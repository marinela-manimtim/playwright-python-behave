# Gherkin Style Guide

This guide defines writing standards for `.feature` files in this framework to ensure consistency, readability, and maintainability across the test suite.

---

## 1. Scenario Structure

Always follow `Given / When / Then` order.
Use `And` or `But` only to extend the immediately preceding keyword.
Keep steps to one action per line.

**Example:**

```gherkin
Scenario: Login with valid credentials
  Given I have a valid user account
  When I send a POST request to "/login" with payload
  Then the response status should be 200
  And the response body should contain "token"
```

See [features/public_posts.feature](features/public_posts.feature) for a reference scenario in this codebase.

---

## 2. Consistent Phrasing

| Keyword  | Purpose                                        |
|----------|------------------------------------------------|
| `Given`  | Precondition or setup — state, data, environment |
| `When`   | Action — API call, user input                  |
| `Then`   | Expected outcome — status code, response body  |

- Use **imperative tone** (not descriptive).
- Avoid technical jargon in steps — keep them business-readable.
- Step text should read naturally to a non-technical stakeholder.

**Bad:**
```gherkin
When I call requests.post with headers
```

**Good:**
```gherkin
When I send a POST request to "/login"
```

The technical implementation of the step belongs in [features/steps/api_steps.py](features/steps/api_steps.py), not in the Gherkin text.

---

## 3. Tags

Use tags for grouping, filtering, and reporting.
Place tags directly above the `Scenario` or `Feature` they apply to.

### Recommended tags

| Tag              | Purpose                                 |
|------------------|-----------------------------------------|
| `@smoke`         | Quick sanity checks                     |
| `@regression`    | Full regression suite                   |
| `@critical`      | High-risk and high-frequency APIs       |
| `@staging`       | Runs against staging environment only   |
| `@prod`          | Runs against production environment only |
| `@auth`          | Authentication and authorisation flows  |
| `@crud`          | Create, read, update, delete operations |
| `@reporting`     | Reporting or analytics endpoints        |

**Example:**

```gherkin
@regression @auth @staging
Scenario: Login with valid credentials
  Given I have a valid user account
  When I send a POST request to "/login" with payload
  Then the response status should be 200
  And the response body should contain "token"
```

To run only tagged scenarios:

```powershell
python -m behave --tags=smoke
python -m behave --tags=regression
python -m behave --tags=auth,staging
```

---

## 4. Parameterization

Use `Scenario Outline` with `<placeholders>` for data-driven tests.
Keep the `Examples` table tabular and minimal — only the columns that vary.

**Example:**

```gherkin
Scenario Outline: Login with different credentials
  Given I have a user with username "<username>" and password "<password>"
  When I send a POST request to "/login"
  Then the response status should be <status>

  Examples:
    | username | password | status |
    | alice    | secret   | 200    |
    | bob      | wrong    | 401    |
```

- Placeholder names should match the `Examples` column headers exactly.
- Use angle brackets `<>` in the step text.
- Avoid large `Examples` tables — split into separate outlines if the test intent differs.

---

## 5. Naming Conventions

### Feature files

- Use `snake_case`.
- Name should describe the business domain or resource being tested.

| Good                      | Bad                |
|---------------------------|--------------------|
| `login.feature`           | `test1.feature`    |
| `crud_operations.feature` | `API.feature`      |
| `public_posts.feature`    | `newFeature.feature` |

See [features/public_posts.feature](features/public_posts.feature) as a reference.

### Scenario titles

- Short, business-readable, sentence case.
- Describe the behavior being tested, not the implementation.

| Good                              | Bad                          |
|-----------------------------------|------------------------------|
| `Login with valid credentials`    | `POST /login 200 test`       |
| `Create a new post`               | `Test post creation API`     |
| `Retrieve a post by id`           | `GET posts id check`         |

### Steps

- Avoid duplicating step definitions — reuse common steps across feature files.
- If a step phrase changes meaning even slightly, create a new step.
- Common step definitions live in [features/steps/api_steps.py](features/steps/api_steps.py).

---

## 6. Best Practices

### Keep scenarios atomic
One scenario tests one behavior. If a scenario is testing two things, split it.

**Bad** (tests two unrelated behaviors):
```gherkin
Scenario: Create and immediately delete a post
  Given the API client is configured
  When I send a POST request to "/posts" with body
  Then the response status code should be 201
  When I send a DELETE request to "/posts/1"
  Then the response status code should be 204
```

**Good** (separated):
```gherkin
Scenario: Create a new post
  ...

Scenario: Delete an existing post
  ...
```

### Avoid chaining too many steps
If a scenario has more than 8–10 steps, it is likely doing too much. Break it up.

### Keep API logic out of Gherkin
Use helpers in step definitions for API calls, not inside the Gherkin text.
The step layer in [features/steps/api_steps.py](features/steps/api_steps.py) calls [helpers/api_client.py](helpers/api_client.py).
The Gherkin layer just describes behavior.

### Align Allure metadata with Gherkin tags
Tags on scenarios are automatically picked up by Allure.
Ensure the tags you use in feature files correspond to meaningful groupings in your Allure report.

---

## Related Files

- [features/public_posts.feature](features/public_posts.feature) - reference feature file
- [features/steps/api_steps.py](features/steps/api_steps.py) - step definitions
- [features/environment.py](features/environment.py) - lifecycle hooks
- [behave.ini](behave.ini) - Behave runner configuration
- [FRAMEWORK_GUIDE.md](FRAMEWORK_GUIDE.md) - full framework architecture guide
- [FRAMEWORK_SETUP.md](FRAMEWORK_SETUP.md) - environment setup guide
