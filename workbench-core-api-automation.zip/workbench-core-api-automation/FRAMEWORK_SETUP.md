# Framework Setup Guide

This guide covers prerequisites and setup for the Python Behave + Allure API automation framework, including Playwright-based implicit authentication.

---

## Prerequisites

### 1. Install Python

Install Python 3.11+ from https://www.python.org/downloads/

After installation, verify it:

```powershell
python --version
python -m pip install --upgrade pip
```

### 2. Install OpenJDK 21 (required for Allure CLI)

Allure requires Java. Install OpenJDK 21 from:
https://adoptium.net/en-GB/temurin/releases/?version=21

Set `JAVA_HOME` and update `Path`:

1. Open environment variables editor:
   ```powershell
   rundll32.exe sysdm.cpl,EditEnvironmentVariables
   ```
2. Add system variable:
   - Name: `JAVA_HOME`
   - Value: JDK install path (without `/bin`), for example: `C:\Program Files\Eclipse Adoptium\jdk-21`
3. Add `%JAVA_HOME%\bin` to `Path`
4. Restart terminal

### 3. Install Allure CLI

Scoop is the recommended installer on Windows:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
Invoke-RestMethod -Uri https://get.scoop.sh | Invoke-Expression
scoop install allure
allure --version
```

---

## Project Setup

From the project root:

### 1. Install dependencies

```powershell
pip install -r requirements.txt
pip show behave
```

Current `requirements.txt` includes:

- `behave>=1.2.6,<2.0.0`
- `requests>=2.32.0,<3.0.0`
- `allure-behave>=2.13.5,<3.0.0`
- `python-dotenv>=1.0.1,<2.0.0`
- `azure-storage-blob>=12.25.1,<13.0.0`
- `azure-storage-file-datalake>=12.20.0,<13.0.0`

### 2. Create `.env`

```powershell
Copy-Item .env.example .env
```

Update values in `.env` for your environment.

Key runtime settings (keep aligned with `.env.example` and `helpers/config.py`):

- `API_TIMEOUT`
- `DEFAULT_HEADERS`
- `OPEN_ALLURE_ON_COMPLETE`
- `ALLURE_RESULTS_DIR`
- Base URL key used by your branch: `API_BASE_URL` or `BASE_URL`
- SSL toggle key used by your branch: `VERIFY_SSL` or `IGNORE_SSL_VERIFY`

---

## Playwright Setup (for implicit auth scenarios)

Playwright is only required when running scenarios that use browser-based implicit authentication (for example tags like `@implicit` / `@implicit_auth`).

### 1. Install Playwright package and browser

```powershell
pip install playwright
playwright install chromium
```

### 2. Configure Playwright auth variables in `.env`

The framework reads these from `.env`:

- `PLAYWRIGHT_LOGIN_URL`
- `PLAYWRIGHT_USERNAME`
- `PLAYWRIGHT_PASSWORD`
- `PLAYWRIGHT_EXPECT_REDIRECT_PREFIX`
- `PLAYWRIGHT_HEADLESS`
- `PLAYWRIGHT_SLOW_MO_MS`
- `PLAYWRIGHT_TIMEOUT_MS`

Optional manual-token variables:

- `PLAYWRIGHT_ACCESS_TOKEN`
- `PLAYWRIGHT_ACCESS_TOKEN_URL`
- `PLAYWRIGHT_ACCESS_TOKEN_EXPIRES_AT`
- `PLAYWRIGHT_MANUAL_LOGIN`
- `PLAYWRIGHT_MANUAL_LOGIN_TIMEOUT_MS`
- `PLAYWRIGHT_PROMPT_FOR_TOKEN`

Security note:

- Do not commit credentials.
- Store sensitive values (especially `PLAYWRIGHT_PASSWORD`) in approved secret stores for CI.

---

## Running Tests

### Standard run

```powershell
python -m behave
```

This writes Allure results to `reports/allure-results` (configured in `behave.ini`).

### Open Allure report manually

```powershell
allure serve reports/allure-results
```

Note:

- If `OPEN_ALLURE_ON_COMPLETE=true`, the framework attempts to open Allure automatically after the run.

---

## Clearing Python Cache

If stale imports or cached auth behavior appears between runs:

```powershell
Remove-Item -Recurse -Force features\__pycache__, features\steps\__pycache__, helpers\__pycache__, auth\__pycache__ -ErrorAction SilentlyContinue
```

Use this when:

- Test state appears to bleed between runs
- Authentication behavior is unexpectedly reused
- Step/helper code changes are not reflected

---

## Python 3.12+ Allure Formatter Note

On Python 3.12+, running Allure formatter flags directly via CLI can trigger runtime issues in some environments.

Avoid:

```powershell
python -m behave -f allure_behave.formatter:AllureFormatter -o reports/allure-results
```

Use:

```powershell
python -m behave
allure serve reports/allure-results
```

---

## VS Code Extension

Install **Behave VSC** for step navigation and runner support.

From VS Code Extensions (`Ctrl+Shift+X`), search for `robypomper.behave-vsc`.

---

## Quick Setup Checklist

- [ ] Python installed and pip upgraded
- [ ] `pip install -r requirements.txt` completed
- [ ] `.env` created from `.env.example` and updated
- [ ] OpenJDK 21 installed and `JAVA_HOME` set
- [ ] Allure CLI installed
- [ ] Playwright installed (`pip install playwright` + `playwright install chromium`) if using implicit auth scenarios
- [ ] Behave VSC extension installed in VS Code

---

## Related Files

- [requirements.txt](requirements.txt) - Python dependencies
- [behave.ini](behave.ini) - Behave and Allure formatter defaults
- [.env.example](.env.example) - runtime configuration template
- [helpers/config.py](helpers/config.py) - runtime settings
- [auth/playwright_auth_handler.py](auth/playwright_auth_handler.py) - browser-based implicit auth
- [features/environment.py](features/environment.py) - test lifecycle hooks
- [FRAMEWORK_ARCHITECTURE.md](FRAMEWORK_ARCHITECTURE.md) - framework architecture