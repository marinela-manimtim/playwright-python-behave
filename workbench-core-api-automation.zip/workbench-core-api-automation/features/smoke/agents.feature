Feature: Smoke test for agents
	As an API automation engineer
	I want to perform smoke tests for agents functionality
    So that I can ensure the basic functionality of agents is working as expected

@create_agent @agents @525527 @implicit_auth @smoke
Scenario Outline: Create a new agent and verify its creation
		Given the API client for agents is configured with region "<region>"
		And I prepare a valid request body for creating an agent with model "<model>"
        When I send a POST request to "/api/projects/<projectId>/assistants?<api-version>"
		Then the response status code should be 200
        And I store the agent assistant id from the response

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@create_thread @agents @525527 @implicit_auth @smoke
Scenario Outline: Create a new thread and verify its creation
        Given the API client for agents is configured with region "<region>"
    And I prepare a valid request body for creating an agent thread
        When I send a POST request to "/api/projects/<projectId>/threads?<api-version>"
        Then the response status code should be 200
    And I store the agent thread id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@create_message @agents @525527 @implicit_auth @smoke
Scenario Outline: Create a new message and verify its creation
    Given the API client for agents is configured with region "<region>" with {{assistantId}}
    And I prepare a valid request body for creating an agent message
    When I send a POST request to "/api/projects/<projectId>/threads/{{threadId}}/messages?<api-version>"
    Then the response status code should be 200
    And I store the agent message id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@create_run @agents @525527 @implicit_auth @smoke
Scenario Outline: Create a new run and verify its creation
        Given the API client for agents is configured with region "<region>"
    And I prepare a valid request body for creating an agent run
        When I send a POST request to "/api/projects/<projectId>/threads/{{threadId}}/runs?<api-version>"
        Then the response status code should be 200
    And I store the agent run id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@get_run @agents @525527 @implicit_auth @smoke
Scenario Outline: Get a run and verify its details
        Given the API client for agents is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |


@list_messages @agents @525527 @implicit_auth @smoke
Scenario Outline: List messages in a thread and verify their details
        Given the API client for agents is configured with region "<region>" with {{assistantId}}
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/messages?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |