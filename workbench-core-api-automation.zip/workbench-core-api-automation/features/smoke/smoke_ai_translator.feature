Feature: Smoke test for AI Translator
	As an API automation engineer
	I want to perform smoke tests for AI Translator functionality
    So that I can ensure the basic functionality of AI Translator is working as expected

@ai_translator @363789 @smoke @implicit_auth
Scenario Outline: Verify that the API can detect language from a piece of text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for detecting language from a piece of text
        When I send a POST request to "/translator/azure/text/detect?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 3.0         |
    | australiaeast | 3.0         |
    | westeurope    | 3.0         |

@ai_translator @363778 @smoke @implicit_auth
Scenario Outline: Verify the translation of text to the desired target language with mandatory parameters only
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for translating a piece of text with mandatory parameters only
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | to |
    | eastus        | 3.0         | hi |
    | australiaeast | 3.0         | hi |
    | westeurope    | 3.0         | hi |

@ai_translator @363782 @smoke @implicit_auth
Scenario Outline: Verify the transliteration of text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for transliterating a piece of text
        When I send a POST request to "/translator/azure/text/transliterate?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | hi       | Deva       | Latn     |
    | australiaeast | 3.0         | hi       | Deva       | Latn     |
    | westeurope    | 3.0         | hi       | Deva       | Latn     |

@ai_translator @363786 @smoke @implicit_auth
Scenario Outline: Verify the breaking of sentence by identifying the positioning of sentence boundaries in a piece of text with mandatory as well as optional parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for breaking a sentence
        When I send a POST request to "/translator/azure/text/breaksentence?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | hi       | Deva       | latn     |
    | australiaeast | 3.0         | hi       | Deva       | latn     |
    | westeurope    | 3.0         | hi       | Deva       | latn     |

@ai_translator @363790 @smoke @implicit_auth
Scenario Outline: Verify the dictionary examples for the provided texts
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary examples
        When I send a POST request to "/translator/azure/text/dictionary/examples?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | en   | es |
    | australiaeast | 3.0         | en   | es |
    | westeurope    | 3.0         | en   | es |

@ai_translator @363792 @smoke @implicit_auth
Scenario Outline: Verify the dictionary lookup for a given text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary lookup
        When I send a POST request to "/translator/azure/text/dictionary/lookup?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | en   | es |
    | australiaeast | 3.0         | en   | es |
    | westeurope    | 3.0         | en   | es |

@ai_translator @363794 @timeout_override @smoke @implicit_auth @smoke
Scenario Outline: Verify the batch translation for a single file
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for batch translation
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 202
        And I store the batch id from the response

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@ai_translator @363797 @timeout_override @implicit_auth @smoke
Scenario Outline: Verify the status for a specific translation job for a single file
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}?api-version=<api-version>"
		Then the response status code should be 200
        And I verify the batch translation status in the response


    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |