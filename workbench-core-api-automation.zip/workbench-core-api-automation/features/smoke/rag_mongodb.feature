Feature: RAG Workflow End-to-End with MongoDB Backend
  As an API automation engineer
  I want to automate the Retrieval-Augmented Generation (RAG) workflow using a MongoDB backend
  So that I can validate the end-to-end RAG process with MongoDB catalog configuration via API

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Create a catalog with mongodb backend
    Given the API client for RAG mongodb is configured with region "<region>"
    When I create a catalog named "<catalog_name>" with mongodb backend
    Then the catalog should be created successfully and catalog id should be saved

    Examples:
      | region        | catalog_name                      |
      | eastus        | Smoke_rag_mongodb_catalog_amer    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Create a catalog source for MongoDB
    Given a mongodb catalog is ready for RAG in region "<region>" with name "<catalog_name>"
    When I create a mongodb catalog source with uri for "<storage_account_name>"
    Then the mongodb catalog source should be created successfully and source id should be saved

    Examples:
      | region        | catalog_name                      | storage_account_name    |
      | eastus        | Smoke_rag_mongodb_catalog_amer    | dlsapimregwbameruseqa   |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   | dlsapimregwbapacaueqa   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    | dlsapimregwbemeaweuqa   |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Start ingestion for MongoDB
    Given a mongodb catalog with source is ready for RAG in region "<region>" with name "<catalog_name>"
    When I start ingestion for the prepared mongodb catalog
    Then the mongodb ingestion job should be accepted and ingestion job id should be saved

    Examples:
      | region        | catalog_name                      |
      | eastus        | Smoke_rag_mongodb_catalog_amer    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Check ingestion status for MongoDB
    Given a mongodb ingestion job is running for RAG in region "<region>" with name "<catalog_name>"
    When I check ingestion status for the prepared mongodb catalog
    Then mongodb ingestion status should eventually be "Ingested"

    Examples:
      | region        | catalog_name                      |
      | eastus        | Smoke_rag_mongodb_catalog_amer    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Perform a search against the MongoDB catalog
    Given an ingested mongodb catalog is ready for RAG in region "<region>" with name "<catalog_name>"
    When I search the prepared mongodb catalog with query "<search_query>"
    Then mongodb search should return results successfully

    Examples:
      | region        | catalog_name                      | search_query |
      | eastus        | Smoke_rag_mongodb_catalog_amer    | Job Level    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   | Job Level    |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    | Job Level    |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Delete catalog source for MongoDB
    Given the mongodb catalog source for "<catalog_name>" in region "<region>" is ready to be deleted
    When I delete the mongodb catalog source
    Then the mongodb catalog source should be deleted successfully

    Examples:
      | region        | catalog_name                      |
      | eastus        | Smoke_rag_mongodb_catalog_amer    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    |

  @smoke-rag-mongodb @mongodb
  Scenario Outline: Delete catalog for MongoDB
    Given the mongodb catalog "<catalog_name>" in region "<region>" is ready to be deleted
    When I delete the mongodb catalog
    Then the mongodb catalog should be deleted successfully

    Examples:
      | region        | catalog_name                      |
      | eastus        | Smoke_rag_mongodb_catalog_amer    |
      | australiaeast | Smoke_rag_mongodb_catalog_aspac   |
      | westeurope    | Smoke_rag_mongodb_catalog_emea    |
