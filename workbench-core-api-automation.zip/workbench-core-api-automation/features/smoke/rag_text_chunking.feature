Feature: RAG Workflow End-to-End
	As an API automation engineer
	I want to automate the Retrieval-Augmented Generation (RAG) workflow
	So that I can validate the end-to-end RAG process via API

	@smoke-rag-text-chunking @12345
	Scenario Outline: Create a catalog for text chunking
		Given the API client for RAG is configured with region "<region>"
		When I create a catalog named "<catalog_name>"
		Then the catalog should be created successfully and catalog id should be saved

		Examples:
			| region        | catalog_name                 |
			| eastus        | Smoke_rag_text_catalog_amer  |
			| australiaeast | Smoke_rag_text_catalog_aspac |
			| westeurope    | Smoke_rag_text_catalog_emea  |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Create a catalog source for text chunking
		Given a catalog is ready for RAG in region "<region>" with name "<catalog_name>"
		When I create a catalog source with uri for "<storage_account_name>"
		Then the catalog source should be created successfully and source id should be saved

		Examples:
			| region        | catalog_name                 | storage_account_name      |
			| eastus        | Smoke_rag_text_catalog_amer  | dlsapimregwbameruseqa     |
			| australiaeast | Smoke_rag_text_catalog_aspac | dlsapimregwbapacaueqa     |
			| westeurope    | Smoke_rag_text_catalog_emea  | dlsapimregwbemeaweuqa     |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Start ingestion for text chunking
		Given a catalog with source is ready for RAG in region "<region>" with name "<catalog_name>"
		When I start ingestion for the prepared catalog
		Then the ingestion job should be accepted and ingestion job id should be saved

		Examples:
			| region        | catalog_name                 |
			| eastus        | Smoke_rag_text_catalog_amer  |
			| australiaeast | Smoke_rag_text_catalog_aspac |
			| westeurope    | Smoke_rag_text_catalog_emea  |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Check ingestion status for text chunking
		Given an ingestion job is running for RAG in region "<region>" with name "<catalog_name>"
		When I check ingestion status for the prepared catalog
		Then ingestion status should eventually be "Ingested"

		Examples:
			| region        | catalog_name                 |
			| eastus        | Smoke_rag_text_catalog_amer  |
			| australiaeast | Smoke_rag_text_catalog_aspac |
			| westeurope    | Smoke_rag_text_catalog_emea  |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Perform a search against the text chunking catalog
		Given an ingested catalog is ready for RAG in region "<region>" with name "<catalog_name>"
		When I search the prepared catalog with query "<search_query>"
		Then search should return results successfully

		Examples:
			| region        | catalog_name                 | search_query |
			| eastus        | Smoke_rag_text_catalog_amer  | Job Level    |
			| australiaeast | Smoke_rag_text_catalog_aspac | Job Level    |
			| westeurope    | Smoke_rag_text_catalog_emea  | Job Level    |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Delete catalog source for text chunking
		Given the catalog source for "<catalog_name>" in region "<region>" is ready to be deleted
		When I delete the catalog source
		Then the catalog source should be deleted successfully

		Examples:
			| region        | catalog_name                 |
			| eastus        | Smoke_rag_text_catalog_amer  |
			| australiaeast | Smoke_rag_text_catalog_aspac |
			| westeurope    | Smoke_rag_text_catalog_emea  |

	@smoke-rag-text-chunking @12345
	Scenario Outline: Delete catalog for text chunking
		Given the catalog "<catalog_name>" in region "<region>" is ready to be deleted
		When I delete the catalog
		Then the catalog should be deleted successfully

		Examples:
			| region        | catalog_name                 |
			| eastus        | Smoke_rag_text_catalog_amer  |
			| australiaeast | Smoke_rag_text_catalog_aspac |
			| westeurope    | Smoke_rag_text_catalog_emea  |
