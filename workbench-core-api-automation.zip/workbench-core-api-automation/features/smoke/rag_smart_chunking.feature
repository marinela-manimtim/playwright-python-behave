Feature: RAG Workflow End-to-End with Smart Chunking
  As an API automation engineer
  I want to automate the Retrieval-Augmented Generation (RAG) workflow using Smart chunking
  So that I can validate the end-to-end RAG process with Smart chunking configuration via API

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Create a catalog with smart chunking configuration
    Given the API client for RAG smart chunking is configured with region "<region>"
    When I create a catalog named "<catalog_name>" with smart chunking settings
    Then the catalog should be created successfully and catalog id should be saved

    Examples:
      | region        | catalog_name                    |
      | eastus        | Smoke_rag_smart_catalog_amer    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   |
      | westeurope    | Smoke_rag_smart_catalog_emea    |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Create a catalog source for smart chunking
    Given a smart chunking catalog is ready for RAG in region "<region>" with name "<catalog_name>"
    When I create a smart chunking catalog source with uri for "<storage_account_name>"
    Then the smart chunking catalog source should be created successfully and source id should be saved

    Examples:
      | region        | catalog_name                    | storage_account_name    |
      | eastus        | Smoke_rag_smart_catalog_amer    | dlsapimregwbameruseqa   |
      | australiaeast | Smoke_rag_smart_catalog_aspac   | dlsapimregwbapacaueqa   |
      | westeurope    | Smoke_rag_smart_catalog_emea    | dlsapimregwbemeaweuqa   |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Start ingestion for smart chunking
    Given a smart chunking catalog with source is ready for RAG in region "<region>" with name "<catalog_name>"
    When I start ingestion for the prepared smart chunking catalog
    Then the smart chunking ingestion job should be accepted and ingestion job id should be saved

    Examples:
      | region        | catalog_name                    |
      | eastus        | Smoke_rag_smart_catalog_amer    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   |
      | westeurope    | Smoke_rag_smart_catalog_emea    |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Check ingestion status for smart chunking
    Given a smart chunking ingestion job is running for RAG in region "<region>" with name "<catalog_name>"
    When I check ingestion status for the prepared smart chunking catalog
    Then smart chunking ingestion status should eventually be "Ingested"

    Examples:
      | region        | catalog_name                    |
      | eastus        | Smoke_rag_smart_catalog_amer    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   |
      | westeurope    | Smoke_rag_smart_catalog_emea    |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Perform a search against the smart chunking catalog
    Given an ingested smart chunking catalog is ready for RAG in region "<region>" with name "<catalog_name>"
    When I search the prepared smart chunking catalog with query "<search_query>"
    Then smart chunking search should return results successfully

    Examples:
      | region        | catalog_name                    | search_query |
      | eastus        | Smoke_rag_smart_catalog_amer    | Job Level    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   | Job Level    |
      | westeurope    | Smoke_rag_smart_catalog_emea    | Job Level    |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Delete catalog source for smart chunking
    Given the smart chunking catalog source for "<catalog_name>" in region "<region>" is ready to be deleted
    When I delete the smart chunking catalog source
    Then the smart chunking catalog source should be deleted successfully

    Examples:
      | region        | catalog_name                    |
      | eastus        | Smoke_rag_smart_catalog_amer    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   |
      | westeurope    | Smoke_rag_smart_catalog_emea    |

  @smoke-rag-smart @smart_chunking
  Scenario Outline: Delete catalog for smart chunking
    Given the smart chunking catalog "<catalog_name>" in region "<region>" is ready to be deleted
    When I delete the smart chunking catalog
    Then the smart chunking catalog should be deleted successfully

    Examples:
      | region        | catalog_name                    |
      | eastus        | Smoke_rag_smart_catalog_amer    |
      | australiaeast | Smoke_rag_smart_catalog_aspac   |
      | westeurope    | Smoke_rag_smart_catalog_emea    |
