from __future__ import annotations

import os
import sys
import shutil
import subprocess
from pathlib import Path

# Ensure the project root is on sys.path so `helpers`, `auth`, etc. are importable.
# (conftest.py does this for pytest, but behave never loads conftest.py.)
_PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from helpers.config import get_settings

PROJECT_ROOT = _PROJECT_ROOT
_DYNAMIC_MODEL_FEATURES = {"azure_openai_completions_and_embeddings.feature"}
_DYNAMIC_MODEL_REGIONS = ("eastus", "australiaeast", "westeurope")


def _on_playwright_browser_open(event: dict[str, object]) -> None:
    region = event.get("region")
    profile = event.get("profile")
    headless = event.get("headless")
    channel = event.get("channel")
    print(
        "[playwright_hook] browser_open "
        f"region={region} profile={profile} headless={headless} channel={channel}"
    )


def _on_playwright_browser_close(event: dict[str, object]) -> None:
    region = event.get("region")
    profile = event.get("profile")
    headless = event.get("headless")
    channel = event.get("channel")
    print(
        "[playwright_hook] browser_close "
        f"region={region} profile={profile} headless={headless} channel={channel}"
    )


def _ensure_allure_results_dir(path: Path) -> None:
    if path.exists() and not path.is_dir():
        path.unlink()
    path.mkdir(parents=True, exist_ok=True)


def _open_allure_dashboard(results_dir: Path) -> None:
    if os.getenv("CI"):
        return

    allure_executable = shutil.which("allure")
    if not allure_executable:
        print("Allure CLI not found on PATH. Results written for later viewing.")
        return

    popen_kwargs = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "cwd": str(PROJECT_ROOT),
    }
    if os.name == "nt":
        popen_kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        popen_kwargs["start_new_session"] = True

    subprocess.Popen(
        [allure_executable, "serve", str(results_dir)],
        **popen_kwargs,
    )


def before_all(context) -> None:
    from auth.playwright_auth_handler import register_browser_lifecycle_hooks

    settings = get_settings()
    results_dir = PROJECT_ROOT / settings.allure_results_dir
    _ensure_allure_results_dir(results_dir)
    context.settings = settings
    context.allure_results_dir = results_dir
    context.client = None
    context.headers = {}
    context.last_response = None
    context.request_payload = None
    context.deployment_map = {}
    
    # Initialize region-keyed storage for IDs that persist across scenarios
    context.config.batch_ids_by_region = {}
    context.config.batch_synthesis_job_ids_by_region = {}
    context.config.message_ids_by_region = {}
    context.config.thread_ids_by_region = {}
    context.config.run_ids_by_region = {}
    context.config.transcription_job_ids_by_region = {}

    register_browser_lifecycle_hooks(
        on_open=_on_playwright_browser_open,
        on_close=_on_playwright_browser_close,
    )


def _fetch_model_access_instances(region: str) -> dict[str, str]:
    from helpers.service import Service  # local import to avoid circular deps at module load

    client = Service(region)
    try:
        response = client.get("/deployments/access", headers={"x-kpmg-region-override": region})
        response.raise_for_status()
        models = response.json().get("models", [])
        deployment_map: dict[str, str] = {}
        for model in models:
            instance_name = model.get("instanceName")
            if instance_name:
                deployment_map[instance_name] = instance_name

        return {
            model_name: deployment_map[model_name]
            for model_name in sorted(deployment_map)
        }
    finally:
        if hasattr(client, "client"):
            client.client.close()


def _scenario_uses_dynamic_model_resolution(scenario_outline) -> bool:
    steps = getattr(scenario_outline, "steps", [])
    return any(
        'deployment name for model type' in getattr(step, "name", "")
        for step in steps
    )


def _expand_dynamic_model_examples(scenario_outline, models_by_region: dict[str, list[str]]) -> None:
    for example in getattr(scenario_outline, "examples", []):
        table = getattr(example, "table", None)
        if not table or "region" not in table.headings or "model_name" not in table.headings:
            continue

        original_rows = list(table.rows)
        expanded_rows: list[list[str]] = []
        for row in original_rows:
            region = row["region"]
            models = models_by_region.get(region)
            if not models:
                expanded_rows.append(list(row.cells))
                continue

            row_data = {heading: row[heading] for heading in table.headings}
            for model_name in models:
                updated_row = dict(row_data)
                updated_row["model_name"] = model_name
                expanded_rows.append([updated_row[heading] for heading in table.headings])

        table.clear(keep_headings=True)
        for cells in expanded_rows:
            table.add_row(cells)


def before_feature(context, feature) -> None:
    context.deployment_map = {}
    feature_name = Path(getattr(feature, "filename", "")).name
    if feature_name not in _DYNAMIC_MODEL_FEATURES:
        return

    models_by_region: dict[str, list[str]] = {}
    for region in _DYNAMIC_MODEL_REGIONS:
        try:
            deployment_map = _fetch_model_access_instances(region)
            if deployment_map:
                context.deployment_map[region] = deployment_map
                models_by_region[region] = list(deployment_map.keys())
        except Exception as exc:  # noqa: BLE001
            print(
                f"[before_feature] Warning: could not expand dynamic models for region '{region}': {exc}"
            )

    for scenario_outline in getattr(feature, "scenarios", []):
        if not getattr(scenario_outline, "examples", None):
            continue
        if not _scenario_uses_dynamic_model_resolution(scenario_outline):
            continue
        _expand_dynamic_model_examples(scenario_outline, models_by_region)

    # Re-wrap dynamically rebuilt scenario objects for the Allure formatter.
    # AllureFormatter.feature() wraps scenarios via allure_commons.test() during
    # the initial feature pass. After our table mutation, ScenarioOutlineBuilder
    # creates NEW scenario objects which are not wrapped → KeyError: None at runtime.
    # Calling _wrap_scenario again on the affected outlines fixes this.
    try:
        from allure_behave.formatter import AllureFormatter
        formatters = getattr(getattr(context, "_runner", None), "formatters", [])
        allure_fmt = next((f for f in formatters if isinstance(f, AllureFormatter)), None)
        if allure_fmt is not None:
            for scenario_outline in getattr(feature, "scenarios", []):
                if not getattr(scenario_outline, "examples", None):
                    continue
                if not _scenario_uses_dynamic_model_resolution(scenario_outline):
                    continue
                # Access .scenarios to trigger ScenarioOutlineBuilder rebuild,
                # then wrap each new scenario object.
                allure_fmt._wrap_scenario(list(scenario_outline.scenarios))
    except Exception:  # noqa: BLE001
        pass  # allure_behave not installed or incompatible version


def before_scenario(context, scenario) -> None:
    scenario_tags = {tag.lower() for tag in getattr(scenario, "effective_tags", [])}
    if "skip" in scenario_tags:
        scenario.skip("Skipped by @skip tag")
        return

    # Clear the global Playwright token cache for scenarios tagged @force_auth_browser
    if "force_auth_browser" in scenario_tags:
        from auth.playwright_auth_handler import _IMPLICIT_TOKEN_CACHE
        _IMPLICIT_TOKEN_CACHE.clear()
        print("[before_scenario] Cleared Playwright token cache due to @force_auth_browser tag")

    context.client = None
    context.headers = {}
    context.last_response = None
    context.request_payload = None
    context.resolved_model_name = None
    # Use a longer timeout for rate-limit scenarios that may take longer to respond
    context.timeout_override = 200 if "timeout_override" in scenario_tags else None
    # Skip auth for scenarios explicitly tagged @no_auth
    context.skip_auth = "no_auth" in scenario_tags
    # Use browser-based implicit auth only for scenarios explicitly tagged for it.
    context.use_implicit_auth = any(tag in scenario_tags for tag in {"implicit", "implicit_auth"})

    # Skip region override header for scenarios explicitly tagged @skip_region_override_australiaeast
    context.skip_region_override_australiaeast = "skip_region_override_australiaeast" in scenario_tags


def after_scenario(context, scenario) -> None:
    developer_portal_context = getattr(context, "developer_portal_context", None)
    if developer_portal_context is not None:
        try:
            developer_portal_context.close()
        except Exception:  # noqa: BLE001
            pass

    developer_portal_browser = getattr(context, "developer_portal_browser", None)
    if developer_portal_browser is not None:
        try:
            developer_portal_browser.close()
            print("[playwright_hook] browser_close source=developer_portal")
        except Exception:  # noqa: BLE001
            pass

    playwright_instance = getattr(context, "playwright_instance", None)
    if playwright_instance is not None:
        try:
            playwright_instance.stop()
        except Exception:  # noqa: BLE001
            pass

    context.developer_portal_page = None
    context.developer_portal_context = None
    context.developer_portal_browser = None
    context.playwright_instance = None

    client = getattr(context, "client", None)
    if client and hasattr(client, "client"):
        client.client.close()


def after_all(context) -> None:
    client = getattr(context, "client", None)
    if client and hasattr(client, "client"):
        client.client.close()

    if getattr(context.settings, "open_allure_on_complete", False):
        _open_allure_dashboard(context.allure_results_dir)