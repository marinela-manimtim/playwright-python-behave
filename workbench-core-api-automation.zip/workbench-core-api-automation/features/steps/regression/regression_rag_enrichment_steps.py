from __future__ import annotations

import json
from datetime import datetime, timezone
from urllib.parse import urlparse

import allure
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()

API_VERSION = "2023-04-01"
ANALYZE_TEXT_ENDPOINT = "/language/analyze-text/jobs"
TEXT_ANALYSIS_RUNTIME_ENDPOINT = "/language/:analyze-text"


def _configure_client(context, region: str) -> None:
    """Configure the API client and standard headers for the selected region."""
    context.client = Service(region, use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _attach_request_details(context, request_body: dict | None = None) -> None:
    """Attach request metadata for diagnostics."""
    allure.attach(
        getattr(context, "request_url", "N/A") or "N/A",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(request_body, indent=2) if request_body is not None else "N/A",
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


def _get_json_response(context, allow_empty: bool = False) -> dict | list:
    """Parse and attach JSON response for diagnostics."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    response_text = (response.text or "").strip()
    if allow_empty and not response_text:
        allure.attach("N/A", name="response_body", attachment_type=allure.attachment_type.TEXT)
        return {}

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _build_unique_display_name(base_name: str) -> str:
    """Create a display name that is unique for each request execution."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"{base_name} - {timestamp}"


def _extract_operation_location_and_job_id(response, payload: dict | list | None = None) -> tuple[str | None, str | None]:
    """Extract the operation-location header value and job id from a response."""
    operation_location = response.headers.get("Operation-Location") or response.headers.get("operation-location")
    job_id = None

    if operation_location:
        parsed_path = urlparse(operation_location).path.strip("/")
        path_parts = parsed_path.split("/") if parsed_path else []
        if path_parts:
            job_id = path_parts[-1]

    if not job_id and isinstance(payload, dict):
        job_id = payload.get("jobId") or payload.get("id") or payload.get("analyzeTextJobId")

    return operation_location, job_id


def _store_job_id(context, job_id: str | None, *, store_for_reuse: bool = True) -> None:
    """Store the job id on the context and optionally in a region map for scenario reuse."""
    assert job_id, "Could not find a job id in the response."

    context.analyze_text_job_id = job_id
    if store_for_reuse:
        region = getattr(context, "headers", {}).get("x-kpmg-region-override")
        if region:
            job_ids_by_region = getattr(context.config, "analyze_text_job_ids_by_region", {})
            job_ids_by_region[region] = job_id
            context.config.analyze_text_job_ids_by_region = job_ids_by_region

        context.config.analyze_text_job_id = job_id
    allure.attach(str(job_id), name="job_id", attachment_type=allure.attachment_type.TEXT)


def _submit_analyze_text_job(
    context,
    request_body: dict,
    response_key_prefix: str,
    *,
    store_for_reuse: bool = True,
) -> None:
    """Submit an analyze-text job and capture the operation-location header."""
    endpoint = ANALYZE_TEXT_ENDPOINT
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    payload = _get_json_response(context, allow_empty=True)

    operation_location, job_id = _extract_operation_location_and_job_id(context.last_response, payload)
    context.operation_location = operation_location
    context.last_operation_location = operation_location
    setattr(context, f"{response_key_prefix}_operation_location", operation_location)
    setattr(context, f"{response_key_prefix}_job_id", job_id)

    if operation_location:
        allure.attach(
            operation_location,
            name="operation_location",
            attachment_type=allure.attachment_type.TEXT,
        )

    _store_job_id(context, job_id, store_for_reuse=store_for_reuse)


# ============================================================
# SCENARIO 1 - Submit Analyze Text Job
# ============================================================


@given('the RAG Enrichment API client is configured with region "{region}"')
def setup_analyze_text_client(context, region):
    _configure_client(context, region)


@when("I submit the Analyze Text Job")
def submit_analyze_text_job(context):
    display_name = _build_unique_display_name("Text Summarization Regression")
    request_body = {
        "displayName": display_name,
        "analysisInput": {
            "documents": [
                {
                    "id": "1",
                    "language": "en",
                    "text": (
                        "The national bird of India is the Indian peacock, scientifically known as Pavo cristatus, and it was declared the national bird in 1963.  "
                        "It is famous for its beautiful and colorful feathers, especially the long tail of the male, which displays eye-like patterns and is spread out in a fan during courtship.  "
                        "The peacock is found across India in forests, farmlands, and near human settlements, making it a common and easily recognizable bird.  "
                        "It holds great cultural and religious significance in Indian traditions and is often associated with beauty, grace, and pride.  "
                        "Because of its widespread presence, unique appearance, and deep connection with Indian culture, the peacock was chosen as a symbol of the country's natural heritage and identity."
                    ),
                }
            ]
        },
        "tasks": [
            {
                "kind": "AbstractiveSummarization",
                "taskName": display_name,
                "parameters": {"sentenceCount": 5},
            }
        ],
    }
    _submit_analyze_text_job(context, request_body, "analyze_text")


@then("the Analyze Text Job should be accepted and operation-location should be saved")
def verify_analyze_text_job_submitted(context):
    assert context.last_status_code in (200, 202), f"Expected HTTP 200/202 but got {context.last_status_code}"
    assert getattr(context, "analyze_text_job_id", None), "analyze_text_job_id was not returned in the response."
    assert getattr(context, "analyze_text_operation_location", None), (
        "operation-location was not returned in the response headers."
    )


# ============================================================
# SCENARIO 2 - Get Analyze Text Job Status
# ============================================================


@given('the Analyze Text Job is started in region "{region}"')
def setup_analyze_text_job_status_client(context, region):
    _configure_client(context, region)

    job_id = None
    if region:
        job_id = getattr(context.config, "analyze_text_job_ids_by_region", {}).get(region)

    if not job_id:
        job_id = getattr(context, "analyze_text_job_id", None)
    if not job_id:
        job_id = getattr(context.config, "analyze_text_job_id", None)

    assert job_id, (
        "No analyze text job id available for this scenario. Run the Submit Analyze Text Job scenario first and store the id from the response."
    )

    context.analyze_text_job_id = job_id
    allure.attach(str(job_id), name="resolved_job_id", attachment_type=allure.attachment_type.TEXT)


@when("I get the Analyze Text Job status")
def get_analyze_text_job_status(context):
    endpoint = f"{ANALYZE_TEXT_ENDPOINT}/{context.analyze_text_job_id}"
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.analyze_text_status_payload = _get_json_response(context)


@then("the Analyze Text Job status should be returned successfully")
def verify_analyze_text_job_status(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "analyze_text_status_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected analyze text job status payload to be a JSON object or array."
    if isinstance(payload, dict):
        status = str(payload.get("status") or payload.get("jobStatus") or "").strip().lower()
        assert status, "Expected a status value in the analyze text job status response."


# ============================================================
# SCENARIO 3 - Text Analysis Runtime
# ============================================================


@when("I submit the Text Analysis Runtime job")
def submit_text_analysis_runtime_job(context):
    request_body = {
        "kind": "EntityRecognition",
        "parameters": {
            "modelVersion": "latest"
        },
        "analysisInput": {
            "documents": [
                {
                    "id": "1",
                    "language": "en",
                    "text": "Microsoft was founded by Bill Gates and Paul Allen."
                },
                {
                    "id": "2",
                    "language": "en",
                    "text": "Pike place market is my favorite Seattle attraction."
                }
            ]
        }
    }
    endpoint = TEXT_ANALYSIS_RUNTIME_ENDPOINT
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.text_analysis_runtime_payload = _get_json_response(context, allow_empty=True)

    operation_location, job_id = _extract_operation_location_and_job_id(
        context.last_response,
        context.text_analysis_runtime_payload,
    )
    context.text_analysis_runtime_operation_location = operation_location
    context.text_analysis_runtime_job_id = job_id

    if operation_location:
        allure.attach(
            operation_location,
            name="text_analysis_runtime_operation_location",
            attachment_type=allure.attachment_type.TEXT,
        )


@then("the Text Analysis Runtime job should be accepted and operation-location should be saved")
def verify_text_analysis_runtime_job_submitted(context):
    assert context.last_status_code in (200, 202), f"Expected HTTP 200/202 but got {context.last_status_code}"
    if context.last_status_code == 202:
        assert getattr(context, "text_analysis_runtime_operation_location", None), (
            "operation-location was not returned in the response headers."
        )
    else:
        payload = getattr(context, "text_analysis_runtime_payload", None) or _get_json_response(context, allow_empty=True)
        assert isinstance(payload, (dict, list)), "Expected Text Analysis Runtime response payload to be a JSON object or array."


# ============================================================
# SCENARIO 4 - Submit Analyze Text Job with malformed JSON format
# ============================================================


@given('the RAG Enrichment malformed analyze text request client is configured with region "{region}"')
def setup_malformed_analyze_text_client(context, region):
    _configure_client(context, region)


@when("I submit the Analyze Text Job API request with malformed JSON format")
def submit_analyze_text_job_with_malformed_json_format(context):
    # Intentionally send runtime-style payload to the submit-job endpoint to validate request-shape handling.
    request_body = {
        "kind": "EntityRecognition",
        "parameters": {
            "modelVersion": "latest"
        },
        "analysisInput": {
            "documents": [
                {
                    "id": "1",
                    "language": "en",
                    "text": "Microsoft was founded by Bill Gates and Paul Allen."
                },
                {
                    "id": "2",
                    "language": "en",
                    "text": "Pike place market is my favorite Seattle attraction."
                }
            ]
        }
    }

    endpoint = ANALYZE_TEXT_ENDPOINT
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.malformed_analyze_text_payload = _get_json_response(context, allow_empty=True)


@then('the Submit Analyze Text Job malformed JSON error should return status 400 with message "Invalid Request."')
def verify_submit_analyze_text_job_malformed_json_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "malformed_analyze_text_payload", None) or _get_json_response(context, allow_empty=True)
    assert isinstance(payload, dict), "Expected malformed-request response payload to be a JSON object."

    error_message = ""
    error_node = payload.get("error")
    if isinstance(error_node, dict):
        error_message = str(error_node.get("message") or "").strip()
    if not error_message:
        error_message = str(payload.get("message") or "").strip()

    assert error_message == "Invalid Request.", (
        f"Expected error message 'Invalid Request.' but got '{error_message}'. Full payload: {payload}"
    )


# ============================================================
# SCENARIO 5 - Get Analyze Text Job Status with invalid job id
# ============================================================


@given('the RAG Enrichment invalid analyze text job status client is configured with region "{region}"')
def setup_invalid_analyze_text_job_status_client(context, region):
    _configure_client(context, region)


@when('I get the Analyze Text Job status using invalid or non-existing job id "{job_id}"')
def get_analyze_text_job_status_with_invalid_job_id(context, job_id):
    endpoint = f"{ANALYZE_TEXT_ENDPOINT}/{job_id}"
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_job_status_payload = _get_json_response(context, allow_empty=True)


@then('the Get Analyze Text Job Status invalid job id error should return status 400 with message "Invalid Request."')
def verify_get_analyze_text_job_status_invalid_job_id_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "invalid_job_status_payload", None) or _get_json_response(context, allow_empty=True)
    assert isinstance(payload, dict), "Expected invalid-job-id response payload to be a JSON object."

    error_message = ""
    error_node = payload.get("error")
    if isinstance(error_node, dict):
        error_message = str(error_node.get("message") or "").strip()
    if not error_message:
        error_message = str(payload.get("message") or "").strip()

    assert error_message == "Invalid Request.", (
        f"Expected error message 'Invalid Request.' but got '{error_message}'. Full payload: {payload}"
    )


# ============================================================
# SCENARIO 6 - Text Analysis Runtime with invalid request body
# ============================================================


@given('the RAG Enrichment invalid text analysis runtime client is configured with region "{region}"')
def setup_invalid_text_analysis_runtime_client(context, region):
    _configure_client(context, region)


@when("I submit the Text Analysis Runtime job with invalid request body")
def submit_text_analysis_runtime_job_with_invalid_request_body(context):
    request_body = {
        "kind": "",
        "parameters": {
            "modelVersion": "latest"
        },
        "analysisInput": {
            "documents": [
                {
                    "id": "1",
                    "language": "en",
                    "text": "Dr. Smith has a very modern medical office, and she has great staff."
                }
            ]
        }
    }
    endpoint = TEXT_ANALYSIS_RUNTIME_ENDPOINT
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_text_analysis_runtime_payload = _get_json_response(context, allow_empty=True)


@then("the Text Analysis Runtime invalid request body error should return status 400")
def verify_text_analysis_runtime_invalid_request_body_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "invalid_text_analysis_runtime_payload", None) or _get_json_response(context, allow_empty=True)
    assert isinstance(payload, dict), "Expected invalid runtime request response payload to be a JSON object."

    error_message = ""
    error_node = payload.get("error")
    if isinstance(error_node, dict):
        error_message = str(error_node.get("message") or "").strip()
    if not error_message:
        error_message = str(payload.get("message") or "").strip()

    assert error_message, f"Expected error message in response payload, but got: {payload}"