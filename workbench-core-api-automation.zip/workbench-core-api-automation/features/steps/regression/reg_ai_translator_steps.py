from __future__ import annotations

import importlib
import json
import os
import time
from urllib.parse import urlparse

import allure
from behave import given, then, when
from dotenv import load_dotenv

from features.steps.regression.blob_data_transfer_steps import (
    _cleanup_destination_path,
    _get_storage_setting,
    _get_storage_ssl_verify,
    _mask_sas_url,
)


def _load_ai_translator_storage_clients():
    """Load only the Azure storage clients required for AI Translator batch translation."""
    blob_module = importlib.import_module("azure.storage.blob")
    datalake_module = importlib.import_module("azure.storage.filedatalake")
    return (
        blob_module.BlobServiceClient,
        datalake_module.DataLakeServiceClient,
    )


def _get_batch_translation_source_url_for_region(context) -> str:
    """Return the static source container URL for the current region from env vars."""
    return _get_batch_translation_storage_setting_for_region(
        context, "BATCH_TRANSLATION_SOURCE_URL", ""
    )


def _get_batch_translation_destination_url_for_region(context) -> str:
    """Return the static destination container URL for the current region from env vars."""
    return _get_batch_translation_storage_setting_for_region(
        context, "BATCH_TRANSLATION_DESTINATION_URL", ""
    )


def _parse_blob_container_and_prefix(blob_url: str) -> tuple[str, str]:
    parsed = urlparse(blob_url)
    path_parts = [segment for segment in parsed.path.strip("/").split("/") if segment]
    if not path_parts:
        return "", ""

    container_name = path_parts[0]
    prefix = "/".join(path_parts[1:]).strip("/")
    return container_name, prefix


def _cleanup_ai_translator_destination_folder(
    blob_service_client,
    data_lake_client,
    destination_url: str,
    fallback_container_name: str,
    fallback_directory_name: str,
) -> None:
    container_from_url, prefix_from_url = _parse_blob_container_and_prefix(destination_url)
    if container_from_url:
        destination_container_name = container_from_url
        directory_name = prefix_from_url.strip("/")
    else:
        destination_container_name = fallback_container_name
        directory_name = fallback_directory_name.strip("/")

    assert destination_container_name, "Destination container name could not be resolved for cleanup."

    if directory_name:
        _cleanup_destination_path(
            blob_service_client=blob_service_client,
            data_lake_client=data_lake_client,
            destination_container_name=destination_container_name,
            directory_name=directory_name,
        )

    try:
        container_client = blob_service_client.get_container_client(destination_container_name)
        if directory_name:
            candidate_blobs = list(container_client.list_blobs(name_starts_with=directory_name))
            blob_names = [
                blob.name
                for blob in candidate_blobs
                if blob.name == directory_name or blob.name.startswith(f"{directory_name}/")
            ]
        else:
            blob_names = [blob.name for blob in container_client.list_blobs()]

        if blob_names:
            container_client.delete_blobs(*blob_names)
    except Exception as ex:  # noqa: BLE001
        allure.attach(
            str(ex),
            name="ai_translator_destination_cleanup_warning",
            attachment_type=allure.attachment_type.TEXT,
        )


def _get_region_for_storage(context) -> str:
    headers = getattr(context, "headers", {}) or {}
    region = headers.get("x-kpmg-region-override", "")
    return str(region).strip().lower()


def _get_batch_translation_connection_string_for_region(context) -> str:
    region = _get_region_for_storage(context)

    region_prefix_map = {
        "eastus": "AMER",
        "westeurope": "EMEA",
        "australiaeast": "ASPAC",
    }

    candidates: list[str] = []
    if region:
        normalized_region = region.replace("-", "_").upper()
        candidates.append(f"BATCH_TRANSLATION_CONNECTION_STRING_{normalized_region}")

        mapped_prefix = region_prefix_map.get(region)
        if mapped_prefix:
            candidates.append(f"BATCH_TRANSLATION_CONNECTION_STRING_{mapped_prefix}")

    candidates.append("BATCH_TRANSLATION_CONNECTION_STRING")

    for env_var_name in candidates:
        raw_value = os.getenv(env_var_name)
        if raw_value and raw_value.strip():
            return raw_value.strip()

    resolved_candidates = ", ".join(candidates)
    raise AssertionError(
        "Missing Azure Storage connection string for batch translation smoke test. "
        f"Checked env vars: {resolved_candidates}."
    )


def _get_batch_translation_storage_setting_for_region(context, base_name: str, default: str) -> str:
    region = _get_region_for_storage(context)

    region_prefix_map = {
        "eastus": "EASTUS",
        "westeurope": "WESTEUROPE",
        "australiaeast": "AUSTRALIAEAST",
    }

    candidates: list[str] = []
    if region:
        normalized_region = region.replace("-", "_").upper()
        candidates.append(f"{base_name}_{normalized_region}")

        mapped_prefix = region_prefix_map.get(region)
        if mapped_prefix:
            candidates.append(f"{base_name}_{mapped_prefix}")

    candidates.append(base_name)

    for env_var_name in candidates:
        raw_value = os.getenv(env_var_name)
        if raw_value and raw_value.strip():
            return raw_value.strip()

    return default

@given("I prepare a valid request body for detecting language from a piece of text")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"English is a widely spoken language that connects people from diverse cultures around the world"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given("I prepare a valid request body for translating a piece of text with mandatory and optional parameters")
@given("I prepare a valid request body for translating a piece of text with mandatory parameters only")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"I would really like to drive your car around the block a few times."}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for verifying the consumption of all the Text APIs")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text": "<Add less than 50000 characters>"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given("I prepare a valid request body for transliterating a piece of text")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"आपका नाम क्या है?"},{"Text":"आप कैसे हैं?"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for breaking a sentence")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"How are you? I am fine. What did you do today?"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )    

@given("I prepare a valid request body for dictionary examples")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"friendship","Translation":"amistad"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )        

@given("I prepare a valid request body for dictionary lookup")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{"Text":"Friendship"}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )  

@given('I prepare a valid request body for batch translation')
def step_impl(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        BlobServiceClient, DataLakeServiceClient = _load_ai_translator_storage_clients()

        account_connection_string = _get_batch_translation_connection_string_for_region(context)
        destination_container_name = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_DESTINATION_CONTAINER",
            "translator-destination",
        )
        destination_directory_name = _get_storage_setting(
            "BATCH_TRANSLATION_DESTINATION_DIRECTORY_NAME",
            _get_storage_setting("BATCH_TRANSLATION_DIRECTORY_NAME", "sourceData"),
        )

        verify_ssl = _get_storage_ssl_verify()
        blob_service_client = BlobServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        data_lake_client = DataLakeServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )

        source_url = _get_batch_translation_source_url_for_region(context)
        destination_url = _get_batch_translation_destination_url_for_region(context)

        if not source_url:
            source_container_name = _get_batch_translation_storage_setting_for_region(
                context, "BATCH_TRANSLATION_SOURCE_CONTAINER", "translator-source"
            )
            source_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{source_container_name}"
            )

        if not destination_url:
            destination_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{destination_container_name}"
            )

        source_prefix = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_SOURCE_PREFIX",
            "",
        ).strip().lstrip("/")
        if source_prefix and not source_prefix.endswith("/"):
            source_prefix = f"{source_prefix}/"

        source_entry = {
            "sourceUrl": source_url,
            "language": "en",
            "storageSource": "AzureBlob",
        }
        if source_prefix:
            source_entry["filter"] = {"prefix": source_prefix}

        _cleanup_ai_translator_destination_folder(
            blob_service_client=blob_service_client,
            data_lake_client=data_lake_client,
            destination_url=destination_url,
            fallback_container_name=destination_container_name,
            fallback_directory_name=destination_directory_name,
        )

        request_body = {
            "inputs": [
                {
                "source": source_entry,
                "targets": [
                    {
                    "targetUrl": destination_url,
                    "language": "fr",
                    "category": "general",
                    "storageSource": "AzureBlob"
                    }
                ],
                "storageType": "Folder"
                }
            ]
            }

    context.request_body = request_body

    masked_inputs = [
        {
            **entry,
            "source": {
                **entry.get("source", {}),
                "sourceUrl": _mask_sas_url(entry.get("source", {}).get("sourceUrl", "")),
            },
            "targets": [
                {
                    **target,
                    "targetUrl": _mask_sas_url(target.get("targetUrl", "")),
                }
                for target in entry.get("targets", [])
            ],
        }
        for entry in request_body.get("inputs", [])
    ]
    masked_request_body = {**request_body, "inputs": masked_inputs}

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

    source_url = ""
    target_url = ""
    if masked_inputs:
        source_url = masked_inputs[0].get("source", {}).get("sourceUrl", "")
        targets = masked_inputs[0].get("targets", [])
        if targets:
            target_url = targets[0].get("targetUrl", "")

    context.batch_translation_source_sas_url = source_url
    context.batch_translation_destination_sas_url = target_url

    print(f"[Batch Translation] Source SAS URL (masked): {source_url}")
    print(f"[Batch Translation] Destination SAS URL (masked): {target_url}")

    allure.attach(
        source_url,
        name="source_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        target_url,
        name="target_url",
        attachment_type=allure.attachment_type.TEXT,
    )

@given('I prepare a request body for batch translation with missing language parameter')
def step_impl(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        BlobServiceClient, DataLakeServiceClient = _load_ai_translator_storage_clients()

        account_connection_string = _get_batch_translation_connection_string_for_region(context)
        destination_container_name = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_DESTINATION_CONTAINER",
            "translator-destination",
        )
        destination_directory_name = _get_storage_setting(
            "BATCH_TRANSLATION_DESTINATION_DIRECTORY_NAME",
            _get_storage_setting("BATCH_TRANSLATION_DIRECTORY_NAME", "sourceData"),
        )

        verify_ssl = _get_storage_ssl_verify()
        blob_service_client = BlobServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        data_lake_client = DataLakeServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )

        source_url = _get_batch_translation_source_url_for_region(context)
        destination_url = _get_batch_translation_destination_url_for_region(context)

        if not source_url:
            source_container_name = _get_batch_translation_storage_setting_for_region(
                context, "BATCH_TRANSLATION_SOURCE_CONTAINER", "translator-source"
            )
            source_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{source_container_name}"
            )

        if not destination_url:
            destination_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{destination_container_name}"
            )

        source_prefix = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_SOURCE_PREFIX",
            "",
        ).strip().lstrip("/")
        if source_prefix and not source_prefix.endswith("/"):
            source_prefix = f"{source_prefix}/"

        source_entry = {
            "sourceUrl": source_url,
            "language": "",
            "storageSource": "AzureBlob",
        }
        if source_prefix:
            source_entry["filter"] = {"prefix": source_prefix}

        _cleanup_ai_translator_destination_folder(
            blob_service_client=blob_service_client,
            data_lake_client=data_lake_client,
            destination_url=destination_url,
            fallback_container_name=destination_container_name,
            fallback_directory_name=destination_directory_name,
        )

        request_body = {
            "inputs": [
                {
                "source": source_entry,
                "targets": [
                    {
                    "targetUrl": destination_url,
                    "language": "",
                    "category": "general",
                    "storageSource": "AzureBlob"
                    }
                ],
                "storageType": "Folder"
                }
            ]
            }

    context.request_body = request_body

    masked_inputs = [
        {
            **entry,
            "source": {
                **entry.get("source", {}),
                "sourceUrl": _mask_sas_url(entry.get("source", {}).get("sourceUrl", "")),
            },
            "targets": [
                {
                    **target,
                    "targetUrl": _mask_sas_url(target.get("targetUrl", "")),
                }
                for target in entry.get("targets", [])
            ],
        }
        for entry in request_body.get("inputs", [])
    ]
    masked_request_body = {**request_body, "inputs": masked_inputs}

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

    source_url = ""
    target_url = ""
    if masked_inputs:
        source_url = masked_inputs[0].get("source", {}).get("sourceUrl", "")
        targets = masked_inputs[0].get("targets", [])
        if targets:
            target_url = targets[0].get("targetUrl", "")

    context.batch_translation_source_sas_url = source_url
    context.batch_translation_destination_sas_url = target_url

    print(f"[Batch Translation] Source SAS URL (masked): {source_url}")
    print(f"[Batch Translation] Destination SAS URL (masked): {target_url}")

    allure.attach(
        source_url,
        name="source_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        target_url,
        name="target_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@given('I prepare a valid request body for batch translation without cleanup')
def step_impl(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        BlobServiceClient, DataLakeServiceClient = _load_ai_translator_storage_clients()

        account_connection_string = _get_batch_translation_connection_string_for_region(context)
        destination_container_name = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_DESTINATION_CONTAINER",
            "translator-destination",
        )
        destination_directory_name = _get_storage_setting(
            "BATCH_TRANSLATION_DESTINATION_DIRECTORY_NAME",
            _get_storage_setting("BATCH_TRANSLATION_DIRECTORY_NAME", "sourceData"),
        )

        verify_ssl = _get_storage_ssl_verify()
        blob_service_client = BlobServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        data_lake_client = DataLakeServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )

        source_url = _get_batch_translation_source_url_for_region(context)
        destination_url = _get_batch_translation_destination_url_for_region(context)

        if not source_url:
            source_container_name = _get_batch_translation_storage_setting_for_region(
                context, "BATCH_TRANSLATION_SOURCE_CONTAINER", "translator-source"
            )
            source_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{source_container_name}"
            )

        if not destination_url:
            destination_url = (
                f"https://{blob_service_client.account_name}.blob.core.windows.net/{destination_container_name}"
            )

        source_prefix = _get_batch_translation_storage_setting_for_region(
            context,
            "BATCH_TRANSLATION_SOURCE_PREFIX",
            "",
        ).strip().lstrip("/")
        if source_prefix and not source_prefix.endswith("/"):
            source_prefix = f"{source_prefix}/"

        source_entry = {
            "sourceUrl": source_url,
            "language": "en",
            "storageSource": "AzureBlob",
        }
        if source_prefix:
            source_entry["filter"] = {"prefix": source_prefix}

        request_body = {
            "inputs": [
                {
                "source": source_entry,
                "targets": [
                    {
                    "targetUrl": destination_url,
                    "category": "general",
                    "language": "fr",
                    "storageSource": "AzureBlob"
                    }
                ],
                "storageType": "Folder"
                }
            ]
            }

    context.request_body = request_body

    masked_inputs = [
        {
            **entry,
            "source": {
                **entry.get("source", {}),
                "sourceUrl": _mask_sas_url(entry.get("source", {}).get("sourceUrl", "")),
            },
            "targets": [
                {
                    **target,
                    "targetUrl": _mask_sas_url(target.get("targetUrl", "")),
                }
                for target in entry.get("targets", [])
            ],
        }
        for entry in request_body.get("inputs", [])
    ]
    masked_request_body = {**request_body, "inputs": masked_inputs}

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

    source_url = ""
    target_url = ""
    if masked_inputs:
        source_url = masked_inputs[0].get("source", {}).get("sourceUrl", "")
        targets = masked_inputs[0].get("targets", [])
        if targets:
            target_url = targets[0].get("targetUrl", "")

    context.batch_translation_source_sas_url = source_url
    context.batch_translation_destination_sas_url = target_url

    print(f"[Batch Translation] Source SAS URL (masked): {source_url}")
    print(f"[Batch Translation] Destination SAS URL (masked): {target_url}")

    allure.attach(
        source_url,
        name="source_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        target_url,
        name="target_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@given('I prepare an invalid request body for batch translation with missing source and target url')
def step_impl(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
            "inputs": [
                {
                    "source": {
                        "language": "en",
                        "storageSource": "AzureBlob",
                    },
                    "targets": [
                        {
                            "category": "general",
                            "language": "fr",
                            "storageSource": "AzureBlob"
                        }
                    ],
                    "storageType": "Folder"
                }
            ]
        }

    context.request_body = request_body

    masked_inputs = [
        {
            **entry,
            "source": {
                **entry.get("source", {}),
                "sourceUrl": _mask_sas_url(entry.get("source", {}).get("sourceUrl", "")),
            },
            "targets": [
                {
                    **target,
                    "targetUrl": _mask_sas_url(target.get("targetUrl", "")),
                }
                for target in entry.get("targets", [])
            ],
        }
        for entry in request_body.get("inputs", [])
    ]
    masked_request_body = {**request_body, "inputs": masked_inputs}

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

    source_url = ""
    target_url = ""
    if masked_inputs:
        source_url = masked_inputs[0].get("source", {}).get("sourceUrl", "")
        targets = masked_inputs[0].get("targets", [])
        if targets:
            target_url = targets[0].get("targetUrl", "")

    context.batch_translation_source_sas_url = source_url
    context.batch_translation_destination_sas_url = target_url

    print(f"[Batch Translation] Source SAS URL (masked): {source_url}")
    print(f"[Batch Translation] Destination SAS URL (masked): {target_url}")

    allure.attach(
        source_url,
        name="source_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        target_url,
        name="target_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the batch id from the response")
def step_store_batch_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing batch id."

    payload = {}
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    batch_id = payload.get("id") or payload.get("batchId")

    if not batch_id:
        operation_location = response.headers.get("Operation-Location") or response.headers.get("operation-location")
        if operation_location:
            batch_id = operation_location.split("?")[0].rstrip("/").split("/")[-1]

    assert batch_id, (
        "Could not find batch id in response. Expected 'id', 'batchId', or Operation-Location header. "
        f"Response body: {json.dumps(payload, indent=2) if payload else response.text[:500]}"
    )

    context.batch_id = batch_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        config_batch_ids_by_region = getattr(context.config, "batch_ids_by_region", {})
        config_batch_ids_by_region[region] = batch_id
        context.config.batch_ids_by_region = config_batch_ids_by_region

    context.config.batch_id = batch_id

    allure.attach(
        str(batch_id),
        name="batch_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store one document id from the response")
@then("I store one document id from the response with status as Succeeded")
def step_store_one_document_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing document id."

    payload = {}
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    documents = payload.get("value") if isinstance(payload, dict) else None
    assert isinstance(documents, list) and documents, (
        "Could not find documents list in response. Expected a non-empty 'value' array. "
        f"Response body: {json.dumps(payload, indent=2) if payload else response.text[:500]}"
    )

    succeeded_document = None
    for document in documents:
        if not isinstance(document, dict):
            continue
        status = str(document.get("status", "")).strip().lower()
        if status == "succeeded" and document.get("id"):
            succeeded_document = document
            break

    assert succeeded_document, (
        "Could not find a document with status 'Succeeded' and a valid 'id' in response. "
        f"Response body: {json.dumps(payload, indent=2) if payload else response.text[:500]}"
    )

    document_id = succeeded_document.get("id")
    assert document_id, (
        "Could not find document id in the selected document entry. Expected key 'id'. "
        f"Selected document: {json.dumps(succeeded_document, indent=2)}"
    )

    context.document_id = document_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        context_document_ids_by_region = getattr(context, "document_ids_by_region", {})
        context_document_ids_by_region[region] = document_id
        context.document_ids_by_region = context_document_ids_by_region

        config_document_ids_by_region = getattr(context.config, "document_ids_by_region", {})
        config_document_ids_by_region[region] = document_id
        context.config.document_ids_by_region = config_document_ids_by_region

    context.config.document_id = document_id

    allure.attach(
        str(document_id),
        name="document_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I verify the batch translation status in the response")
def step_verify_batch_translation_status_in_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before verifying batch translation status."

    payload = response.json()

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    expected_batch_id = None
    if region:
        expected_batch_id = getattr(context.config, "batch_ids_by_region", {}).get(region)
    if not expected_batch_id:
        expected_batch_id = getattr(context, "batch_id", None)
    if not expected_batch_id:
        expected_batch_id = getattr(context.config, "batch_id", None)

    expected_document_id = None
    if region:
        expected_document_id = getattr(context.config, "document_ids_by_region", {}).get(region)
    if not expected_document_id:
        expected_document_id = getattr(context, "document_id", None)
    if not expected_document_id:
        expected_document_id = getattr(context.config, "document_id", None)

    request_path = getattr(response.request, "path_url", "") or ""
    is_specific_document_status = "/documents/" in request_path

    actual_batch_id = None
    actual_document_id = None

    def _assert_ids(current_payload, current_request_path, during_polling=False):
        nonlocal actual_batch_id, actual_document_id

        endpoint_is_specific_document = "/documents/" in (current_request_path or "")
        current_batch_id = current_payload.get("batchId")

        if current_batch_id:
            assert expected_batch_id, (
                "No batch id available for verification. Run batch creation and store the batch id first."
            )
            actual_batch_id = current_batch_id
            poll_suffix = " during polling" if during_polling else ""
            assert str(actual_batch_id) == str(expected_batch_id), (
                f"Expected batch id '{expected_batch_id}' for region '{region}', got '{actual_batch_id}'{poll_suffix}."
            )
            return

        if endpoint_is_specific_document:
            current_document_id = current_payload.get("id") or current_payload.get("documentId")
            assert current_document_id, (
                f"Expected 'id' or 'documentId' in response body, got: {json.dumps(current_payload, indent=2)}"
            )
            assert expected_document_id, (
                "No document id available for verification. Run documents-list scenario and store one document id first."
            )
            actual_document_id = current_document_id
            poll_suffix = " during polling" if during_polling else ""
            assert str(actual_document_id) == str(expected_document_id), (
                f"Expected document id '{expected_document_id}' for region '{region}', got '{actual_document_id}'{poll_suffix}."
            )
            return

        current_batch_like_id = current_payload.get("id") or current_payload.get("batchId")
        assert current_batch_like_id, (
            f"Expected 'id' or 'batchId' in response body, got: {json.dumps(current_payload, indent=2)}"
        )
        assert expected_batch_id, (
            "No batch id available for verification. Run batch creation and store the batch id first."
        )
        actual_batch_id = current_batch_like_id
        poll_suffix = " during polling" if during_polling else ""
        assert str(actual_batch_id) == str(expected_batch_id), (
            f"Expected batch id '{expected_batch_id}' for region '{region}', got '{actual_batch_id}'{poll_suffix}."
        )

    _assert_ids(payload, request_path)

    status = payload.get("status")
    assert status, f"Expected 'status' in response body, got: {json.dumps(payload, indent=2)}"

    retry_endpoint = getattr(response.request, "path_url", None)
    assert retry_endpoint, "Could not resolve the batch status endpoint for polling."

    poll_interval_seconds = 30
    max_wait_seconds = 20 * 60
    waited_seconds = 0

    while status not in ("Succeeded", "Failed") and waited_seconds < max_wait_seconds:
        wait_message = (
            f"Batch status is '{status}'. Waiting {poll_interval_seconds} seconds before re-checking status."
        )
        print(wait_message)
        allure.attach(
            wait_message,
            name="batch_translation_status_wait",
            attachment_type=allure.attachment_type.TEXT,
        )
        time.sleep(poll_interval_seconds)
        waited_seconds += poll_interval_seconds

        retry_response = context.client.get(retry_endpoint, headers=getattr(context, "headers", {}))
        context.last_response = retry_response
        payload = retry_response.json()

        retry_request_path = getattr(retry_response.request, "path_url", retry_endpoint)
        _assert_ids(payload, retry_request_path, during_polling=True)

        status = payload.get("status")
        assert status, f"Expected 'status' in polling response body, got: {json.dumps(payload, indent=2)}"

    assert status != "Failed", (
        f"Batch translation status is 'Failed'. Response: {json.dumps(payload, indent=2)}"
    )
    assert status == "Succeeded", (
        f"Expected batch translation status 'Succeeded' within {max_wait_seconds} seconds, got '{status}'. "
        f"Response: {json.dumps(payload, indent=2)}"
    )

    source_url = getattr(context, "batch_translation_source_sas_url", "")
    destination_url = getattr(context, "batch_translation_destination_sas_url", "")
    if source_url:
        print(f"[Batch Translation Status] Source SAS URL (masked): {source_url}")
        allure.attach(
            source_url,
            name="status_source_url",
            attachment_type=allure.attachment_type.TEXT,
        )
    if destination_url:
        print(f"[Batch Translation Status] Destination SAS URL (masked): {destination_url}")
        allure.attach(
            destination_url,
            name="status_target_url",
            attachment_type=allure.attachment_type.TEXT,
        )

    allure.attach(
        json.dumps(
            {
                "region": region,
                "endpointType": "specific-document" if is_specific_document_status else "batch",
                "expectedBatchId": str(expected_batch_id),
                "actualBatchId": str(actual_batch_id),
                "expectedDocumentId": str(expected_document_id),
                "actualDocumentId": str(actual_document_id),
                "status": status,
            },
            indent=2,
        ),
        name="batch_translation_status_validation",
        attachment_type=allure.attachment_type.JSON,
    )
