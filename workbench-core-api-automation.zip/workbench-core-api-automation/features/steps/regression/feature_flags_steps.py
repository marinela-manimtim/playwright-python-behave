from __future__ import annotations

import json

import allure
from behave import given


@given("I prepare a valid request body for creating a feature flag")
def step_prepare_valid_feature_flag_request_body(context):
	if context.text:
		request_body = json.loads(context.text)
	else:
		request_body = {"groupName": "testgroupone", "retention": 30}

	context.request_body = request_body

	allure.attach(
		json.dumps(request_body, indent=2),
		name="request_body",
		attachment_type=allure.attachment_type.JSON,
	)
