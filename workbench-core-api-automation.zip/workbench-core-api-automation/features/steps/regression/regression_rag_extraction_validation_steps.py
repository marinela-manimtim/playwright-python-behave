# ============================================================
# RAG Extraction Validation Regression - Step Definitions
# ============================================================

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import allure
from azure.storage.blob import BlobSasPermissions, BlobServiceClient, generate_blob_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()

# ============================================================
# Storage Context
# ============================================================

_extraction_validation_store: dict = {}


def _store(context, **kwargs) -> None:
    """Save key/value pairs into the region-specific slot of _extraction_validation_store."""
    region = getattr(context, "region", None) or "default"
    _extraction_validation_store.setdefault(region, {}).update(kwargs)


def _restore(context, region: str, *keys) -> None:
    """Restore key/value pairs from the region-specific slot."""
    data = _extraction_validation_store.get(region, {})
    for key in keys:
        setattr(context, key, data.get(key))


# ============================================================
# Helper Functions
# ============================================================


def _storage_account_name_for_region(region: str) -> str:
    """Map test region to its regression source storage account."""
    mapping = {
        "eastus": "dlsapimregwbameruseqa",
        "australiaeast": "dlsapimregwbapacaueqa",
        "westeurope": "dlsapimregwbemeaweuqa",
    }
    account_name = mapping.get(region)
    assert account_name, f"No storage account mapping configured for region '{region}'."
    return account_name


def generate_reg_source_sas_uri(storage_account_name: str) -> str:
    """Build a blob-level SAS URI for the first file under reg-source/sourceData and return URI."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }

    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"

    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."

    container_name = "reg-source"
    container_client = blob_service_client.get_container_client(container_name)
    
    # List all blobs and find HandWrittentext.jpg (case-insensitive search)
    blob_name = None
    for blob in container_client.list_blobs():
        if blob.name.lower() == "handwrittentext.jpg":
            blob_name = blob.name
            break
    
    assert blob_name is not None, (
        f"Blob 'HandWrittentext.jpg' not found in container '{container_name}'. "
        f"Available blobs: {[b.name for b in container_client.list_blobs()]}"
    )
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True, add=True, create=True, write=True, delete=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )

    encoded_blob_name = quote(blob_name, safe="/")
    return f"https://{account_name}.blob.core.windows.net/{container_name}/{encoded_blob_name}?{sas_token}"


def _configure_client(context, region: str, timeout: int | None = None) -> None:
    """Configure API client and common headers."""
    context.region = region
    context.client = Service(
        region,
        timeout=timeout,
        use_implicit_auth=getattr(context, "use_implicit_auth", False),
    )
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _get_json_response(context, allow_empty: bool = False) -> dict | list:
    """Parse and attach JSON response for diagnostics."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    response_text = (response.text or "").strip()
    if allow_empty and not response_text:
        allure.attach(
            "N/A",
            name="response_body",
            attachment_type=allure.attachment_type.TEXT,
        )
        return {}

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _attach_request_details(context, request_body: dict | None = None) -> None:
    """Attach request URL and request body for consistent Allure diagnostics."""
    allure.attach(
        getattr(context, "request_url", "N/A") or "N/A",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(request_body, indent=2) if request_body is not None else "N/A",
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


# ============================================================
# SCENARIO 1 - Create Validation Report
# ============================================================


@given('the Extraction Validation API client is configured with region "{region}"')
def setup_extraction_validation_client(context, region):
    _configure_client(context, region, timeout=120)
    context.storage_account_name = _storage_account_name_for_region(region)


@when('I create a validation report with storage account "{storage_account_name}"')
def create_validation_report(context, storage_account_name):
    endpoint = "/extraction/validation/validationReports/"
    sas_uri = generate_reg_source_sas_uri(context.storage_account_name)
    request_body = {
        "urlSource": sas_uri,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.validation_payload = _get_json_response(context)


@then("the validation report should be created successfully and report id should be saved")
def verify_validation_report_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "validation_payload", None) or _get_json_response(context)
    
    # Extract report ID from response - adjust field name based on actual API response
    report_id = payload.get("reportId") or payload.get("id") or payload.get("validationReportId")
    assert report_id, f"No report ID found in response: {payload}"
    
    context.report_id = report_id
    _store(context, report_id=report_id)
    allure.attach(str(context.report_id), name="report_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 2 - Get Validation Report
# ============================================================


@given('the Extraction Validation API client is configured with region "{region}" and report id from previous scenario')
def setup_extraction_validation_client_with_report(context, region):
    _configure_client(context, region)
    _restore(context, region, "report_id")
    assert getattr(context, "report_id", None), (
        "report_id is missing — Scenario 1 (Create Validation Report) must pass before this step."
    )


@when("I get the validation report by id")
def get_validation_report(context):
    endpoint = f"/extraction/validation/validationReports/{context.report_id}"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.get_validation_payload = _get_json_response(context)


@then("the validation report should be retrieved successfully")
def verify_validation_report_retrieved(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "get_validation_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected validation report response payload to be a JSON object or array."


# ============================================================
# SCENARIO 3 - Create Validation Report with missing urlSource
# ============================================================


@given('the Extraction Validation blank urlSource client is configured with region "{region}"')
def setup_extraction_validation_blank_url_source_client(context, region):
    _configure_client(context, region, timeout=120)


@when("I create a validation report with blank urlSource")
def create_validation_report_with_blank_url_source(context):
    endpoint = "/extraction/validation/validationReports/"
    request_body = {
        "urlSource": "",
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.blank_url_source_validation_payload = _get_json_response(context, allow_empty=True)


@then("the validation report blank urlSource request should be created successfully and report id should be saved")
def verify_validation_report_blank_url_source_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "blank_url_source_validation_payload", None) or _get_json_response(context, allow_empty=True)
    assert isinstance(payload, dict), "Expected blank urlSource response payload to be a JSON object."

    report_id = payload.get("reportId") or payload.get("id") or payload.get("validationReportId")
    assert report_id, f"No report ID found in response: {payload}"

    context.report_id = report_id
    _store(context, report_id=report_id)
    allure.attach(str(context.report_id), name="report_id", attachment_type=allure.attachment_type.TEXT)


@then('the validation report for blank urlSource should fail with status 404 and message "No report found for given validation id. Please check the validation id and try again."')
def verify_validation_report_blank_url_source_get_failure(context):
    assert context.last_status_code == 404, f"Expected HTTP 404 but got {context.last_status_code}"
    payload = getattr(context, "get_validation_payload", None) or _get_json_response(context, allow_empty=True)
    assert isinstance(payload, dict), "Expected get-validation response payload to be a JSON object."

    expected_message = "No report found for given validation id. Please check the validation id and try again."
    error_message = ""
    error_node = payload.get("error")
    if isinstance(error_node, dict):
        error_message = str(error_node.get("message") or "").strip()
    if not error_message:
        error_message = str(payload.get("message") or "").strip()

    assert error_message == expected_message, (
        f"Expected error message '{expected_message}' but got '{error_message}'. Full payload: {payload}"
    )
