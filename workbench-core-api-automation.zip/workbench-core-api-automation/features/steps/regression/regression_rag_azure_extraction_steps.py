# ============================================================
# RAG Azure Extraction Regression — Step Definitions
# ============================================================
# Covers the core extraction workflow:
#   1. List Models
#   2. Get Model
#   3. Analyze Document
#   4. Get Analyze Result
#   5. Analyze Document with invalid modelId
# ============================================================

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import quote, urlparse

import allure
from azure.storage.blob import BlobSasPermissions, BlobServiceClient, generate_blob_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

API_VERSION = "2024-11-30"

load_dotenv()

# Module-level store keyed by region — persists across all scenarios for the entire test run.
_rag_azure_extraction_store: dict = {}


def _store(context, **kwargs) -> None:
    """Save key/value pairs into the region-specific slot of _rag_azure_extraction_store."""
    region = context.headers.get("x-kpmg-region-override", "unknown")
    _rag_azure_extraction_store.setdefault(region, {}).update(kwargs)


def _restore(context, region, *keys) -> None:
    """Load stored values for a region back into context."""
    data = _rag_azure_extraction_store.get(region, {})
    for key in keys:
        setattr(context, key, data.get(key))


def _configure_client(context, region: str) -> None:
    """Configure client and headers aligned with AI Search header conventions."""
    context.client = Service(region, use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _get_json_response(context, allow_empty: bool = False) -> dict:
    """Parse and attach the last JSON response for diagnostics."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    response_text = (response.text or "").strip()
    if allow_empty and not response_text:
        allure.attach(
            "N/A",
            name="response_body",
            attachment_type=allure.attachment_type.TEXT,
        )
        return {}

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _attach_request_details(context, request_body: dict | None = None) -> None:
    """Attach request URL and body for consistent Allure diagnostics."""
    allure.attach(
        getattr(context, "request_url", "N/A") or "N/A",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(request_body, indent=2) if request_body is not None else "N/A",
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


def generate_reg_source_sas_uri(storage_account_name: str) -> str:
    """Build a blob-level SAS URI for the first file found under reg-source/sourceData."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }

    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"

    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."

    container_name = "reg-source"
    directory_name = "sourceData"
    container_client = blob_service_client.get_container_client(container_name)
    candidate_blob = next(
        (
            blob
            for blob in container_client.list_blobs(name_starts_with=f"{directory_name}/")
            if getattr(blob, "name", "") and not str(blob.name).endswith("/")
        ),
        None,
    )
    assert candidate_blob is not None, (
        f"No files found under {container_name}/{directory_name} for storage account {storage_account_name}."
    )

    blob_name = candidate_blob.name if hasattr(candidate_blob, "name") else str(candidate_blob)
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True, add=True, create=True, write=True, delete=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )

    encoded_blob_name = quote(blob_name, safe="/")
    return f"https://{account_name}.blob.core.windows.net/{container_name}/{encoded_blob_name}?{sas_token}"


# ============================================================
# SCENARIO 1 — List Models
# ============================================================


@given('the API client for RAG Azure Extraction list models is configured with region "{region}"')
def setup_rag_azure_extraction_list_models_client(context, region):
    # Set up the API client so we can talk to the right region.
    _configure_client(context, region)
    _restore(context, region, "model_id", "analyze_result_id")


@when("I list RAG Azure Extraction models")
def list_rag_azure_extraction_models(context):
    # Send a request to list available extraction models
    endpoint = "/extraction/azure/documentintelligence/documentModels/"
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = _get_json_response(context)
    model_id = payload["value"][0]["modelId"]

    context.models_payload = payload
    context.model_id = model_id
    _store(context, models_payload=payload, model_id=model_id)
    allure.attach(model_id, name="first_model_id", attachment_type=allure.attachment_type.TEXT)


@then("the RAG Azure Extraction models should be listed successfully")
def verify_list_models_success(context):
    # Check the response: HTTP 200 means success and models list should be present
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "models_payload", None) or _get_json_response(context)
    assert isinstance(payload.get("value"), list), "Expected 'value' list in response payload."
    assert len(payload["value"]) > 0, "Expected at least one model in response payload."
    assert getattr(context, "model_id", None), "First modelId was not found in list-models response."


# ============================================================
# SCENARIO 2 — Get Model
# ============================================================


@given('the API client for RAG Azure Extraction get model is configured with region "{region}"')
def setup_rag_azure_extraction_get_model_client(context, region):
    # Set up the API client for fetching model details by id.
    _configure_client(context, region)
    _restore(context, region, "model_id", "analyze_result_id")


@when("I get the first listed RAG Azure Extraction model")
def get_rag_azure_extraction_model(context):
    # Send a request to fetch model details by model id
    model_id = getattr(context, "model_id", None)
    assert model_id, (
        "model_id is missing — run List Models scenario first for this region."
    )
    endpoint = f"/extraction/azure/documentintelligence/documentModels/{model_id}"
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = _get_json_response(context)
    context.model_payload = payload
    _store(context, model_id=model_id)


@then("the RAG Azure Extraction model should be fetched successfully")
def verify_get_model_success(context):
    # Check the response: HTTP 200 means model was fetched successfully
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "model_payload", None) or _get_json_response(context)
    model_name = payload.get("modelId") or payload.get("id")
    assert model_name, "Expected model identifier in response payload."
    expected_model_id = getattr(context, "model_id", None)
    if expected_model_id:
        assert model_name == expected_model_id, (
            f"Expected model '{expected_model_id}' but got '{model_name}'."
        )


# ============================================================
# SCENARIO 3 — Analyze Document
# ============================================================


@given('the API client for RAG Azure Extraction analyze document is configured with region "{region}"')
def setup_rag_azure_extraction_analyze_document_client(context, region):
    # Set up the API client for starting document analyze requests.
    _configure_client(context, region)
    _restore(context, region, "model_id", "analyze_result_id")


@when('I analyze a document using the first listed RAG Azure Extraction model with storage account "{storage_account_name}"')
def analyze_document_rag_azure_extraction(context, storage_account_name):
    # Send a request to start document analysis for the selected model
    model_id = getattr(context, "model_id", None)
    assert model_id, (
        "model_id is missing — run List Models scenario first for this region."
    )
    sas_uri = generate_reg_source_sas_uri(storage_account_name)
    endpoint = f"/extraction/azure/documentintelligence/documentModels/{model_id}:analyze"
    context.request_params = {
        "api-version": API_VERSION,
        "_overload": "analyzeDocument",
    }
    request_body = {"urlSource": sas_uri}
    context.request_url = (
        context.client.base_url
        + f"{endpoint}?api-version={API_VERSION}&_overload=analyzeDocument"
    )
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    payload = _get_json_response(context, allow_empty=True)

    operation_location = (
        context.last_response.headers.get("Operation-Location")
        or context.last_response.headers.get("operation-location")
    )
    analyze_result_id = None
    if operation_location:
        parsed_path = urlparse(operation_location).path.strip("/")
        path_parts = parsed_path.split("/") if parsed_path else []
        if "analyzeResults" in path_parts:
            analyze_index = path_parts.index("analyzeResults")
            if analyze_index + 1 < len(path_parts):
                analyze_result_id = path_parts[analyze_index + 1]

    if not analyze_result_id:
        analyze_result_id = (
            payload.get("resultId")
            or payload.get("analyzeResultId")
            or payload.get("id")
        )

    context.analyze_result_id = analyze_result_id
    _store(context, model_id=model_id, analyze_result_id=analyze_result_id)

@then("the RAG Azure Extraction analyze request should be accepted and analyze result id should be saved")
def verify_analyze_document_success(context):
    # Check the response: HTTP 200/202 and an analyze result id is required for polling
    assert context.last_status_code in (200, 202), (
        f"Expected HTTP 200/202 but got {context.last_status_code}"
    )
    assert getattr(context, "analyze_result_id", None), (
        "analyze_result_id was not returned in the response."
    )


# ============================================================
# SCENARIO 4 — Get Analyze Result
# ============================================================


@given('the RAG Azure Extraction analyze request is started in region "{region}"')
def setup_client_with_analyze_request(context, region):
    # Restore the region-specific analyze_result_id created in Scenario 3
    _configure_client(context, region)
    _restore(context, region, "model_id", "analyze_result_id")
    assert getattr(context, "model_id", None), (
        "model_id is missing — run List Models scenario first for this region."
    )
    assert getattr(context, "analyze_result_id", None), (
        "analyze_result_id is missing — run Analyze Document scenario first for this region."
    )


@when("I get the RAG Azure Extraction analyze result for the first listed model")
def get_rag_azure_extraction_analyze_result(context):
    # Poll every 5 seconds until the analyze result reaches a terminal state or times out.
    model_id = getattr(context, "model_id", None)
    assert model_id, (
        "model_id is missing — run List Models scenario first for this region."
    )
    endpoint = (
        f"/extraction/azure/documentintelligence/documentModels/{model_id}"
        f"/analyzeResults/{context.analyze_result_id}"
    )
    context.request_params = {"api-version": API_VERSION}
    context.request_url = context.client.base_url + f"{endpoint}?api-version={API_VERSION}"
    _attach_request_details(context)
    poll_interval_seconds = 5
    timeout_seconds = 600
    max_attempts = timeout_seconds // poll_interval_seconds
    terminal_error_statuses = {"failed", "cancelled", "canceled"}
    status = ""

    for attempt in range(max_attempts):
        context.last_response = context.client.get(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        context.analyze_result_payload = _get_json_response(context)
        status = str(context.analyze_result_payload.get("status", "")).lower()

        allure.attach(
            f"Attempt {attempt + 1}/{max_attempts} - Status: {status or 'unknown'}",
            name="analyze_result_poll",
            attachment_type=allure.attachment_type.TEXT,
        )

        if status == "succeeded":
            return

        if status in terminal_error_statuses:
            raise AssertionError(
                f"Analyze result reached terminal status '{status}' before succeeding."
            )

        if attempt < max_attempts - 1:
            time.sleep(poll_interval_seconds)

    raise AssertionError(
        f"Analyze result did not reach 'succeeded' after {max_attempts} attempts "
        f"({timeout_seconds}s). Last status: {status or 'unknown'}"
    )


@then("the RAG Azure Extraction analyze result should be fetched successfully")
def verify_get_analyze_result_success(context):
    # Check the response: polling should stop only after a successful terminal status.
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "analyze_result_payload", None) or _get_json_response(context)
    status = str(payload.get("status", "")).lower()
    assert status, "Expected analyze result payload to include status."
    assert status == "succeeded", f"Expected analyze result status 'succeeded' but got '{status}'."


# ============================================================
# SCENARIO 5 — Analyze Document with invalid modelId
# ============================================================


@given('the API client for RAG Azure Extraction invalid model analyze document is configured with region "{region}"')
def setup_rag_azure_extraction_invalid_model_client(context, region):
    # Set up the API client for invalid-model negative test flow.
    _configure_client(context, region)
    _restore(context, region, "model_id", "analyze_result_id")


@when('I analyze a document using an invalid RAG Azure Extraction modelId "{model_id}" with storage account "{storage_account_name}"')
def analyze_document_rag_azure_extraction_invalid_model(context, model_id, storage_account_name):
    # Send the same request body as the normal analyze flow, but force an invalid model id.
    sas_uri = generate_reg_source_sas_uri(storage_account_name)
    endpoint = f"/extraction/azure/documentintelligence/documentModels/{model_id}:analyze"
    context.request_params = {
        "api-version": API_VERSION,
        "_overload": "analyzeDocument",
    }
    request_body = {"urlSource": sas_uri}
    context.request_url = (
        context.client.base_url
        + f"{endpoint}?api-version={API_VERSION}&_overload=analyzeDocument"
    )
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_analyze_model_payload = _get_json_response(context)


@then("the RAG Azure Extraction invalid model analyze response should contain validation details")
def verify_analyze_document_invalid_model_error(context):
    assert context.last_status_code == 404, f"Expected HTTP 404 but got {context.last_status_code}"
    payload = getattr(context, "invalid_analyze_model_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected validation error response payload to be a JSON object."

    error_node = payload.get("error")
    if isinstance(error_node, dict):
        error_message = error_node.get("message") or error_node.get("code")
    else:
        error_message = payload.get("message") or payload.get("code")

    assert error_message, (
        f"Expected an error payload for invalid model id, but got: {payload}"
    )
