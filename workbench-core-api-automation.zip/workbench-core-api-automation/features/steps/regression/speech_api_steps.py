from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone

import allure
from behave import given, then, when
from dotenv import load_dotenv
from features.steps.regression.blob_data_transfer_steps import (
    _get_connection_string_for_region,
    _get_storage_setting,
    _get_storage_ssl_verify,
    _load_azure_storage_clients,
    _mask_sas_url,
)


def _resolve_context_region(context) -> str | None:
    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        return region

    region = getattr(context, "current_region", None)
    if region:
        return region

    client = getattr(context, "client", None)
    return getattr(client, "region", None)



@given("I prepare a valid request body for submitting text to speech")
def step_impl(context):

    if context.text:
        request_body = context.text
    else:
        request_body = (
            '<speak version="1.0" xml:lang="en-US">\n'
            '    <voice xml:lang="en-US" xml:gender="Male" name="en-US-ChristopherNeural">\n'
            "        I'm excited to try text to speech!\n"
            '    </voice>\n'
            '</speak>'
        )
    context.request_body = request_body
    context.content_type = "application/ssml+xml"

    allure.attach(
        request_body,
        name="request_body",
        attachment_type=allure.attachment_type.XML,
    )

@given("I prepare a valid request body for creating a batch synthesis job")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
    "inputKind": "SSML",
    "synthesisConfig": {
        "voice": "en-US-AvaMultilingualNeural"
    },
    "inputs": [
        {
            "content": "<speak version=\"1.0\" xml:lang=\"en-US\"><voice name=\"en-US-JennyNeural\">Aaj apka din shubh ho</voice></speak>"
        }
    ],
    "properties": {
        "outputFormat": "audio-24khz-160kbitrate-mono-mp3",
        "wordBoundaryEnabled": True,
        "sentenceBoundaryEnabled": True
    }
}

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given("I prepare a valid request body for submitting a transcription job")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        BlobServiceClient, ContainerSasPermissions, generate_container_sas, _, _, _ = _load_azure_storage_clients()

        account_connection_string = _get_connection_string_for_region(context)
        source_container_name = _get_storage_setting("SPEECH_TRANSCRIPTION_SOURCE_CONTAINER", "reg-source")
        source_blob_name = _get_storage_setting("SPEECH_TRANSCRIPTION_SOURCE_BLOB", "whatstheweatherlike.wav")

        verify_ssl = _get_storage_ssl_verify()
        blob_service_client = BlobServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        account_name = blob_service_client.account_name
        account_key = getattr(blob_service_client.credential, "account_key", None)

        assert account_key, (
            "AZURE_STORAGE_CONNECTION_STRING must contain an account key so SAS tokens can be generated."
        )

        expiry = datetime.now(timezone.utc) + timedelta(hours=1)
        source_sas_token = generate_container_sas(
            account_name=account_name,
            container_name=source_container_name,
            account_key=account_key,
            permission=ContainerSasPermissions(read=True, list=True),
            expiry=expiry,
        )
        source_audio_url = (
            f"https://{account_name}.blob.core.windows.net/"
            f"{source_container_name}/{source_blob_name}?{source_sas_token}"
        )

        request_body = {
  "displayName": "Transscription job - 1",
  "description": "My First transcription job",
  "customProperties": {},
  "locale": "en-US",
  "contentUrls": [
    source_audio_url
  ],
  "properties": {
    "timeToLiveHours": 48,
    "languageIdentification": {
      "candidateLocales": [
        "en-US",
        "de-DE",
        "es-ES"
      ]
    }
  }
}

    context.request_body = request_body

    masked_request_body = dict(request_body)
    masked_request_body["contentUrls"] = [
        _mask_sas_url(url) for url in request_body.get("contentUrls", [])
    ]

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given("I prepare a valid request body for synchronous transcription of an audio file")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "displayName": "Synchronous transcription job - 1",
  "description": "My First synchronous transcription job",
  "customProperties": {},
  "locale": "en-US",
  "contentUrls": [
    "https://dlsapimregwbapacaueqa.blob.core.windows.net/speech-test/3mb_wav_file.wav"
  ],
  "properties": {
    "timeToLiveHours": 48,
    "languageIdentification": {
      "candidateLocales": [
        "en-US",
        "de-DE",
        "es-ES"
      ]
    }
  }
}

    context.request_body = request_body
    context.multipart_form_data = {
        key: json.dumps(value) if isinstance(value, (dict, list)) else str(value)
        for key, value in request_body.items()
    }
    context.content_type = None

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for updating the mutable details of the transcription identified by its ID")
def step_prepare_update_transcription_request_body(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "displayName": "My Updated transcription job-1",
  "description": "My updated first transcription job",
  "customProperties": {}
}

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I generate a unique batch synthesis job id")
def step_generate_batch_synthesis_id(context):
    """Generate a unique UUID for the batch synthesis job and store it in context."""
    batch_synthesis_id = str(uuid.uuid4())
    context.batch_synthesis_id = batch_synthesis_id
    
    allure.attach(
        batch_synthesis_id,
        name="batch_synthesis_id",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"[Speech API] Generated batch synthesis job ID: {batch_synthesis_id}")


@given("I have a valid batch synthesis job id stored from the previous scenario outline")
def step_have_valid_batch_synthesis_job_id_from_previous_scenario(context):
    region = _resolve_context_region(context)

    batch_synthesis_job_id = None
    if region:
        batch_synthesis_job_id = getattr(
            context.config,
            "batch_synthesis_job_ids_by_region",
            {},
        ).get(region)

    if not batch_synthesis_job_id:
        batch_synthesis_job_id = getattr(context, "batch_synthesis_job_id", None)
    if not batch_synthesis_job_id:
        batch_synthesis_job_id = getattr(context.config, "batch_synthesis_job_id", None)

    assert batch_synthesis_job_id, (
        "No batch synthesis job id available for this scenario. "
        "Run the batch synthesis creation scenario first and store the id from the response."
    )

    context.batch_synthesis_job_id = batch_synthesis_job_id
    context.batch_synthesis_id = batch_synthesis_job_id

    allure.attach(
        str(batch_synthesis_job_id),
        name="resolved_batch_synthesis_job_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the batch synthesis job id from the response")
def step_store_batch_synthesis_job_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, (
        "No response found. Ensure a request step ran before storing batch synthesis job id."
    )

    payload = {}
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    batch_synthesis_job_id = (
        payload.get("id")
        or payload.get("batchSynthesisId")
        or payload.get("jobId")
    )

    if not batch_synthesis_job_id:
        operation_location = (
            response.headers.get("Operation-Location")
            or response.headers.get("operation-location")
        )
        if operation_location:
            batch_synthesis_job_id = operation_location.split("?")[0].rstrip("/").split("/")[-1]

    assert batch_synthesis_job_id, (
        "Could not find batch synthesis job id in response. Expected 'id', 'batchSynthesisId', "
        "'jobId', or Operation-Location header. "
        f"Response body: {json.dumps(payload, indent=2) if payload else response.text[:500]}"
    )

    context.batch_synthesis_job_id = batch_synthesis_job_id
    context.batch_synthesis_id = batch_synthesis_job_id

    region = _resolve_context_region(context)
    if region:
        batch_ids_by_region = getattr(context.config, "batch_synthesis_job_ids_by_region", {})
        batch_ids_by_region[region] = batch_synthesis_job_id
        context.config.batch_synthesis_job_ids_by_region = batch_ids_by_region

    context.config.batch_synthesis_job_id = batch_synthesis_job_id

    allure.attach(
        str(batch_synthesis_job_id),
        name="batch_synthesis_job_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the transcription job id from the response")
def step_store_transcription_job_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, (
        "No response found. Ensure a request step ran before storing transcription job id."
    )

    payload = {}
    try:
        payload = response.json()
    except ValueError:
        payload = {}

    transcription_job_id = (
        payload.get("id")
        or payload.get("transcriptionJobId")
        or payload.get("jobId")
    )

    if not transcription_job_id:
        self_url = payload.get("self")
        if isinstance(self_url, str) and "/transcriptions/" in self_url:
            transcription_segment = self_url.split("/transcriptions/", 1)[1]
            transcription_job_id = (
                transcription_segment.split("?", 1)[0].split("/", 1)[0].strip()
            )

    if not transcription_job_id:
        operation_location = (
            response.headers.get("Operation-Location")
            or response.headers.get("operation-location")
        )
        if operation_location:
            transcription_job_id = operation_location.split("?")[0].rstrip("/").split("/")[-1]

    assert transcription_job_id, (
        "Could not find transcription job id in response. Expected 'id', 'transcriptionJobId', "
        "'jobId', 'self' URL, or Operation-Location header. "
        f"Response body: {json.dumps(payload, indent=2) if payload else response.text[:500]}"
    )

    region = _resolve_context_region(context)
    if region:
        transcription_ids_by_region = getattr(context.config, "transcription_job_ids_by_region", {})
        transcription_ids_by_region[region] = transcription_job_id
        context.config.transcription_job_ids_by_region = transcription_ids_by_region

    context.config.transcription_job_id = transcription_job_id

    allure.attach(
        str(transcription_job_id),
        name="transcription_job_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@given("I have a valid transcription job id stored from the previous scenario outline")
def step_have_valid_transcription_job_id_from_previous_scenario(context):
    region = _resolve_context_region(context)

    transcription_job_id = None
    if region:
        transcription_job_id = getattr(
            context.config,
            "transcription_job_ids_by_region",
            {},
        ).get(region)

    if not transcription_job_id:
        transcription_job_id = getattr(context.config, "transcription_job_id", None)

    assert transcription_job_id, (
        "No transcription job id available for this scenario. "
        "Run the transcription submit scenario first and store the id from the response."
    )

    context.transcription_job_id = transcription_job_id

    allure.attach(
        str(transcription_job_id),
        name="resolved_transcription_job_id",
        attachment_type=allure.attachment_type.TEXT,
    )
