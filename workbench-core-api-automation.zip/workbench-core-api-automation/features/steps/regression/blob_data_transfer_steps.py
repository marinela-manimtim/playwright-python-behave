from __future__ import annotations

import json
import importlib
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import allure
from behave import given, then, when
from dotenv import load_dotenv


load_dotenv(Path(__file__).resolve().parents[3] / ".env")


def _safe_json(response) -> str:
    try:
        return json.dumps(response.json(), indent=2)
    except Exception:
        return response.text or "(empty response body)"


def _mask_sas_url(url: str) -> str:
    if "?" not in url:
        return url
    base, _, _query = url.partition("?")
    return f"{base}?<redacted>"


def _get_storage_setting(name: str, default: str | None = None) -> str:
    value = os.getenv(name, default)
    if value is None or not str(value).strip():
        raise AssertionError(
            f"Required environment variable '{name}' is not set for blob data transfer smoke tests."
        )
    return str(value).strip()


def _parse_bool(value: str | None, default: bool = True) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _get_storage_ssl_verify() -> bool:
    transfer_override = os.getenv("DATA_TRANSFER_IGNORE_SSL_VERIFY")
    if transfer_override is not None:
        ignore_ssl = _parse_bool(transfer_override, default=False)
    else:
        ignore_ssl = _parse_bool(os.getenv("IGNORE_SSL_VERIFY"), default=False)
    return not ignore_ssl


def _get_region_for_storage(context) -> str:
    headers = getattr(context, "headers", {}) or {}
    region = headers.get("x-kpmg-region-override", "")
    return str(region).strip().lower()


def _get_connection_string_for_region(context) -> str:
    region = _get_region_for_storage(context)

    region_prefix_map = {
        "eastus": "AMER",
        "westeurope": "EMEA",
        "australiaeast": "ASPAC",
    }

    candidates: list[str] = []
    if region:
        normalized_region = region.replace("-", "_").upper()
        candidates.append(f"AZURE_STORAGE_CONNECTION_STRING_{normalized_region}")

        mapped_prefix = region_prefix_map.get(region)
        if mapped_prefix:
            candidates.append(f"AZURE_STORAGE_CONNECTION_STRING_{mapped_prefix}")

    candidates.append("AZURE_STORAGE_CONNECTION_STRING")

    for env_var_name in candidates:
        raw_value = os.getenv(env_var_name)
        if not raw_value or not raw_value.strip():
            continue

        raw_value = raw_value.strip()
        if env_var_name == "AZURE_STORAGE_CONNECTION_STRING":
            try:
                parsed = json.loads(raw_value)
            except json.JSONDecodeError:
                return raw_value

            if isinstance(parsed, dict):
                region_keys = [region, region.replace("-", "_"), region_prefix_map.get(region, "").lower()]
                for key in region_keys:
                    if key and parsed.get(key):
                        return str(parsed[key]).strip()

                available_keys = ", ".join(sorted(parsed.keys()))
                raise AssertionError(
                    f"AZURE_STORAGE_CONNECTION_STRING is a JSON object but no key matches region '{region}'. "
                    f"Available keys: {available_keys}"
                )

        return raw_value

    resolved_candidates = ", ".join(candidates)
    raise AssertionError(
        "Missing Azure Storage connection string for blob data transfer test. "
        f"Checked env vars: {resolved_candidates}."
    )


def _load_azure_storage_clients():
    blob_module = importlib.import_module("azure.storage.blob")
    datalake_module = importlib.import_module("azure.storage.filedatalake")
    exceptions_module = importlib.import_module("azure.core.exceptions")
    return (
        blob_module.BlobServiceClient,
        blob_module.ContainerSasPermissions,
        blob_module.generate_container_sas,
        datalake_module.DataLakeServiceClient,
        exceptions_module.HttpResponseError,
        exceptions_module.ServiceRequestError,
    )


def _cleanup_destination_path(
    blob_service_client,
    data_lake_client,
    destination_container_name: str,
    directory_name: str,
) -> None:
    try:
        destination_file_system = data_lake_client.get_file_system_client(destination_container_name)
        destination_directory = destination_file_system.get_directory_client(directory_name)
        if destination_directory.exists():
            destination_file_system.delete_directory(directory_name)
        return
    except Exception as ex:  # noqa: BLE001
        allure.attach(
            str(ex),
            name="destination_cleanup_datalake_warning",
            attachment_type=allure.attachment_type.TEXT,
        )

    try:
        container_client = blob_service_client.get_container_client(destination_container_name)
        blob_names = [
            blob.name
            for blob in container_client.list_blobs(name_starts_with=f"{directory_name}/")
        ]
        if blob_names:
            container_client.delete_blobs(*blob_names)
    except Exception as ex:  # noqa: BLE001
        allure.attach(
            str(ex),
            name="destination_cleanup_blob_warning",
            attachment_type=allure.attachment_type.TEXT,
        )

@given('I prepare a valid payload for creating a data transfer job')
def step_impl(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        BlobServiceClient, ContainerSasPermissions, generate_container_sas, DataLakeServiceClient, _, _ = _load_azure_storage_clients()

        account_connection_string = _get_connection_string_for_region(context)
        source_container_name = _get_storage_setting("DATA_TRANSFER_SOURCE_CONTAINER", "reg-source")
        destination_container_name = _get_storage_setting("DATA_TRANSFER_DESTINATION_CONTAINER", "reg-destination")
        directory_name = _get_storage_setting("DATA_TRANSFER_DIRECTORY_NAME", "sourceData")

        verify_ssl = _get_storage_ssl_verify()
        blob_service_client = BlobServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        data_lake_client = DataLakeServiceClient.from_connection_string(
            account_connection_string,
            connection_verify=verify_ssl,
        )
        account_name = blob_service_client.account_name
        account_key = getattr(blob_service_client.credential, "account_key", None)

        assert account_key, (
            "AZURE_STORAGE_CONNECTION_STRING must contain an account key so container SAS tokens can be generated."
        )

        _cleanup_destination_path(
            blob_service_client=blob_service_client,
            data_lake_client=data_lake_client,
            destination_container_name=destination_container_name,
            directory_name=directory_name,
        )

        expiry = datetime.now(timezone.utc) + timedelta(hours=1)
        source_sas_token = generate_container_sas(
            account_name=account_name,
            container_name=source_container_name,
            account_key=account_key,
            permission=ContainerSasPermissions(read=True, list=True),
            expiry=expiry,
        )
        destination_sas_token = generate_container_sas(
            account_name=account_name,
            container_name=destination_container_name,
            account_key=account_key,
            permission=ContainerSasPermissions(
                read=True,
                list=True,
                write=True,
                delete=True,
                add=True,
                create=True,
            ),
            expiry=expiry,
        )

        source_sas_url = (
            f"https://{account_name}.blob.core.windows.net/{source_container_name}?{source_sas_token}"
        )
        destination_sas_url = (
            f"https://{account_name}.blob.core.windows.net/{destination_container_name}?{destination_sas_token}"
        )

        request_body = {
            "sourceSasUri": source_sas_url,
            "destinationSasUri": destination_sas_url,
            "recursive": True,
        }

    context.request_body = request_body

    masked_request_body = {
        **request_body,
        "sourceSasUri": _mask_sas_url(request_body.get("sourceSasUri", "")),
        "destinationSasUri": _mask_sas_url(request_body.get("destinationSasUri", "")),
    }

    allure.attach(
        json.dumps(masked_request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then('I store the ingestion job id from the response')
def step_store_ingestion_job_id(context) -> None:
    body = context.last_response.json()
    ingestion_job_id = body.get("ingestionJobId")
    assert ingestion_job_id, f"Expected 'ingestionJobId' in response body, got: {body}"

    context.ingestion_job_id = ingestion_job_id
    allure.attach(
        ingestion_job_id,
        name="ingestion_job_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@when('I poll the data transfer job status until completion')
def step_poll_data_transfer_status(context) -> None:
    ingestion_job_id = getattr(context, "ingestion_job_id", None)
    assert ingestion_job_id, "No ingestion job id found on context."

    poll_interval_seconds = int(os.getenv("DATA_TRANSFER_POLL_INTERVAL_SECONDS", "3"))
    poll_timeout_seconds = int(os.getenv("DATA_TRANSFER_POLL_TIMEOUT_SECONDS", "180"))
    max_attempts = max(1, poll_timeout_seconds // max(1, poll_interval_seconds))
    endpoint = f"/data-transfer/azure/azcopy/azure/azcopysync/{ingestion_job_id}"
    headers = getattr(context, "headers", {})

    for _ in range(max_attempts):
        response = context.client.get(endpoint, headers=headers)
        context.last_response = response

        body = response.json()
        job_status = body.get("jobStatus")
        if job_status in {"Completed", "Failed"}:
            allure.attach(
                _safe_json(response),
                name="final_job_status_response",
                attachment_type=allure.attachment_type.JSON,
            )
            return

        time.sleep(poll_interval_seconds)

    raise AssertionError(
        f"Timed out waiting for data transfer job '{ingestion_job_id}' to complete after {poll_timeout_seconds} seconds."
    )


@then('the data transfer job should be completed successfully')
def step_validate_data_transfer_completed(context) -> None:
    body = context.last_response.json()

    assert context.last_response.status_code == 200, (
        f"Expected polling response status code 200, got {context.last_response.status_code}: {_safe_json(context.last_response)}"
    )
    assert body.get("ingestionJobId") == context.ingestion_job_id, (
        f"Expected ingestionJobId '{context.ingestion_job_id}', got '{body.get('ingestionJobId')}'."
    )
    assert body.get("jobStatus") == "Completed", (
        f"Expected jobStatus 'Completed', got '{body.get('jobStatus')}'. Response: {body}"
    )

    detailed_status = body.get("detailedStatus") or {}
    total_transfers = detailed_status.get("totalTransfers", 0)
    assert total_transfers > 0, (
        f"Expected detailedStatus.totalTransfers > 0, got '{total_transfers}'. Response: {body}"
    )