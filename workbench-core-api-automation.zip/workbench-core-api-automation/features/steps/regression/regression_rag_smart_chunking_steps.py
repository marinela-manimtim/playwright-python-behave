# ============================================================
# RAG Smart Chunking Regression - Step Definitions
# ============================================================

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import allure
from azure.storage.blob import BlobSasPermissions, BlobServiceClient, generate_blob_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()


def _storage_account_name_for_region(region: str) -> str:
    """Map test region to its regression source storage account."""
    mapping = {
        "eastus": "dlsapimregwbameruseqa",
        "australiaeast": "dlsapimregwbapacaueqa",
        "westeurope": "dlsapimregwbemeaweuqa",
    }
    account_name = mapping.get(region)
    assert account_name, f"No storage account mapping configured for region '{region}'."
    return account_name


def _openai_models_for_region(region: str) -> tuple[str, str]:
    """Return chat and embedding deployment ids for the given region."""
    models_by_region = {
        "eastus": (
            "gpt-4o-mini-2024-07-18-dzs-eus",
            "text-embedding-3-small-1-std-eus",
        ),
        "australiaeast": (
            "gpt-4o-mini-2024-07-18-gs-ae",
            "text-embedding-3-small-1-std-ae",
        ),
        "westeurope": (
            "gpt-4o-mini-2024-07-18-dzs-we",
            "text-embedding-3-small-1-gs-sdc",
        ),
    }
    model_ids = models_by_region.get(region)
    assert model_ids, f"No OpenAI deployment mapping configured for region '{region}'."
    return model_ids


def generate_reg_source_sas_uri(storage_account_name: str) -> tuple[str, str]:
    """Build a blob-level SAS URI for the first file under reg-source/sourceData and return URI + file name."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }

    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"

    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."

    container_name = "reg-source"
    directory_name = "sourceData"
    container_client = blob_service_client.get_container_client(container_name)
    candidate_blob = next(
        (
            blob
            for blob in container_client.list_blobs(name_starts_with=f"{directory_name}/")
            if getattr(blob, "name", "") and not str(blob.name).endswith("/")
        ),
        None,
    )
    assert candidate_blob is not None, (
        f"No files found under {container_name}/{directory_name} for storage account {storage_account_name}."
    )

    blob_name = candidate_blob.name if hasattr(candidate_blob, "name") else str(candidate_blob)
    source_file_name = blob_name.rsplit("/", 1)[-1]
    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True, add=True, create=True, write=True, delete=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )

    encoded_blob_name = quote(blob_name, safe="/")
    return (
        f"https://{account_name}.blob.core.windows.net/{container_name}/{encoded_blob_name}?{sas_token}",
        source_file_name,
    )


def _configure_client(context, region: str, timeout: int | None = None) -> None:
    """Configure API client and common headers."""
    context.client = Service(
        region,
        timeout=timeout,
        use_implicit_auth=getattr(context, "use_implicit_auth", False),
    )
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _get_json_response(context, allow_empty: bool = False) -> dict | list:
    """Parse and attach JSON response for diagnostics."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    response_text = (response.text or "").strip()
    if allow_empty and not response_text:
        allure.attach(
            "N/A",
            name="response_body",
            attachment_type=allure.attachment_type.TEXT,
        )
        return {}

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _attach_request_details(context, request_body: dict | None = None) -> None:
    """Attach request URL and request body for consistent Allure diagnostics."""
    allure.attach(
        getattr(context, "request_url", "N/A") or "N/A",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(request_body, indent=2) if request_body is not None else "N/A",
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


# ============================================================
# SCENARIO 1 - Create Chunks
# ============================================================


@given('the RAG Smart Chunking chunking API client is configured with region "{region}"')
def setup_chunking_client(context, region):
    _configure_client(context, region, timeout=120)
    context.storage_account_name = _storage_account_name_for_region(region)
    chat_model_id, embedding_model_id = _openai_models_for_region(region)
    context.headers["x-openai-deployment-id"] = chat_model_id
    context.headers["x-openai-deployment-id-embeddings"] = embedding_model_id
    context.headers["x-openai-api-version"] = "2024-06-01"


@when("I create a smart chunking list of chunks from the specified input string")
def create_chunk_list(context):
    endpoint = "/text-chunking/microsoft/smart/smart"
    sas_uri, source_file_name = generate_reg_source_sas_uri(context.storage_account_name)
    request_body = {
        "path":     sas_uri,
        "source": source_file_name,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.chunking_payload = _get_json_response(context)


@then("the smart chunk list should be created successfully")
def verify_chunk_list_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "chunking_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected smart chunking response payload to be a JSON object or array."


# ============================================================
# SCENARIO 2 - Health Check
# ============================================================


@given('the RAG Smart Chunking health check API client is configured with region "{region}"')
def setup_health_check_client(context, region):
    _configure_client(context, region)


@when("I get the RAG Smart Chunking health check status")
def get_smart_chunking_health(context):
    endpoint = "/text-chunking/microsoft/smart/health-check/self"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.health_payload = _get_json_response(context)


@then("the RAG Smart Chunking health check should be returned successfully")
def verify_smart_chunking_health(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "health_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected smart chunking health-check response payload to be a JSON object or array."


# ============================================================
# SCENARIO 3 - Version
# ============================================================


@given('the RAG Smart Chunking version API client is configured with region "{region}"')
def setup_version_client(context, region):
    _configure_client(context, region)


@when("I get the RAG Smart Chunking API version")
def get_smart_chunking_version(context):
    endpoint = "/text-chunking/microsoft/smart/version"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.version_payload = _get_json_response(context)


@then("the RAG Smart Chunking API version should be returned successfully")
def verify_smart_chunking_version(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "version_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected smart chunking version response payload to be a JSON object or array."


# ============================================================
# SCENARIO 4 - Negative Case: Invalid request body
# ============================================================


@given('the RAG Smart Chunking negative case API client is configured with region "{region}"')
def setup_negative_case_client(context, region):
    _configure_client(context, region)


@when("I create a smart chunking request with invalid body values")
def create_smart_chunking_with_invalid_body(context):
    endpoint = "/text-chunking/microsoft/smart/smart"
    request_body = {
        "path": 123,
        "source": True,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_body_payload = _get_json_response(context)


@then("the smart chunking invalid body response should contain the expected validation error")
def verify_smart_chunking_invalid_body_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "invalid_body_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected validation error response payload to be a JSON object."
    assert payload.get("error") == "Invalid JSON format", (
        f"Expected error 'Invalid JSON format' but got: {payload.get('error')}"
    )


# ============================================================
# SCENARIO 5 - Negative Case: Invalid header values
# ============================================================


@given('the RAG Smart Chunking invalid OpenAI headers API client is configured with region "{region}"')
def setup_invalid_openai_headers_client(context, region):
    _configure_client(context, region, timeout=120)
    context.storage_account_name = _storage_account_name_for_region(region)


@when("I create a smart chunking request with invalid OpenAI headers")
def create_smart_chunking_with_invalid_openai_headers(context):
    endpoint = "/text-chunking/microsoft/smart/smart"
    sas_uri, source_file_name = generate_reg_source_sas_uri(context.storage_account_name)
    request_body = {
        "path": sas_uri,
        "source": source_file_name,
    }
    context.headers["x-openai-deployment-id"] = "gpt-4"
    context.headers["x-openai-deployment-id-embeddings"] = "text-embedding"
    context.headers["x-openai-api-version"] = "2026"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_openai_headers_payload = _get_json_response(context)


@then("the smart chunking invalid OpenAI headers response should contain validation details")
def verify_smart_chunking_invalid_openai_headers_error(context):
    assert context.last_status_code == 404, f"Expected HTTP 404 but got {context.last_status_code}"
    payload = getattr(context, "invalid_openai_headers_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected validation error response payload to be a JSON object."
    assert payload.get("message") == "text-embedding is not a valid model or you do not have access to it.", (
        f"Expected invalid model message but got: {payload.get('message')}"
    )
