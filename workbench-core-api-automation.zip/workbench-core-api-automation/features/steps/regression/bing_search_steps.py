from __future__ import annotations

import json

import allure
from behave import given


@given('I prepare a valid request body for creating an agent with model "{model}" with bing search enabled')
def step_prepare_create_agent_body(context, model: str):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "model": model,
  "name": "Creating this assistant to validate the Bing Search functionality",
  "instructions": "You are a helpful assistant",
  "tools": [
        {
            "type": "bing_grounding",
            "bing_grounding": {
                "search_configurations": [
                    {
                        "connection_id": "/subscriptions/505f6e9b-691e-4732-bc6c-17b79f8e7be4/resourceGroups/rgp-aif-wb-apac-aue-dv/providers/Microsoft.CognitiveServices/accounts/aif-wb-apac-aue-dv/projects/aif-prj-wb-apac-aue-dv/connections/bingaifprjwbapacauedv",
                        "market": "en-us",
                        "set_lang": "en",
                        "count": 5
                    }
                ]
            }
        }
    ]
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given('I prepare a valid request body for creating an agent with model "{model}" with bing search enabled with missing tool type')
def step_prepare_create_agent_body(context, model: str):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "model": model,
  "name": "Assistant-N1",
  "instructions": "You are a helpful assistant",
  "tools": [
        {
            "bing_grounding": {
                "search_configurations": [
                    {
                        "connection_id": "/subscriptions/505f6e9b-691e-4732-bc6c-17b79f8e7be4/resourceGroups/rgp-aif-wb-apac-aue-dv/providers/Microsoft.CognitiveServices/accounts/aif-wb-apac-aue-dv/projects/aif-prj-wb-apac-aue-dv/connections/bingaifprjwbapacauedv",
                        "market": "en-us",
                        "set_lang": "en",
                        "count": 5
                    }
                ]
            }
        }
    ]
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given('I prepare a valid request body for creating an assistant with model "{model}" with bing search enabled')
def step_prepare_create_assistant_body(context, model: str):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "model": model,
  "name": "Creating this assistant to validate the Bing Search functionality",
  "instructions": "You are a helpful assistant",
  "tools": [
        {
            "type": "bing_grounding",
            "bing_grounding": {
                "search_configurations": [
                    {
                        "connection_id": "/subscriptions/505f6e9b-691e-4732-bc6c-17b79f8e7be4/resourceGroups/rgp-aif-wb-apac-aue-dv/providers/Microsoft.CognitiveServices/accounts/aif-wb-apac-aue-dv/projects/aif-prj-wb-apac-aue-dv/connections/bingaifprjwbapacauedv",
                        "market": "en-us",
                        "set_lang": "en",
                        "count": 5
                    }
                ]
            }
        }
    ]
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

