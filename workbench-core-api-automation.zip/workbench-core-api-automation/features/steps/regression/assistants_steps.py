from __future__ import annotations

import json

import allure
from behave import given, then


def _resolve_context_region(context) -> str | None:
    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        return region

    region = getattr(context, "current_region", None)
    if region:
        return region

    client = getattr(context, "client", None)
    return getattr(client, "region", None)


@given('I prepare a valid request body for creating an assistant with model "{model}"')
def step_prepare_create_assistant_body(context, model: str):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
            "model": model,
            "name": "My Assistant for Demo",
            "instructions": "You are a helpful assistant",
        }

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for updating an assistant with model \"{model}\"")
def step_prepare_update_assistant_body(context, model: str):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "model": model,
  "name": "My Assistant_Modified",
  "instructions": "You are a helpful assistant",
  "tools": [
        {
            "type": "bing_grounding",
            "bing_grounding": {
                "search_configurations": [
                    {
                        "connection_id": "/subscriptions/505f6e9b-691e-4732-bc6c-17b79f8e7be4/resourceGroups/rgp-aif-wb-apac-aue-dv/providers/Microsoft.CognitiveServices/accounts/aif-wb-apac-aue-dv/projects/aif-prj-wb-apac-aue-dv/connections/bingaifprjwbapacauedv",
                        "market": "en-us",
                        "set_lang": "en",
                        "count": 5
                    }
                ]
            }
        }
    ]
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for creating a thread")
def step_prepare_create_thread_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        region = getattr(context, "headers", {}).get("x-kpmg-region-override")
        assistant_id = None
        if region:
            assistant_id = getattr(context.config, "assistant_ids_by_region", {}).get(region)
        if not assistant_id:
            assistant_id = getattr(context, "assistant_id", None)
        if not assistant_id:
            assistant_id = getattr(context.config, "assistant_id", None)

        assert assistant_id, (
            "No assistant id available for thread creation. "
            "Run the create-assistant scenario first and store the assistant id from the response."
        )

        request_body = {
  "assistant_id" : assistant_id,
  "messages": [
    {
        "role" : "user",
        "content" :"Hi Buddy..!!Whats up?"
    }
   ],
  "metadata": {
    "qa-purpose": "automated-test"
  }
}

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for creating a message")
def step_prepare_create_message_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        region = getattr(context, "headers", {}).get("x-kpmg-region-override")
        thread_id = None
        if region:
            thread_id = getattr(context.config, "thread_ids_by_region", {}).get(region)
        if not thread_id:
            thread_id = getattr(context, "thread_id", None)
        if not thread_id:
            thread_id = getattr(context.config, "thread_id", None)

        assert thread_id, (
            "No thread id available for message creation. "
            "Run the create-thread scenario first and store the thread id from the response."
        )

        context.thread_id = thread_id

        request_body = {
  "role": "user",
  "content": "What are the last faint words?"
}

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@given("I prepare a valid request body for creating a run")
def step_prepare_create_run_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        region = getattr(context, "headers", {}).get("x-kpmg-region-override")
        assistant_id = None
        if region:
            assistant_id = getattr(context.config, "assistant_ids_by_region", {}).get(region)
        if not assistant_id:
            assistant_id = getattr(context, "assistant_id", None)
        if not assistant_id:
            assistant_id = getattr(context.config, "assistant_id", None)

        assert assistant_id, (
            "No assistant id available for run creation. "
            "Run the create-assistant scenario first and store the assistant id from the response."
        )

        thread_id = None
        if region:
            thread_id = getattr(context.config, "thread_ids_by_region", {}).get(region)
        if not thread_id:
            thread_id = getattr(context, "thread_id", None)
        if not thread_id:
            thread_id = getattr(context.config, "thread_id", None)

        assert thread_id, (
            "No thread id available for run creation. "
            "Run the create-thread scenario first and store the thread id from the response."
        )

        context.thread_id = thread_id

        request_body = {
  "assistant_id": assistant_id,
  "instructions": "Creating run for testing",
  "metadata": {
    "qa-purpose": "automated-test"
  }
}

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )

@given("I prepare a valid request body for updating a thread metadata")
def step_prepare_update_thread_metadata_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
            "metadata": {
            "qa-purpose": "automated-test",
            "updated": "true"
  }
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    ) 

@given("I prepare a valid request body for updating a message")
def step_prepare_update_message_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "metadata": {
    "qa-updated": "true"
  }
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )   

@given("I prepare a valid request body for updating a run metadata")
def step_prepare_update_run_metadata_body(context):
    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = {
  "metadata": {
    "qa-updated": "true"
  }
}
    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("I store the assistant id from the response")
def step_store_assistant_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing assistant id."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            "Expected JSON response when storing assistant id, "
            f"but received: {response.text[:500]}"
        ) from exc

    assistant_id = payload.get("assistant_id") or payload.get("id")
    if not assistant_id and isinstance(payload.get("data"), dict):
        assistant_id = payload["data"].get("assistant_id") or payload["data"].get("id")

    assert assistant_id, (
        "Could not find assistant id in response. "
        "Expected one of: 'assistant_id', 'id', 'data.assistant_id', 'data.id'. "
        f"Response body: {json.dumps(payload, indent=2)}"
    )

    context.assistant_id = assistant_id
    context.config.assistant_id = assistant_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        config_assistant_ids_by_region = getattr(context.config, "assistant_ids_by_region", {})
        config_assistant_ids_by_region[region] = assistant_id
        context.config.assistant_ids_by_region = config_assistant_ids_by_region

    allure.attach(
        str(assistant_id),
        name="assistant_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the thread id from the response")
def step_store_thread_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing thread id."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            "Expected JSON response when storing thread id, "
            f"but received: {response.text[:500]}"
        ) from exc

    thread_id = payload.get("thread_id") or payload.get("id")
    if not thread_id and isinstance(payload.get("data"), dict):
        thread_id = payload["data"].get("thread_id") or payload["data"].get("id")

    assert thread_id, (
        "Could not find thread id in response. "
        "Expected one of: 'thread_id', 'id', 'data.thread_id', 'data.id'. "
        f"Response body: {json.dumps(payload, indent=2)}"
    )

    context.thread_id = thread_id
    context.config.thread_id = thread_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        config_thread_ids_by_region = getattr(context.config, "thread_ids_by_region", {})
        config_thread_ids_by_region[region] = thread_id
        context.config.thread_ids_by_region = config_thread_ids_by_region

    allure.attach(
        str(thread_id),
        name="thread_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the message id from the response")
def step_store_message_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing message id."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            "Expected JSON response when storing message id, "
            f"but received: {response.text[:500]}"
        ) from exc

    message_id = payload.get("message_id") or payload.get("id")
    if not message_id and isinstance(payload.get("data"), dict):
        message_id = payload["data"].get("message_id") or payload["data"].get("id")

    assert message_id, (
        "Could not find message id in response. "
        "Expected one of: 'message_id', 'id', 'data.message_id', 'data.id'. "
        f"Response body: {json.dumps(payload, indent=2)}"
    )

    context.message_id = message_id
    context.config.message_id = message_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        message_ids_by_region = getattr(context, "message_ids_by_region", {})
        message_ids_by_region[region] = message_id
        context.message_ids_by_region = message_ids_by_region
        config_message_ids_by_region = getattr(context.config, "message_ids_by_region", {})
        config_message_ids_by_region[region] = message_id
        context.config.message_ids_by_region = config_message_ids_by_region

    allure.attach(
        str(message_id),
        name="message_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store the run id from the response")
def step_store_run_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing run id."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            "Expected JSON response when storing run id, "
            f"but received: {response.text[:500]}"
        ) from exc

    run_id = payload.get("run_id") or payload.get("id")
    if not run_id and isinstance(payload.get("data"), dict):
        run_id = payload["data"].get("run_id") or payload["data"].get("id")

    assert run_id, (
        "Could not find run id in response. "
        "Expected one of: 'run_id', 'id', 'data.run_id', 'data.id'. "
        f"Response body: {json.dumps(payload, indent=2)}"
    )

    context.run_id = run_id
    context.config.run_id = run_id

    region = getattr(context, "headers", {}).get("x-kpmg-region-override")
    if region:
        config_run_ids_by_region = getattr(context.config, "run_ids_by_region", {})
        config_run_ids_by_region[region] = run_id
        context.config.run_ids_by_region = config_run_ids_by_region

    allure.attach(
        str(run_id),
        name="run_id",
        attachment_type=allure.attachment_type.TEXT,
    )


@then("I store one step id from the response")
@then("I store the step id from the response")
def step_store_step_id_from_response(context):
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Ensure a request step ran before storing step id."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            "Expected JSON response when storing step id, "
            f"but received: {response.text[:500]}"
        ) from exc

    step_id = payload.get("step_id") or payload.get("id")
    if not step_id and isinstance(payload.get("data"), dict):
        step_id = payload["data"].get("step_id") or payload["data"].get("id")
    if not step_id and isinstance(payload.get("data"), list) and payload["data"]:
        first_item = payload["data"][0]
        if isinstance(first_item, dict):
            step_id = first_item.get("step_id") or first_item.get("id")
    if not step_id:
        step_id = payload.get("first_id")

    assert step_id, (
        "Could not find step id in response. "
        "Expected one of: 'step_id', 'id', 'data.step_id', 'data.id', 'data[0].id', 'first_id'. "
        f"Response body: {json.dumps(payload, indent=2)}"
    )

    context.step_id = step_id
    context.config.step_id = step_id

    region = _resolve_context_region(context)
    if region:
        config_step_ids_by_region = getattr(context.config, "step_ids_by_region", {})
        config_step_ids_by_region[region] = step_id
        context.config.step_ids_by_region = config_step_ids_by_region
        step_ids_by_region = getattr(context, "step_ids_by_region", {})
        step_ids_by_region[region] = step_id
        context.step_ids_by_region = step_ids_by_region

    allure.attach(
        str(step_id),
        name="step_id",
        attachment_type=allure.attachment_type.TEXT,
    )
