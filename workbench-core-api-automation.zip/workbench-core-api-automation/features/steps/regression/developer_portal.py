from __future__ import annotations

import os
import time
from urllib.parse import urlparse

import allure
from behave import When, given, then, when
from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright


def _resolve_developer_portal_url(context, qa_environment: str) -> str:
    environment = qa_environment.strip().lower()
    env_key_map = {
        "eastus": "DEVELOPER_PORTAL_URL_EASTUS",
        "australiaeast": "DEVELOPER_PORTAL_URL_AUSTRALIAEAST",
        "westeurope": "DEVELOPER_PORTAL_URL_WESTEUROPE",
    }
    env_key = env_key_map.get(environment)
    if not env_key:
        raise ValueError(f"Invalid QA environment: {qa_environment}")

    value = context.config.userdata.get(env_key) or os.getenv(env_key, "")
    value = value.strip() if isinstance(value, str) else ""
    if not value:
        raise ValueError(
            f"Missing '{env_key}' in behave userdata or environment variables."
        )
    return value


def _get_required_secret(context, key: str) -> str:
    value = context.config.userdata.get(key) or os.getenv(key, "")
    value = value.strip() if isinstance(value, str) else ""
    if not value:
        raise ValueError(
            f"Missing '{key}' in behave userdata or environment variables."
        )
    return value


def _current_path(page) -> str:
    parsed = urlparse(page.url)
    path = (parsed.path or "/").rstrip("/")
    return path or "/"


def _assert_path_matches_any(page, expected_prefixes: tuple[str, ...], label: str) -> None:
    deadline = time.time() + 10
    while time.time() < deadline:
        current_path = _current_path(page).lower()
        if any(
            current_path == prefix or current_path.startswith(f"{prefix}/")
            for prefix in expected_prefixes
        ):
            return
        page.wait_for_timeout(200)

    current_path = _current_path(page)
    raise AssertionError(
        f"'{label}' did not navigate to expected endpoint. "
        f"Expected one of: {expected_prefixes}; actual path: '{current_path}'"
    )
    
@given('I am on the developer portal login page for "{qa_environment}"')
def step_open_developer_portal(context, qa_environment: str) -> None:
    context.developer_portal_url = _resolve_developer_portal_url(context, qa_environment)
    context.developer_portal_username = _get_required_secret(context, "DEVELOPER_PORTAL_USERNAME")
    context.developer_portal_password = _get_required_secret(context, "DEVELOPER_PORTAL_PASSWORD")

    headless_raw = (context.config.userdata.get("PLAYWRIGHT_HEADLESS") or os.getenv("PLAYWRIGHT_HEADLESS", "false"))
    headless = str(headless_raw).strip().lower() in {"true", "1", "yes", "on"}

    context.playwright_instance = sync_playwright().start()
    context.developer_portal_browser = context.playwright_instance.chromium.launch(
        channel="chrome",
        headless=headless,
    )
    context.developer_portal_context = context.developer_portal_browser.new_context(
        http_credentials={
            "username": context.developer_portal_username,
            "password": context.developer_portal_password,
        }
    )
    context.developer_portal_page = context.developer_portal_context.new_page()
    context.developer_portal_page.goto(context.developer_portal_url, wait_until="domcontentloaded")

    allure.attach(
        context.developer_portal_url,
        name="developer_portal_url",
        attachment_type=allure.attachment_type.TEXT,
    )

    print(
        "[playwright_hook] browser_open "
        f"region={qa_environment} headless={headless} channel=chrome"
    )


@when('I enter valid credentials for "{qa_environment}"')
def step_enter_valid_credentials(context, qa_environment: str) -> None:
    _ = qa_environment
    page = getattr(context, "developer_portal_page", None)
    if page is None:
        raise RuntimeError("Developer portal page is not initialized.")

    username = getattr(context, "developer_portal_username", None) or _get_required_secret(context, "DEVELOPER_PORTAL_USERNAME")
    password = getattr(context, "developer_portal_password", None) or _get_required_secret(context, "DEVELOPER_PORTAL_PASSWORD")

    try:
        page.get_by_role("button", name="Sign-in").click(timeout=15_000)
    except Exception:
        pass

    try:
        with page.expect_popup(timeout=15_000) as popup_info:
            page.get_by_role("button", name="Microsoft Entra ID").click()
        login_page = popup_info.value
    except Exception:
        login_page = page

    login_page.get_by_role("textbox").first.fill(username)
    login_page.get_by_role("button", name="Next").first.click()

    password_selectors = ["input[type='password']", "#i0118", "input[name='passwd']"]
    password_filled = False
    for selector in password_selectors:
        try:
            login_page.wait_for_selector(selector, timeout=15_000)
            login_page.fill(selector, password)
            password_filled = True
            break
        except PWTimeout:
            continue

    if not password_filled:
        raise RuntimeError("Could not locate password field for Microsoft Entra ID login.")

    for button_name in ("Sign in", "Next"):
        try:
            login_page.get_by_role("button", name=button_name).first.click(timeout=10_000)
            break
        except Exception:
            continue


@when('I attempt to sign in during a network interruption for "{qa_environment}"')
def step_login_with_network_interruption(context, qa_environment: str) -> None:
    _ = qa_environment
    page = getattr(context, "developer_portal_page", None)
    if page is None:
        raise RuntimeError("Developer portal page is not initialized.")

    username = getattr(context, "developer_portal_username", None) or _get_required_secret(context, "DEVELOPER_PORTAL_USERNAME")
    password = getattr(context, "developer_portal_password", None) or _get_required_secret(context, "DEVELOPER_PORTAL_PASSWORD")

    login_error: Exception | None = None
    login_page = page

    try:
        page.get_by_role("button", name="Sign-in").click(timeout=15_000)
    except Exception:
        pass

    try:
        with page.expect_popup(timeout=15_000) as popup_info:
            page.get_by_role("button", name="Microsoft Entra ID").click()
        login_page = popup_info.value
    except Exception:
        login_page = page

    context.developer_portal_context.set_offline(True)

    try:
        login_page.get_by_role("textbox").first.fill(username)
        login_page.get_by_role("button", name="Next").first.click()

        password_selectors = ["input[type='password']", "#i0118", "input[name='passwd']"]
        for selector in password_selectors:
            try:
                login_page.wait_for_selector(selector, timeout=5_000)
                login_page.fill(selector, password)
                break
            except PWTimeout:
                continue

        for button_name in ("Sign in", "Next"):
            try:
                login_page.get_by_role("button", name=button_name).first.click(timeout=5_000)
                break
            except Exception:
                continue
    except Exception as exc:
        login_error = exc

    context.network_interruption_login_error = login_error
    context.network_interruption_login_url = login_page.url

    screenshot_bytes = login_page.screenshot(full_page=True)
    allure.attach(
        screenshot_bytes,
        name="login_blocked_network_interruption",
        attachment_type=allure.attachment_type.PNG,
    )

    context.developer_portal_context.set_offline(False)


@then("I should see that login is blocked due to network interruption")
def step_verify_login_blocked_network_interruption(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
        raise RuntimeError("Developer portal page is not initialized.")

    login_error = getattr(context, "network_interruption_login_error", None)
    current_url = (page.url or "").lower()
    entered_dashboard = "/dashboard" in current_url or "welcome to the kpmg ai" in page.content().lower()

    assert (not entered_dashboard), (
        "Login unexpectedly succeeded while network was offline. "
        f"Current URL: {page.url}"
    )

    if login_error is not None:
        return

    blocked_indicators = [
        "network",
        "cannot reach",
        "try again",
        "offline",
        "error",
    ]
    content_lower = page.content().lower()
    assert any(indicator in content_lower for indicator in blocked_indicators), (
        "No explicit network-block indicator found, but login did not reach dashboard. "
        f"Current URL: {page.url}"
    )

@then("I should be redirected to the developer portal dashboard")
def step_verify_dashboard(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
        raise RuntimeError("Developer portal page is not initialized.")

    page.get_by_text("Welcome to the KPMG AI").first.wait_for(timeout=20_000)
    assert page.get_by_text("Welcome to the KPMG AI").first.is_visible(), (
        "Failed to redirect to the developer portal dashboard"
    )

@then("I should verify developer portal navigation endpoints")
def step_verify_navigation_endpoints(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
        raise RuntimeError("Developer portal page is not initialized.")

    page.get_by_role("link", name="Home").click()
    _assert_path_matches_any(page, ("/", "/home"), "Home")

    page.get_by_role("link", name="APIs").click()
    _assert_path_matches_any(page, ("/apis",), "APIs")

    page.get_by_role("article").filter(has_text="☰").get_by_role("link").click()

    page.get_by_role("link", name="Products").click()
    _assert_path_matches_any(page, ("/products",), "Products")

    page.get_by_role("article").filter(has_text="☰").get_by_role("link").click()

    page.get_by_role("link", name="Reports").click()
    _assert_path_matches_any(page, ("/reports",), "Reports")

    page.get_by_role("article").filter(has_text="☰").get_by_role("link").click()

    page.get_by_role("link", name="Profile").click()
    _assert_path_matches_any(page, ("/profile",), "Profile")

    page.get_by_role("article").filter(has_text="☰").get_by_role("link").click()

@when("I am on the APIs page")
def step_open_apis_page(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
            raise RuntimeError("Developer portal page is not initialized.")

    page.get_by_role("link", name="APIs").click()
    _assert_path_matches_any(page, ("/apis",), "APIs")
    
@when('I search for an API "{api_name}" in the search bar')
def step_search_api(context, api_name: str) -> None: 
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")
    
    search_box = page.get_by_role("searchbox", name="Search APIs")
    search_box.click()
    search_box.fill(api_name)

@then('I should see the API "{api_name}" in the search results')
def step_verify_search_api(context, api_name: str) -> None:  
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    result_link = page.get_by_role("link", name=f"{api_name}")
    try:
        result_link.first.wait_for(timeout=15_000)
        assert result_link.first.is_visible(), (
            f"API '{api_name}' link is not visible in the search results"
        )
    except Exception:
        screenshot_bytes = page.screenshot(full_page=True)
        allure.attach(
            screenshot_bytes,
            name=f"api_search_failure_{api_name}",
            attachment_type=allure.attachment_type.PNG,
        )
        raise

@then("I should verify the different API endpoints are accessible")  
def step_verify_api_endpoints(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_title("Create or validate a search").click()
    assert page.get_by_text("Create or validate a search").is_visible(), (
        "Create or validate a search link is not visible in the search results"
    )
    page.get_by_text("Delete a search index mapping").click()
    assert page.get_by_text("Delete a search index mapping").is_visible(), (
        "Delete a search index mapping link is not visible in the search results"
    )
    page.get_by_text("Get the search index mapping").click()
    assert page.get_by_text("Get the search index mapping").is_visible(), (
        "Get the search index mapping link is not visible in the search results"
    )
    page.get_by_text("Reverse lookup — get agent ID").click()
    assert page.get_by_text("Reverse lookup — get agent ID").is_visible(), (
        "Reverse lookup — get agent ID link is not visible in the search results"
    )

@when("I select a filter tag")    
def step_select_filter_tag(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_title("Add tags to search query").click()
    page.get_by_role("option", name="contract-compatible").click()

@then("I should see the filtered APIs in the search results")
def step_verify_filtered_results(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("link", name="Azure AI Search - Agents API")
    assert page.get_by_role("link", name="Azure AI Search - Agents API").is_visible(), (
         "Azure AI Search - Agents API link is not visible in the search results"
    )

    page.get_by_role("link", name="Azure AI Search - Indexes,")
    assert page.get_by_role("link", name="Azure AI Search - Indexes,").is_visible(), (
        "Azure AI Search - Indexes link is not visible in the search results"
    )

    page.get_by_role("link", name="Azure AI Translator - Document API")
    assert page.get_by_role("link", name="Azure AI Translator - Document API").is_visible(), (
        "Azure AI Translator - Document API link is not visible in the search results"
    )

    page.get_by_role("link", name="Azure AI Translator - Text API")
    assert page.get_by_role("link", name="Azure AI Translator - Text API").is_visible(), (
        "Azure AI Translator - Text API link is not visible in the search results"
    )
    page.get_by_role("link", name="Azure OpenAI - Assistants API")
    assert page.get_by_role("link", name="Azure OpenAI - Assistants API").is_visible(), (
        "Azure OpenAI - Assistants API link is not visible in the search results"
    )
    page.get_by_role("link", name="Azure OpenAI - Completions")
    assert page.get_by_role("link", name="Azure OpenAI - Completions").is_visible(), (
        "Azure OpenAI - Completions link is not visible in the search results"
    )
    page.get_by_role("link", name="Azure OpenAI - Responses API")
    assert page.get_by_role("link", name="Azure OpenAI - Responses API").is_visible(), (
        "Azure OpenAI - Responses API link is not visible in the search results"
    )

    page.get_by_role("link", name="Claude Foundry v2")
    assert page.get_by_role("link", name="Claude Foundry v2").is_visible(), (
        "Claude Foundry v2 link is not visible in the search results"
    )
    page.get_by_role("link", name="Foundry Passthrough")
    assert page.get_by_role("link", name="Foundry Passthrough").is_visible(), (
        "Foundry Passthrough link is not visible in the search results"
    )    

@when('I click on the API link for "{api_name}"')
def step_click_api_link(context, api_name: str) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("link", name=f"{api_name}").click()

@then('I should be redirected to the API documentation page for "{api_name}"')
def step_verify_api_details_page(context, api_name: str) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.locator("h1").get_by_text("Azure AI Translator - Text API")
    assert page.locator("h1").get_by_text(f"{api_name}").is_visible(), (
        f"Failed to redirect to the API details page for '{api_name}'"
    )

@then('I click on the "Try it" button for the API "{api_name}"') 
def step_click_try_it_button(context, api_name: str) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("button", name="Try it ").click()
    assert page.get_by_role("button", name="Try it ").is_visible(), (
        f"Failed to click on the 'Try it' button for the API '{api_name}'"
    )   

@then("I should be able to execute the API request and receive a response")  
def step_execute_api_request(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("button", name="Execute").click()
    assert page.get_by_role("button", name="Execute").is_visible(), (
        "Failed to execute the API request and receive a response"
    )

    page.get_by_text("Languages").click()
    page.get_by_role("group").filter(has_text="Parameters api-version 3.").get_by_role("combobox").select_option("2025-05-01-preview")
    page.get_by_role("button", name=" Add header").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").fill("x-kpmg-region-override")
    page.get_by_role("textbox", name="Header value").nth(1).click()
    page.get_by_role("textbox", name="Header value").nth(1).fill("australiaeast")
    page.get_by_role("button", name=" Add header").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").fill("x-kpmg-charge-code")
    page.get_by_role("textbox", name="Header value").nth(2).click()
    page.get_by_role("textbox", name="Header value").nth(2).fill("1")
    page.get_by_role("button", name=" Add header").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").fill("x-kpmg-config-group")
    page.get_by_role("textbox", name="Header value").nth(3).click()
    page.get_by_role("textbox", name="Header value").nth(3).fill("97dbda91-bc6a-4b4f-85ec-57b85bfeb420")
    page.get_by_role("button", name=" Add header").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").click()
    page.get_by_role("textbox", name="Header name", description="Name is required.").fill("Ocp-Apim-Subscription-Key")
    page.get_by_role("textbox", name="Header value").nth(4).click()
    page.get_by_role("textbox", name="Header value").nth(4).fill("F20e0a9e4cc2474eba263ee8e7b39013")
    page.get_by_role("button", name="Send").click()
    page.locator("operation-console").get_by_text("200 OK").click()  

@when("I am on the User Profile page")    
def step_open_user_profile_page(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("link", name="Profile").click()
    _assert_path_matches_any(page, ("/profile",), "Profile")

@then("I should be redirected to the User Profile page")   
def step_verify_user_profile_page(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_role("heading", name="User profile")
    assert page.get_by_role("heading", name="User Profile").is_visible(), (
        "Failed to redirect to the User Profile page"
    )

@then("I should be able to verify my account information")     
def step_verify_account_information(context) -> None:
    page = getattr(context, "developer_portal_page", None)
    if page is None:
                raise RuntimeError("Developer portal page is not initialized.")   

    page.get_by_text("go-cld-mamanimtim@kpmgqa.com")
    assert page.get_by_text("go-cld-mamanimtim@kpmgqa.com").is_visible(), (
        "Failed to verify account information"
    )