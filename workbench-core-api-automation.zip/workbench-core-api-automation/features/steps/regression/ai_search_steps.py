# ============================================================
# AI Search End-to-End Smoke — Step Definitions
# ============================================================
# Covers the full pipeline:
#   1.  Create Catalog (RAG API)
#   2.  Create Catalog Source (RAG API)
#   3.  Start Ingestion Job (RAG API)
#   4.  Get Ingestion Job Status (RAG API)
#   5.  Create Data Source (Azure AI Search API)
#   6.  Get Data Source by Name (Azure AI Search API)
#   7.  Create or Update Data Source (Azure AI Search API)
#   8.  List Data Sources (Azure AI Search API)
#   9.  Create Index (Azure AI Search API)
#   10. Get Index by Name (Azure AI Search API)
#   11. Create or Update Index (Azure AI Search API)
#   12. List Indexes (Azure AI Search API)
#   13. Get Index Statistics (Azure AI Search API)
#   14. Analyze Text with Index Analyzer (Azure AI Search API)
#   15. Create Skillset (Azure AI Search API)
#   16. Get Skillset by Name (Azure AI Search API)
#   17. Create or Update Skillset (Azure AI Search API)
#   18. List Skillsets (Azure AI Search API)
#   19. Create Indexer (Azure AI Search API)
#   20. Get Indexer by Name (Azure AI Search API)
#   21. Create or Update Indexer (Azure AI Search API)
#   22. Get Indexer Status (Azure AI Search API)
#   23. List Indexers (Azure AI Search API)
#   24. Reset Indexer (Azure AI Search API)
#   25. Run Indexer On-demand (Azure AI Search API)
#   26. Create Agent (Agents API)
#   27. Create Thread (Agents API)
#   28. Create Message (Agents API)
#   29. Create Run (Agents API)
#   30. Get / Poll Run (Agents API)
#   31. List Messages (Agents API)
#   32. Delete Thread (Agents API)
#   33. Delete Agent (Agents API)
#   34. Delete Indexer (Azure AI Search API)
#   35. Delete Skillset (Azure AI Search API)
#   36. Delete Index (Azure AI Search API)
#   37. Delete Data Source (Azure AI Search API)
#   38. Delete Catalog Source (RAG API)
#   39. Delete Catalog (RAG API)
#   40. Negative: Data Source Invalid Type (Azure AI Search API)
#   41. Negative: Index Missing Mandatory Parameters (Azure AI Search API)
#   42. Negative: Skillset Missing Parameters (Azure AI Search API)
#   43. Negative: Indexer Missing Parameters (Azure AI Search API)
# ============================================================

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import quote

import allure
import requests
from azure.storage.blob import BlobServiceClient, ContainerSasPermissions, generate_container_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()

# Module-level store keyed by region — persists across all scenarios for the entire test run.
# Behave executes all rows of one Scenario Outline before moving to the next scenario,
# so each region must keep its own IDs and names independently.
_ai_search_store: dict = {}
_RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


# ────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────

def _store(context, **kwargs) -> None:
    """Save key/value pairs into the region-specific slot of _ai_search_store."""
    region = context.headers.get("x-kpmg-region-override", "unknown")
    _ai_search_store.setdefault(region, {}).update(kwargs)


def _restore(context, region, *keys) -> None:
    """Load stored values for a region back into context."""
    data = _ai_search_store.get(region, {})
    for key in keys:
        setattr(context, key, data.get(key))


def _request_with_retry(context, method: str, endpoint: str, *, json_body=None, params=None, max_attempts: int = 4):
    """Send HTTP request with retry for transient gateway/service errors."""
    delay_seconds = 2
    client_method = getattr(context.client, method)

    for attempt in range(1, max_attempts + 1):
        try:
            response = client_method(
                endpoint,
                json=json_body,
                headers=context.headers,
                params=params,
            )
        except (requests.exceptions.ReadTimeout, requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as exc:
            allure.attach(
                f"Attempt {attempt}/{max_attempts} raised {type(exc).__name__}: {exc}. Retrying in {delay_seconds}s.",
                name="transient_retry_exception",
                attachment_type=allure.attachment_type.TEXT,
            )
            if attempt < max_attempts:
                time.sleep(delay_seconds)
                delay_seconds *= 2
                continue
            raise

        context.last_response = response
        context.last_status_code = response.status_code

        if response.status_code not in _RETRYABLE_STATUS_CODES:
            return response

        allure.attach(
            f"Attempt {attempt}/{max_attempts} returned {response.status_code}. Retrying in {delay_seconds}s.",
            name="transient_retry",
            attachment_type=allure.attachment_type.TEXT,
        )

        if attempt < max_attempts:
            time.sleep(delay_seconds)
            delay_seconds *= 2

    return context.last_response

def generate_reg_source_sas_uri(storage_account_name: str) -> str:
    """Build a SAS URI for reg-source/sourceData using the connection string for the given storage account."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }
    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"
    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."
    container_name = "reg-source"
    directory_name = "sourceData"
    sas_token = generate_container_sas(
        account_name=account_name,
        container_name=container_name,
        account_key=account_key,
        permission=ContainerSasPermissions(read=True, add=True, create=True, write=True, delete=True, list=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )
    return f"https://{account_name}.blob.core.windows.net/{container_name}/{directory_name}?{sas_token}"


def _resolve_storage_connection_string_for_region(region: str) -> str:
    """Resolve Azure Storage connection string for a region from standard env vars."""
    region_prefix_map = {
        "eastus": "AMER",
        "westeurope": "EMEA",
        "australiaeast": "ASPAC",
    }
    normalized_region = (region or "").replace("-", "_").upper()
    mapped_prefix = region_prefix_map.get(region)

    candidates = []
    if normalized_region:
        candidates.append(f"AZURE_STORAGE_CONNECTION_STRING_{normalized_region}")
    if mapped_prefix:
        candidates.append(f"AZURE_STORAGE_CONNECTION_STRING_{mapped_prefix}")
    candidates.append("AZURE_STORAGE_CONNECTION_STRING")

    for env_var_name in candidates:
        raw_value = os.getenv(env_var_name)
        if not raw_value or not raw_value.strip():
            continue

        raw_value = raw_value.strip()
        if env_var_name == "AZURE_STORAGE_CONNECTION_STRING":
            try:
                parsed = json.loads(raw_value)
            except json.JSONDecodeError:
                return raw_value

            if isinstance(parsed, dict):
                keys_to_try = [region, region.replace("-", "_"), (mapped_prefix or "").lower()]
                for key in keys_to_try:
                    if key and parsed.get(key):
                        return str(parsed[key]).strip()
                continue

        return raw_value

    raise AssertionError(
        "Missing Azure Storage connection string for raw-file listing. "
        f"Checked env vars: {', '.join(candidates)}"
    )


def _attach_ingested_raw_file_names(context) -> None:
    """Attach raw folder blob names for the current catalog/source to Allure."""
    region = context.headers.get("x-kpmg-region-override", "")
    catalog_id = getattr(context, "catalog_id", None)
    source_id = getattr(context, "source_id", None)
    assert catalog_id and source_id, "catalog_id/source_id missing for raw file listing."

    prefix = f"{catalog_id}/sources/{source_id}/raw/"
    allure.attach(prefix, name="raw_folder_prefix", attachment_type=allure.attachment_type.TEXT)

    try:
        connection_string = _resolve_storage_connection_string_for_region(region)
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service_client.get_container_client("catalogs")
        file_names = [blob.name for blob in container_client.list_blobs(name_starts_with=prefix)]

        allure.attach(str(len(file_names)), name="raw_folder_file_count", attachment_type=allure.attachment_type.TEXT)
        allure.attach(
            json.dumps(file_names, indent=2),
            name="raw_folder_file_names",
            attachment_type=allure.attachment_type.JSON,
        )
    except Exception as exc:  # noqa: BLE001
        allure.attach(
            str(exc),
            name="raw_folder_listing_warning",
            attachment_type=allure.attachment_type.TEXT,
        )

def get_json_response(context) -> dict:
    """Parse last HTTP response as JSON, attach it to the Allure report."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."
    error_message = (
        f"Unexpected response:\n"
        f"Status Code: {response.status_code}\n"
        f"Request URL: {response.url}\n"
        f"Content-Type: {response.headers.get('Content-Type', 'N/A')}\n"
        f"Response Body (first 1000 chars): {response.text[:1000]}"
    )
    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(error_message) from exc
    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _extract_error_message(payload: dict) -> str:
    """Extract a user-facing error message from common error response shapes."""
    if not isinstance(payload, dict):
        return str(payload)
    error_node = payload.get("error")
    if isinstance(error_node, dict):
        message = error_node.get("message")
        if message:
            return str(message)
    message = payload.get("message")
    if message:
        return str(message)
    return json.dumps(payload)


def _get_ai_search_resource_by_name(context, collection: str, resource_name: str) -> dict:
    """Fetch an Azure AI Search resource by name using the API wrapper's supported route."""
    encoded_name = quote(resource_name, safe="")
    candidate_endpoints = [
        f"/search/azure/{collection}('{encoded_name}')",
        f"/search/azure/{collection}/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.get(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    return get_json_response(context)


def _build_data_source_request_body(context, name: str, subscription_id: str, storage_resource_group: str, storage_account_name: str) -> dict:
    """Build request body for creating or updating an Azure AI Search data source."""
    return {
        "name": name,
        "type": "azureblob",
        "credentials": {
            "connectionString": (
                f"ResourceId=/subscriptions/{subscription_id}"
                f"/resourceGroups/{storage_resource_group}"
                f"/providers/Microsoft.Storage/storageAccounts/{storage_account_name};"
            ),
        },
        "container": {
            "name": "catalogs",
            "query": f"{context.catalog_id}/sources/{context.source_id}/raw",
        },
    }


# ============================================================
# SCENARIO 1 — Create a catalog for AI Search
# ============================================================

@given('the API client for AI Search is configured with region "{region}"')
def setup_ai_search_client(context, region):
    # Set up the API client so we can talk to the right region
    context.client = Service(region, timeout=90, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/rag/kpmg/catalog",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when('I create an AI Search catalog named "{catalog_name}"')
def create_ai_search_catalog(context, catalog_name):
    # Send a request to create a new catalog for the AI Search end-to-end pipeline
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_catalog_name = f"{catalog_name}_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    request_body = {"displayName": unique_catalog_name}
    context.request_url = context.client.base_url + "/rag/kpmg/catalog"
    context.request_params = None
    _request_with_retry(
        context,
        "post",
        "/rag/kpmg/catalog",
        json_body=request_body,
        params=None,
        max_attempts=4,
    )
    payload = get_json_response(context)
    context.catalog_id = payload.get("catalogId")
    _store(context, catalog_id=context.catalog_id)
    allure.attach(json.dumps(request_body, indent=2), name="catalog_request_body", attachment_type=allure.attachment_type.JSON)


@then("the AI Search catalog should be created successfully and catalog id should be saved")
def verify_catalog_created_ai_search(context):
    # Check the response: HTTP 200 means success, and we must have got back a catalog ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "catalog_id", None), "catalog_id was not returned in the response."
    allure.attach(str(context.catalog_id), name="catalog_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 2 — Create a catalog source for AI Search
# ============================================================

@given('the AI Search catalog is ready for AI Search in region "{region}" with name "{catalog_name}"')
def setup_ai_search_client_with_catalog(context, region, catalog_name):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Create Catalog) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/blob",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when('I create an AI Search catalog source with storage account "{storage_account_name}"')
def create_ai_search_catalog_source(context, storage_account_name):
    # Generate a SAS URI from the storage account name — same pattern as RAG files
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_source_name = f"Smoke_AI_Search_Source_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    sas_uri = generate_reg_source_sas_uri(storage_account_name)
    request_body = {
        "displayName": unique_source_name,
        "uri": sas_uri,
    }
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/blob"
    context.request_params = None
    context.last_response = context.client.post(
        f"/rag/kpmg/catalog/{context.catalog_id}/source/blob",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.source_id = payload.get("sourceId")
    _store(context, source_id=context.source_id)
    allure.attach(json.dumps(request_body, indent=2), name="catalog_source_request_body", attachment_type=allure.attachment_type.JSON)


@then("the AI Search catalog source should be created successfully and source id should be saved")
def verify_catalog_source_created_ai_search(context):
    # Check the response: HTTP 200 means success, and we must have got back a source ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "source_id", None), "source_id was not returned in the response."
    allure.attach(str(context.source_id), name="source_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 3 — Start Ingestion Job
# ============================================================

@given('the AI Search catalog and source are ready for ingestion in region "{region}" with name "{catalog_name}"')
def setup_ai_search_client_with_catalog_and_source(context, region, catalog_name):
    _restore(context, region, "catalog_id", "source_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Create Catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 2 (Create Catalog Source) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I start an AI Search ingestion job")
def start_ai_search_ingestion(context):
    # Send a request to kick off the ingestion job for the catalog
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest"
    context.request_params = None
    context.last_response = context.client.post(
        f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.ingestion_job_id = payload.get("ingestionJobId")
    _store(context, ingestion_job_id=context.ingestion_job_id)
    allure.attach(str(context.ingestion_job_id), name="ingestion_job_id", attachment_type=allure.attachment_type.TEXT)


@then("the AI Search ingestion job should be accepted and ingestion job id should be saved")
def verify_ingestion_started_ai_search(context):
    # Check the response: HTTP 202 (Accepted) means the job was queued, and we must have a job ID
    assert context.last_status_code == 202, f"Expected HTTP 202 but got {context.last_status_code}"
    assert getattr(context, "ingestion_job_id", None), "ingestion_job_id was not returned in the response."
    allure.attach(str(context.ingestion_job_id), name="ingestion_job_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 4 — Poll Ingestion Jobs until complete
# ============================================================

@given('the AI Search ingestion job is running in region "{region}" with name "{catalog_name}"')
def setup_ai_search_client_with_ingestion(context, region, catalog_name):
    _restore(context, region, "catalog_id", "source_id", "ingestion_job_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Create Catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 2 (Create Catalog Source) must pass before this step."
    )
    assert getattr(context, "ingestion_job_id", None), (
        "ingestion_job_id is missing — Scenario 3 (Start Ingestion Job) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I poll the ingestion jobs for the AI Search catalog until complete")
def poll_ingestion_jobs(context):
    # Keep checking every 5 seconds until ingestion finishes or we run out of attempts
    max_attempts = 120   # 120 × 5 s = 10 min max
    poll_interval = 5

    for attempt in range(1, max_attempts + 1):
        context.last_response = context.client.get(
            f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}",
            headers=context.headers,
        )
        context.last_status_code = context.last_response.status_code
        payload = get_json_response(context)
        context.ingestion_status = payload.get("ingestionStatus")

        print(f"Attempt {attempt}/{max_attempts} — ingestion status: {context.ingestion_status}")
        allure.attach(
            f"Attempt {attempt} — Status: {context.ingestion_status}",
            name="ingestion_poll",
            attachment_type=allure.attachment_type.TEXT,
        )

        # Stop polling as soon as we reach a final status (pass or fail)
        if context.ingestion_status in ("Ingested", "IngestionFailed"):
            _store(context, ingestion_status=context.ingestion_status)
            return

        time.sleep(poll_interval)

    raise AssertionError(
        f"Ingestion did not finish after {max_attempts} attempts "
        f"({max_attempts * poll_interval}s). Last status: {context.ingestion_status}"
    )


@then("the ingestion job status should eventually be completed")
def verify_ingestion_completed(context):
    # Confirm the final status is "Ingested" (not "IngestionFailed")
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert context.ingestion_status == "Ingested", (
        f"Expected ingestion status 'Ingested' but got '{context.ingestion_status}'"
    )
    _attach_ingested_raw_file_names(context)


# ============================================================
# SCENARIO 5 — Create Data Source (Azure AI Search)
# ============================================================

@given('the AI Search ingestion is complete in region "{region}"')
def setup_ai_search_client_post_ingestion(context, region):
    # Fail immediately if Scenarios 1 or 2 did not complete successfully
    _restore(context, region, "catalog_id", "source_id", "ingestion_status")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Create Catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 2 (Create Catalog Source) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/datasources?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when(
    'I create an AI Search data source with subscriptionId "{subscription_id}" '
    'storageResourceGroup "{storage_resource_group}" storageAccountName "{storage_account_name}"'
)
def create_ai_search_data_source(context, subscription_id, storage_resource_group, storage_account_name):
    # Send a request to create the Azure AI Search data source pointing to the catalog's blob container
    data_source_name = f"ds-{context.catalog_id}-{context.source_id}"
    request_body = _build_data_source_request_body(
        context,
        data_source_name,
        subscription_id,
        storage_resource_group,
        storage_account_name,
    )
    context.request_url = context.client.base_url + "/search/azure/datasources?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/datasources",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.data_source_name = payload.get("name") or data_source_name
    _store(
        context,
        data_source_name=context.data_source_name,
        subscription_id=subscription_id,
        storage_resource_group=storage_resource_group,
        storage_account_name=storage_account_name,
    )
    allure.attach(json.dumps(request_body, indent=2), name="data_source_request_body", attachment_type=allure.attachment_type.JSON)


@then("the data source should be created successfully and data source name should be saved")
def verify_data_source_created(context):
    # Check the response: HTTP 201 means the data source was created
    assert context.last_status_code == 201, f"Expected HTTP 201 but got {context.last_status_code}"
    assert getattr(context, "data_source_name", None), "data_source_name was not returned in the response."
    allure.attach(str(context.data_source_name), name="data_source_name", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 6 — Get Data Source by Name (Azure AI Search)
# ============================================================

@given('the AI Search data source has been created in region "{region}"')
def setup_ai_search_client_with_existing_data_source(context, region):
    # Fail immediately if Scenario 5 did not complete successfully
    _restore(context, region, "data_source_name")
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Scenario 5 (Create Data Source) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/datasources('{context.data_source_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the AI Search data source by name")
def get_ai_search_data_source_by_name(context):
    context.last_payload = _get_ai_search_resource_by_name(context, "datasources", context.data_source_name)


@then("the data source should be fetched successfully by name")
def verify_data_source_fetched_by_name(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    returned_name = context.last_payload.get("name")
    assert returned_name == context.data_source_name, (
        f"Expected data source name '{context.data_source_name}' but got '{returned_name}'"
    )


# ============================================================
# SCENARIO 7 — Create or Update Data Source (Azure AI Search)
# ============================================================

@given('the AI Search data source is ready to be updated in region "{region}"')
def setup_ai_search_client_for_update_data_source(context, region):
    _restore(
        context,
        region,
        "data_source_name",
        "catalog_id",
        "source_id",
        "subscription_id",
        "storage_resource_group",
        "storage_account_name",
    )
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Create Data Source scenario must pass before this step."
    )
    assert getattr(context, "subscription_id", None), "subscription_id missing from create data source scenario."
    assert getattr(context, "storage_resource_group", None), "storage_resource_group missing from create data source scenario."
    assert getattr(context, "storage_account_name", None), "storage_account_name missing from create data source scenario."

    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    context.updated_data_source_name = f"updated-{context.data_source_name}"
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/datasources('{context.updated_data_source_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create or update the AI Search data source with updated name")
def create_or_update_ai_search_data_source(context):
    request_body = _build_data_source_request_body(
        context,
        context.updated_data_source_name,
        context.subscription_id,
        context.storage_resource_group,
        context.storage_account_name,
    )
    encoded_name = quote(context.updated_data_source_name, safe="")
    candidate_endpoints = [
        f"/search/azure/datasources('{encoded_name}')",
        f"/search/azure/datasources/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.put(
            endpoint,
            json=request_body,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    payload = get_json_response(context)
    context.data_source_name = payload.get("name") or context.updated_data_source_name
    _store(context, data_source_name=context.data_source_name)
    allure.attach(
        json.dumps(request_body, indent=2),
        name="update_data_source_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the data source should be created or updated successfully")
def verify_data_source_updated(context):
    assert context.last_status_code in (200, 201), f"Expected HTTP 200 or 201 but got {context.last_status_code}"
    assert getattr(context, "data_source_name", None), "Updated data source name was not returned in response."


# ============================================================
# SCENARIO 8 — List Data Sources (Azure AI Search)
# ============================================================

@given('the AI Search data source is ready to be listed in region "{region}"')
def setup_ai_search_client_for_list_data_sources(context, region):
    _restore(context, region, "data_source_name")
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Update Data Source scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/datasources?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all AI Search data sources")
def list_all_ai_search_data_sources(context):
    context.request_url = context.client.base_url + "/search/azure/datasources?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.get(
        "/search/azure/datasources",
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)


@then("the updated AI Search data source should be present in the list")
def verify_data_source_present_in_list(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    items = context.last_payload.get("value") or []
    returned_names = [item.get("name") for item in items if item.get("name")]
    assert context.data_source_name in returned_names, (
        f"Expected updated data source '{context.data_source_name}' in list response. "
        f"Found names: {returned_names[:20]}"
    )


# ============================================================
# SCENARIO 9 — Create Index (Azure AI Search)
# ============================================================

@given('the AI Search data source is ready in region "{region}"')
def setup_ai_search_client_with_data_source(context, region):
    # Fail immediately if Scenario 5 did not complete successfully
    _restore(context, region, "data_source_name", "catalog_id", "source_id")
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Scenario 5 (Create Data Source) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexes?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


_EMBEDDING_CONFIG_BY_REGION = {
    "eastus": {
        "deploymentId": "text-embedding-3-small-1-std-eus",
    },
    "australiaeast": {
        "deploymentId": "text-embedding-3-small-1-std-ae",
    },
    "westeurope": {
        "deploymentId": "text-embedding-3-small-1-gs-sdc",
    },
}


def _build_index_request_body(context, index_name: str) -> dict:
    """Build request body for creating or updating an Azure AI Search index."""
    region = context.headers.get("x-kpmg-region-override")
    assert region and region in _EMBEDDING_CONFIG_BY_REGION, (
        f"No embedding config defined for region '{region}'. Expected one of: {list(_EMBEDDING_CONFIG_BY_REGION)}"
    )
    embedding_config = _EMBEDDING_CONFIG_BY_REGION[region]
    return {
        "name": index_name,
        "fields": [
            {
                "name": "id",
                "type": "Edm.String",
                "key": True,
                "searchable": True,
                "filterable": True,
                "retrievable": True,
                "sortable": True,
                "facetable": False,
                "analyzer": "keyword",
            },
            {
                "name": "parent_id",
                "type": "Edm.String",
                "searchable": False,
                "filterable": True,
                "retrievable": True,
                "sortable": True,
                "facetable": False,
            },
            {
                "name": "content",
                "type": "Edm.String",
                "searchable": True,
                "filterable": False,
                "retrievable": True,
                "sortable": False,
                "facetable": False,
            },
            {
                "name": "metadata_storage_name",
                "type": "Edm.String",
                "searchable": True,
                "filterable": True,
                "retrievable": True,
                "sortable": True,
                "facetable": False,
            },
            {
                "name": "metadata_storage_path",
                "type": "Edm.String",
                "searchable": False,
                "filterable": True,
                "retrievable": True,
                "sortable": True,
                "facetable": False,
            },
            {
                "name": "contentVector",
                "type": "Collection(Edm.Single)",
                "searchable": True,
                "filterable": False,
                "retrievable": True,
                "sortable": False,
                "facetable": False,
                "dimensions": 1536,
                "vectorSearchProfile": "my-vector-profile",
            },
        ],
        "suggesters": [
            {
                "name": "sg",
                "searchMode": "analyzingInfixMatching",
                "sourceFields": ["content", "metadata_storage_name"],
            }
        ],
        "vectorSearch": {
            "algorithms": [
                {
                    "name": "my-hnsw",
                    "kind": "hnsw",
                    "hnswParameters": {
                        "metric": "cosine",
                        "m": 4,
                        "efConstruction": 400,
                        "efSearch": 500,
                    },
                }
            ],
            "profiles": [
                {
                    "name": "my-vector-profile",
                    "algorithm": "my-hnsw",
                    "vectorizer": "my-openai-vectorizer",
                }
            ],
            "vectorizers": [
                {
                    "name": "my-openai-vectorizer",
                    "kind": "azureOpenAI",
                    "azureOpenAIParameters": {
                        "resourceUri": "https://aif-wb-apac-aue-dv.openai.azure.com",
                        "deploymentId": embedding_config["deploymentId"],
                        "modelName": "text-embedding-3-small",
                    },
                }
            ],
        },
    }


def _build_skillset_request_body(context, skillset_name: str) -> dict:
    """Build request body for creating or updating an Azure AI Search skillset."""
    region = context.headers.get("x-kpmg-region-override")
    assert region and region in _EMBEDDING_CONFIG_BY_REGION, (
        f"No embedding config defined for region '{region}'. Expected one of: {list(_EMBEDDING_CONFIG_BY_REGION)}"
    )
    deployment_id = _EMBEDDING_CONFIG_BY_REGION[region]["deploymentId"]
    return {
        "name": skillset_name,
        "description": "creating skillset",
        "skills": [
            {
                "@odata.type": "#Microsoft.Skills.Text.SplitSkill",
                "name": "chunking-skill",
                "context": "/document",
                "defaultLanguageCode": "en",
                "textSplitMode": "pages",
                "maximumPageLength": 2000,
                "pageOverlapLength": 500,
                "inputs": [
                    {"name": "text", "source": "/document/content"},
                ],
                "outputs": [
                    {"name": "textItems", "targetName": "pages"},
                ],
            },
            {
                "@odata.type": "#Microsoft.Skills.Text.AzureOpenAIEmbeddingSkill",
                "name": "vectorizing-skill",
                "context": "/document/pages/*",
                "resourceUri": "https://aif-wb-apac-aue-dv.openai.azure.com",
                "deploymentId": deployment_id,
                "dimensions": 1536,
                "modelName": "text-embedding-3-small",
                "inputs": [
                    {"name": "text", "source": "/document/pages/*"},
                ],
                "outputs": [
                    {"name": "embedding", "targetName": "vector"},
                ],
            },
        ],
        "indexProjections": {
            "selectors": [
                {
                    "targetIndexName": context.index_name,
                    "parentKeyFieldName": "parent_id",
                    "sourceContext": "/document/pages/*",
                    "mappings": [
                        {"name": "content", "source": "/document/pages/*"},
                        {"name": "contentVector", "source": "/document/pages/*/vector"},
                        {"name": "metadata_storage_name", "source": "/document/metadata_storage_name"},
                        {"name": "metadata_storage_path", "source": "/document/metadata_storage_path"},
                    ],
                }
            ],
            "parameters": {
                "projectionMode": "skipIndexingParentDocuments",
            },
        },
    }


@when("I create an AI Search index")
def create_ai_search_index(context):
    # Send a request to create the Azure AI Search index with all required fields
    desired_index_name = f"index-{context.catalog_id}-{context.source_id}"
    request_body = _build_index_request_body(context, desired_index_name)
    context.request_url = context.client.base_url + "/search/azure/indexes?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/indexes",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.index_name = payload.get("name") or desired_index_name
    _store(context, index_name=context.index_name)
    allure.attach(json.dumps(request_body, indent=2), name="index_request_body", attachment_type=allure.attachment_type.JSON)


@then("the index should be created successfully and index name should be saved")
def verify_index_created(context):
    # Check the response: HTTP 201 means the index was created
    assert context.last_status_code == 201, f"Expected HTTP 201 but got {context.last_status_code}"
    assert getattr(context, "index_name", None), "index_name was not returned in the response."
    allure.attach(str(context.index_name), name="index_name", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 10 — Get Index by Name (Azure AI Search)
# ============================================================

@given('the AI Search index has been created in region "{region}"')
def setup_ai_search_client_with_existing_index(context, region):
    # Fail immediately if Scenario 9 did not complete successfully
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexes('{context.index_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the AI Search index by name")
def get_ai_search_index_by_name(context):
    context.last_payload = _get_ai_search_resource_by_name(context, "indexes", context.index_name)


@then("the index should be fetched successfully by name")
def verify_index_fetched_by_name(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    returned_name = context.last_payload.get("name")
    assert returned_name == context.index_name, (
        f"Expected index name '{context.index_name}' but got '{returned_name}'"
    )


# ============================================================
# SCENARIO 11 — Create or Update Index (Azure AI Search)
# ============================================================

@given('the AI Search index is ready to be updated in region "{region}"')
def setup_ai_search_client_for_update_index(context, region):
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    context.updated_index_name = f"updated-{context.index_name}"
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexes('{context.updated_index_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create or update the AI Search index with updated name")
def create_or_update_ai_search_index(context):
    request_body = _build_index_request_body(context, context.updated_index_name)
    encoded_name = quote(context.updated_index_name, safe="")
    candidate_endpoints = [
        f"/search/azure/indexes('{encoded_name}')",
        f"/search/azure/indexes/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.put(
            endpoint,
            json=request_body,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    payload = get_json_response(context)
    context.index_name = payload.get("name") or context.updated_index_name
    _store(context, index_name=context.index_name)
    allure.attach(json.dumps(request_body, indent=2), name="update_index_request_body", attachment_type=allure.attachment_type.JSON)


@then("the index should be created or updated successfully")
def verify_index_updated(context):
    assert context.last_status_code in (200, 201), f"Expected HTTP 200 or 201 but got {context.last_status_code}"
    assert getattr(context, "index_name", None), "Updated index name was not returned in the response."


# ============================================================
# SCENARIO 12 — List Indexes (Azure AI Search)
# ============================================================

@given('the AI Search index is ready to be listed in region "{region}"')
def setup_ai_search_client_for_list_indexes(context, region):
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 11 (Create or Update Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexes?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all AI Search indexes")
def list_all_ai_search_indexes(context):
    context.request_url = context.client.base_url + "/search/azure/indexes?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.get(
        "/search/azure/indexes",
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)


@then("the updated AI Search index should be present in the list")
def verify_index_present_in_list(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    items = context.last_payload.get("value") or []
    returned_names = [item.get("name") for item in items if item.get("name")]
    assert context.index_name in returned_names, (
        f"Expected updated index '{context.index_name}' in list response. Found names: {returned_names[:20]}"
    )


# ============================================================
# SCENARIO 13 — Get Index Statistics (Azure AI Search)
# ============================================================

@given('the AI Search index is ready for statistics in region "{region}"')
def setup_ai_search_client_for_index_statistics(context, region):
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 11 (Create or Update Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexes('{context.index_name}')/search.stats?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get AI Search index statistics by name")
def get_ai_search_index_statistics(context):
    encoded_name = quote(context.index_name, safe="")
    candidate_endpoints = [
        f"/search/azure/indexes('{encoded_name}')/search.stats",
        f"/search/azure/indexes/{encoded_name}/search.stats",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.get(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    context.last_payload = get_json_response(context)


@then("the index statistics should be fetched successfully")
def verify_index_statistics_fetched(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert "documentCount" in context.last_payload, "documentCount is missing in index stats response."
    assert "storageSize" in context.last_payload, "storageSize is missing in index stats response."


# ============================================================
# SCENARIO 14 — Analyze Text with Index Analyzer (Azure AI Search)
# ============================================================

@given('the AI Search index is ready for text analysis in region "{region}"')
def setup_ai_search_client_for_index_analyze(context, region):
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 11 (Create or Update Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexes('{context.index_name}')/search.analyze?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I analyze text using the AI Search index analyzer")
def analyze_text_with_ai_search_index(context):
    encoded_name = quote(context.index_name, safe="")
    request_body = {
        "analyzer": "en.microsoft",
        "text": "What is the content of the uploaded file",
    }
    candidate_endpoints = [
        f"/search/azure/indexes('{encoded_name}')/search.analyze",
        f"/search/azure/indexes/{encoded_name}/search.analyze",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.post(
            endpoint,
            json=request_body,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    context.last_payload = get_json_response(context)
    allure.attach(json.dumps(request_body, indent=2), name="analyze_request_body", attachment_type=allure.attachment_type.JSON)


@then("the text should be analyzed successfully")
def verify_text_analyzed_successfully(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert isinstance(context.last_payload.get("tokens"), list), "Expected tokens list in analyze response."


# ============================================================
# SCENARIO 15 — Create Skillset (Azure AI Search)
# ============================================================

@given('the AI Search index is ready in region "{region}"')
def setup_ai_search_client_with_index(context, region):
    # Fail immediately if Scenario 9 did not complete successfully
    _restore(context, region, "index_name", "catalog_id", "source_id")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create an AI Search skillset")
def create_ai_search_skillset(context):
    # Send a request to create the skillset with a split skill and an OpenAI embedding skill
    desired_skillset_name = f"skillset-{context.catalog_id}-{context.source_id}"
    request_body = _build_skillset_request_body(context, desired_skillset_name)
    context.request_url = context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/skillsets",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.skillset_name = payload.get("name") or desired_skillset_name
    _store(context, skillset_name=context.skillset_name)
    allure.attach(json.dumps(request_body, indent=2), name="skillset_request_body", attachment_type=allure.attachment_type.JSON)


@then("the skillset should be created successfully and skillset name should be saved")
def verify_skillset_created(context):
    # Check the response: HTTP 201 means the skillset was created
    assert context.last_status_code == 201, f"Expected HTTP 201 but got {context.last_status_code}"
    assert getattr(context, "skillset_name", None), "skillset_name was not returned in the response."
    allure.attach(str(context.skillset_name), name="skillset_name", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 16 — Get Skillset by Name (Azure AI Search)
# ============================================================

@given('the AI Search skillset has been created in region "{region}"')
def setup_ai_search_client_with_existing_skillset(context, region):
    # Fail immediately if Scenario 15 did not complete successfully
    _restore(context, region, "skillset_name")
    assert getattr(context, "skillset_name", None), (
        "skillset_name is missing — Scenario 15 (Create Skillset) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/skillsets('{context.skillset_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the AI Search skillset by name")
def get_ai_search_skillset_by_name(context):
    context.last_payload = _get_ai_search_resource_by_name(context, "skillsets", context.skillset_name)


@then("the skillset should be fetched successfully by name")
def verify_skillset_fetched_by_name(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    returned_name = context.last_payload.get("name")
    assert returned_name == context.skillset_name, (
        f"Expected skillset name '{context.skillset_name}' but got '{returned_name}'"
    )


# ============================================================
# SCENARIO 17 — Create or Update Skillset (Azure AI Search)
# ============================================================

@given('the AI Search skillset is ready to be updated in region "{region}"')
def setup_ai_search_client_for_update_skillset(context, region):
    _restore(context, region, "skillset_name", "index_name")
    assert getattr(context, "skillset_name", None), (
        "skillset_name is missing — Scenario 15 (Create Skillset) must pass before this step."
    )
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    context.updated_skillset_name = f"updated-{context.skillset_name}"
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/skillsets('{context.updated_skillset_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create or update the AI Search skillset with updated name")
def create_or_update_ai_search_skillset(context):
    request_body = _build_skillset_request_body(context, context.updated_skillset_name)
    encoded_name = quote(context.updated_skillset_name, safe="")
    candidate_endpoints = [
        f"/search/azure/skillsets('{encoded_name}')",
        f"/search/azure/skillsets/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.put(
            endpoint,
            json=request_body,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    payload = get_json_response(context)
    context.skillset_name = payload.get("name") or context.updated_skillset_name
    _store(context, skillset_name=context.skillset_name)
    allure.attach(
        json.dumps(request_body, indent=2),
        name="update_skillset_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the skillset should be created or updated successfully")
def verify_skillset_updated(context):
    assert context.last_status_code in (200, 201), f"Expected HTTP 200 or 201 but got {context.last_status_code}"
    assert getattr(context, "skillset_name", None), "Updated skillset name was not returned in response."


# ============================================================
# SCENARIO 18 — List Skillsets (Azure AI Search)
# ============================================================

@given('the AI Search skillset is ready to be listed in region "{region}"')
def setup_ai_search_client_for_list_skillsets(context, region):
    _restore(context, region, "skillset_name")
    assert getattr(context, "skillset_name", None), (
        "skillset_name is missing — Scenario 17 (Create or Update Skillset) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all AI Search skillsets")
def list_all_ai_search_skillsets(context):
    context.request_url = context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.get(
        "/search/azure/skillsets",
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)


@then("the updated AI Search skillset should be present in the list")
def verify_skillset_present_in_list(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    items = context.last_payload.get("value") or []
    returned_names = [item.get("name") for item in items if item.get("name")]
    assert context.skillset_name in returned_names, (
        f"Expected updated skillset '{context.skillset_name}' in list response. Found names: {returned_names[:20]}"
    )


# ============================================================
# SCENARIO 19 — Create Indexer (Azure AI Search)
# ============================================================

@given('the AI Search skillset is ready in region "{region}"')
def setup_ai_search_client_with_skillset(context, region):
    # Fail immediately if Scenarios 5, 9, or 15 did not complete successfully
    _restore(context, region, "data_source_name", "index_name", "skillset_name", "catalog_id", "source_id")
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Scenario 5 (Create Data Source) must pass before this step."
    )
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexers?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


def _build_indexer_request_body(context, indexer_name: str) -> dict:
    """Build request body for creating or updating an Azure AI Search indexer."""
    return {
        "name": indexer_name,
        "dataSourceName": context.data_source_name,
        "targetIndexName": context.index_name,
        "skillsetName": context.skillset_name,
        "parameters": {
            "configuration": {
                "dataToExtract": "contentAndMetadata",
                "parsingMode": "default",
            },
        },
        "fieldMappings": [
            {
                "sourceFieldName": "metadata_storage_name",
                "targetFieldName": "metadata_storage_name",
            },
            {
                "sourceFieldName": "metadata_storage_path",
                "targetFieldName": "metadata_storage_path",
            },
        ],
        "outputFieldMappings": [],
    }


@when("I create an AI Search indexer")
def create_ai_search_indexer(context):
    # Send a request to create the indexer that wires together data source, index, and skillset
    desired_indexer_name = f"indexer-{context.catalog_id}-{context.source_id}"
    request_body = _build_indexer_request_body(context, desired_indexer_name)
    context.request_url = context.client.base_url + "/search/azure/indexers?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/indexers",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.indexer_name = payload.get("name") or desired_indexer_name
    _store(context, indexer_name=context.indexer_name)
    allure.attach(json.dumps(request_body, indent=2), name="indexer_request_body", attachment_type=allure.attachment_type.JSON)


@then("the indexer should be created successfully and indexer name should be saved")
def verify_indexer_created(context):
    # Check the response: HTTP 201 means the indexer was created
    assert context.last_status_code == 201, f"Expected HTTP 201 but got {context.last_status_code}"
    assert getattr(context, "indexer_name", None), "indexer_name was not returned in the response."
    allure.attach(str(context.indexer_name), name="indexer_name", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 20 — Get Indexer by Name (Azure AI Search)
# ============================================================

@given('the AI Search indexer has been created in region "{region}"')
def setup_ai_search_client_with_existing_indexer(context, region):
    # Fail immediately if Scenario 19 did not complete successfully
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 19 (Create Indexer) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexers('{context.indexer_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the AI Search indexer by name")
def get_ai_search_indexer_by_name(context):
    context.last_payload = _get_ai_search_resource_by_name(context, "indexers", context.indexer_name)


@then("the indexer should be fetched successfully by name")
def verify_indexer_fetched_by_name(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    returned_name = context.last_payload.get("name")
    assert returned_name == context.indexer_name, (
        f"Expected indexer name '{context.indexer_name}' but got '{returned_name}'"
    )


# ============================================================
# SCENARIO 21 — Create or Update Indexer (Azure AI Search)
# ============================================================

@given('the AI Search indexer is ready to be updated in region "{region}"')
def setup_ai_search_client_for_update_indexer(context, region):
    _restore(
        context,
        region,
        "indexer_name",
        "data_source_name",
        "index_name",
        "skillset_name",
        "catalog_id",
        "source_id",
    )
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 19 (Create Indexer) must pass before this step."
    )
    assert getattr(context, "data_source_name", None), "data_source_name missing for indexer update."
    assert getattr(context, "index_name", None), "index_name missing for indexer update."
    assert getattr(context, "skillset_name", None), "skillset_name missing for indexer update."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    context.updated_indexer_name = f"updated-{context.indexer_name}"
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexers('{context.updated_indexer_name}')?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create or update the AI Search indexer with updated name")
def create_or_update_ai_search_indexer(context):
    request_body = _build_indexer_request_body(context, context.updated_indexer_name)
    encoded_name = quote(context.updated_indexer_name, safe="")
    candidate_endpoints = [
        f"/search/azure/indexers('{encoded_name}')",
        f"/search/azure/indexers/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.put(
            endpoint,
            json=request_body,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    payload = get_json_response(context)
    context.indexer_name = payload.get("name") or context.updated_indexer_name
    _store(context, indexer_name=context.indexer_name)
    allure.attach(
        json.dumps(request_body, indent=2),
        name="update_indexer_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the indexer should be created or updated successfully")
def verify_indexer_updated(context):
    assert context.last_status_code in (200, 201), f"Expected HTTP 200 or 201 but got {context.last_status_code}"
    assert getattr(context, "indexer_name", None), "Updated indexer name was not returned in response."


# ============================================================
# SCENARIO 22 — Get Indexer Status (Azure AI Search)
# ============================================================

@given('the AI Search indexer is ready for status in region "{region}"')
def setup_ai_search_client_for_indexer_status(context, region):
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 21 (Create or Update Indexer) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexers('{context.indexer_name}')/search.status?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the AI Search indexer status by name")
def get_ai_search_indexer_status_by_name(context):
    encoded_name = quote(context.indexer_name, safe="")
    status_endpoints = [
        f"/search/azure/indexers('{encoded_name}')/search.status",
        f"/search/azure/indexers/{encoded_name}/search.status",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in status_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.get(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break

    context.last_payload = get_json_response(context)


@then("the AI Search indexer status should be fetched successfully")
def verify_ai_search_indexer_status_fetched(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    status = context.last_payload.get("status") or (context.last_payload.get("lastResult") or {}).get("status")
    assert status, "Indexer status payload does not contain status/lastResult.status."


# ============================================================
# SCENARIO 23 — List Indexers (Azure AI Search)
# ============================================================

@given('the AI Search indexer is ready to be listed in region "{region}"')
def setup_ai_search_client_for_list_indexers(context, region):
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 21 (Create or Update Indexer) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexers?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all AI Search indexers")
def list_all_ai_search_indexers(context):
    context.request_url = context.client.base_url + "/search/azure/indexers?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.get(
        "/search/azure/indexers",
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)


@then("the updated AI Search indexer should be present in the list")
def verify_indexer_present_in_list(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    items = context.last_payload.get("value") or []
    returned_names = [item.get("name") for item in items if item.get("name")]
    assert context.indexer_name in returned_names, (
        f"Expected updated indexer '{context.indexer_name}' in list response. Found names: {returned_names[:20]}"
    )


# ============================================================
# SCENARIO 24 — Reset Indexer (Azure AI Search)
# ============================================================

@given('the AI Search indexer is ready to be reset in region "{region}"')
def setup_ai_search_client_for_reset_indexer(context, region):
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 21 (Create or Update Indexer) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexers('{context.indexer_name}')/search.reset?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I reset the AI Search indexer by name")
def reset_ai_search_indexer_by_name(context):
    encoded_name = quote(context.indexer_name, safe="")
    candidate_endpoints = [
        f"/search/azure/indexers('{encoded_name}')/search.reset",
        f"/search/azure/indexers/{encoded_name}/search.reset",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.post(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break


@then("the AI Search indexer should be reset successfully")
def verify_ai_search_indexer_reset(context):
    assert context.last_status_code in (200, 202, 204), f"Expected HTTP 200, 202, or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 25 — Run Indexer On-demand (Azure AI Search)
# ============================================================

@given('the AI Search indexer is ready to be run on-demand in region "{region}"')
def setup_ai_search_client_for_run_indexer_on_demand(context, region):
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 21 (Create or Update Indexer) must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/search/azure/indexers('{context.indexer_name}')/search.run?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I run the AI Search indexer on-demand")
def run_ai_search_indexer_on_demand(context):
    encoded_name = quote(context.indexer_name, safe="")
    candidate_endpoints = [
        f"/search/azure/indexers('{encoded_name}')/search.run",
        f"/search/azure/indexers/{encoded_name}/search.run",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.post(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code != 404:
            break


@then("the AI Search indexer run request should be accepted")
def verify_ai_search_indexer_run_request_accepted(context):
    assert context.last_status_code in (200, 202, 204), (
        f"Expected HTTP 200/202/204 for indexer run request but got {context.last_status_code}"
    )


# ============================================================
# SCENARIO 26 — Create Agent with AI Search Tool
# ============================================================

@given('the AI Search agents client is configured with region "{region}"')
def setup_ai_search_agents_client(context, region):
    # Fail immediately if Scenarios 19 and 9 did not complete successfully
    _restore(context, region, "indexer_name", "index_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Scenario 19 (Create Indexer) must pass before this step."
    )
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


_AGENT_CONFIG_BY_REGION = {
    "eastus": {
        "subscription_id": "52d41c4b-f44f-474d-8a17-39d0a6fcabfe",
        "resource_group": "rgp-aif-wb-amer-use-qa",
        "account": "aif-wb-amer-use-qa",
        "project": "aif-prj-wb-amer-use-qa",
        "connection": "aif-prj-wb-amer-use-qa-aisearch-aif-prj-wb-amer-use-qa",
    },
    "australiaeast": {
        "subscription_id": "773e5b57-1bf3-4f99-be79-910d12e3d329",
        "resource_group": "rgp-aif-wb-apac-aue-qa",
        "account": "aif-wb-apac-aue-qa",
        "project": "aif-prj-wb-apac-aue-qa",
        "connection": "aif-prj-wb-apac-aue-qa-aisearch-aif-prj-wb-apac-aue-qa",
    },
    "westeurope": {
        "subscription_id": "4322af52-c22c-456b-92ce-87dc4c530bc8",
        "resource_group": "rgp-aif-wb-emea-weu-qa",
        "account": "aif-wb-emea-weu-qa",
        "project": "aif-prj-wb-emea-weu-qa",
        "connection": "aif-prj-wb-emea-weu-qa-aisearch-aif-prj-wb-emea-weu-qa",
    },
}


_AGENTS_API_VERSION = "api-version=2025-05-15-preview"


@when('I create an AI Search agent named "{agent_name}" for project "{project_id}" with model "{model_name}"')
def create_ai_search_agent(context, agent_name, project_id, model_name):
    api_version = _AGENTS_API_VERSION
    # Send a request to create an agent configured to use azure_ai_search as its tool
    assert getattr(context, "index_name", None), (
        "index_name is missing — Scenario 9 (Create Index) must pass before creating the agent."
    )
    region = context.headers.get("x-kpmg-region-override")
    assert region and region in _AGENT_CONFIG_BY_REGION, (
        f"No agent config defined for region '{region}'. Expected one of: {list(_AGENT_CONFIG_BY_REGION)}"
    )
    agent_cfg = _AGENT_CONFIG_BY_REGION[region]
    project_connection_id = (
        f"/subscriptions/{agent_cfg['subscription_id']}"
        f"/resourceGroups/{agent_cfg['resource_group']}"
        f"/providers/Microsoft.CognitiveServices/accounts/{agent_cfg['account']}"
        f"/projects/{agent_cfg['project']}"
        f"/connections/{agent_cfg['connection']}"
    )
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_agent_name = f"{agent_name}_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    request_body = {
        "model": model_name,
        "name": unique_agent_name,
        "instructions": (
            "You are a helpful assistant with access to an AI Search index. "
            "If a user asks anything about files, documents, file names, file paths, or file contents, "
            "always call the azure_ai_search tool before answering."
        ),
        "AgentOwner": "go-cld-sulagnabehera@kpmgqa.com",
        "tools": [
            {
                "type": "azure_ai_search",
                "azure_ai_search": {
                    "indexes": [
                        {
                            "index_name": context.index_name,
                            "project_connection_id": project_connection_id,
                            "query_type": "vector_simple_hybrid",
                            "top_k": 5,
                        }
                    ],
                },
            }
        ],
    }
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/assistants?{api_version}"
    context.request_params = None
    context.last_response = context.client.post(
        f"/api/projects/{project_id}/assistants?{api_version}",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    assistant_id = payload.get("assistant_id") or payload.get("id")
    context.assistant_id = assistant_id
    context.config.assistant_id = assistant_id
    _store(context, assistant_id=assistant_id)
    allure.attach(json.dumps(request_body, indent=2), name="agent_request_body", attachment_type=allure.attachment_type.JSON)


@then("the agent should be created successfully and assistant id should be saved")
def verify_agent_created(context):
    # Check the response: HTTP 200 means success, and we must have got back an assistant ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "assistant_id", None), "assistant_id was not returned in the response."
    allure.attach(str(context.assistant_id), name="assistant_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 27 — Create Thread
# ============================================================

@given('the AI Search agent is ready in region "{region}"')
def setup_ai_search_client_with_agent(context, region):
    # Fail immediately if Scenario 26 did not complete successfully
    _restore(context, region, "assistant_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Scenario 26 (Create Agent) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
        "x-assistant-id": context.assistant_id,
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I create an AI Search thread for project "{project_id}"')
def create_ai_search_thread(context, project_id):
    api_version = _AGENTS_API_VERSION
    # Send a request to create a thread with the assistant and an initial greeting message
    assistant_id = (
        getattr(context, "assistant_id", None)
        or getattr(context.config, "assistant_id", None)
    )
    assert assistant_id, "No assistant_id available. Run Scenario 26 (Create Agent) first."
    request_body = {
        "assistant_id": assistant_id,
        "messages": [
            {
                "role": "user",
                "content": "Hi Buddy..!!Whats up?",
            }
        ],
        "metadata": {
            "qa-purpose": "automated-test",
        },
    }
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/threads?{api_version}"
    context.request_params = None
    context.last_response = context.client.post(
        f"/api/projects/{project_id}/threads?{api_version}",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    thread_id = payload.get("thread_id") or payload.get("id")
    context.thread_id = thread_id
    context.config.thread_id = thread_id
    _store(context, thread_id=thread_id)
    allure.attach(json.dumps(request_body, indent=2), name="thread_request_body", attachment_type=allure.attachment_type.JSON)


@then("the thread should be created successfully and thread id should be saved")
def verify_thread_created(context):
    # Check the response: HTTP 200 means success, and we must have got back a thread ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "thread_id", None), "thread_id was not returned in the response."
    allure.attach(str(context.thread_id), name="thread_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 28 — Create Message
# ============================================================

@given('the AI Search thread is ready in region "{region}"')
def setup_ai_search_client_with_thread(context, region):
    # Fail immediately if Scenarios 9 or 10 did not complete successfully
    _restore(context, region, "assistant_id", "thread_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Scenario 26 (Create Agent) must pass before this step."
    )
    assert getattr(context, "thread_id", None), (
        "thread_id is missing — Scenario 27 (Create Thread) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
        "x-assistant-id": context.assistant_id,
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I create an AI Search message for project "{project_id}"')
def create_ai_search_message(context, project_id):
    api_version = _AGENTS_API_VERSION
    # Send a request to post a user message to the thread
    thread_id = (
        getattr(context, "thread_id", None)
        or getattr(context.config, "thread_id", None)
    )
    assert thread_id, "No thread_id available. Run Scenario 27 (Create Thread) first."
    request_body = {
        "role": "user",
        "content": "Tell me the ADF key components and short description on it.",
    }
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/threads/{thread_id}/messages?{api_version}"
    context.request_params = None
    context.last_response = context.client.post(
        f"/api/projects/{project_id}/threads/{thread_id}/messages?{api_version}",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.message_id = payload.get("message_id") or payload.get("id")
    _store(context, message_id=context.message_id)
    allure.attach(json.dumps(request_body, indent=2), name="message_request_body", attachment_type=allure.attachment_type.JSON)


@then("the message should be created successfully and message id should be saved")
def verify_message_created(context):
    # Check the response: HTTP 200 means success, and we must have got back a message ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "message_id", None), "message_id was not returned in the response."
    allure.attach(str(context.message_id), name="message_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 29 — Create Run
# ============================================================

@given('the AI Search thread is ready for run in region "{region}"')
def setup_ai_search_client_with_thread_for_run(context, region):
    # Fail immediately if Scenarios 9 or 10 did not complete successfully
    _restore(context, region, "assistant_id", "thread_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Scenario 26 (Create Agent) must pass before this step."
    )
    assert getattr(context, "thread_id", None), (
        "thread_id is missing — Scenario 27 (Create Thread) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I create an AI Search run for project "{project_id}"')
def create_ai_search_run(context, project_id):
    api_version = _AGENTS_API_VERSION
    # Send a request to kick off a run for the thread with the assistant
    assistant_id = (
        getattr(context, "assistant_id", None)
        or getattr(context.config, "assistant_id", None)
    )
    thread_id = (
        getattr(context, "thread_id", None)
        or getattr(context.config, "thread_id", None)
    )
    assert assistant_id, "No assistant_id available. Run Scenario 26 (Create Agent) first."
    assert thread_id, "No thread_id available. Run Scenario 27 (Create Thread) first."
    request_body = {
        "assistant_id": assistant_id,
        "instructions": "Creating run",
        "metadata": {
            "qa-purpose": "automated-test",
        },
    }
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/threads/{thread_id}/runs?{api_version}"
    context.request_params = None
    context.last_response = context.client.post(
        f"/api/projects/{project_id}/threads/{thread_id}/runs?{api_version}",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    run_id = payload.get("run_id") or payload.get("id")
    context.run_id = run_id
    context.config.run_id = run_id
    _store(context, run_id=run_id)
    allure.attach(json.dumps(request_body, indent=2), name="run_request_body", attachment_type=allure.attachment_type.JSON)


@then("the run should be created successfully and run id should be saved")
def verify_run_created(context):
    # Check the response: HTTP 200 means success, and we must have got back a run ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "run_id", None), "run_id was not returned in the response."
    allure.attach(str(context.run_id), name="run_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 30 — Poll Run until complete (Get Run)
# ============================================================

@given('the AI Search run is started in region "{region}"')
def setup_ai_search_client_with_run(context, region):
    # Fail immediately if Scenarios 10 or 12 did not complete successfully
    _restore(context, region, "thread_id", "run_id")
    assert getattr(context, "thread_id", None), (
        "thread_id is missing — Scenario 27 (Create Thread) must pass before this step."
    )
    assert getattr(context, "run_id", None), (
        "run_id is missing — Scenario 29 (Create Run) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I poll the AI Search run until complete for project "{project_id}"')
def poll_ai_search_run(context, project_id):
    api_version = _AGENTS_API_VERSION
    # Keep checking every 5 seconds until the run reaches a terminal status
    thread_id = (
        getattr(context, "thread_id", None)
        or getattr(context.config, "thread_id", None)
    )
    run_id = (
        getattr(context, "run_id", None)
        or getattr(context.config, "run_id", None)
    )
    assert thread_id, "thread_id is missing — Scenario 27 (Create Thread) must pass first."
    assert run_id, "run_id is missing — Scenario 29 (Create Run) must pass first."

    max_attempts = 60   # 60 × 5 s = 5 min max
    poll_interval = 5
    terminal_statuses = {"completed", "failed", "cancelled", "expired"}

    for attempt in range(1, max_attempts + 1):
        context.last_response = context.client.get(
            f"/api/projects/{project_id}/threads/{thread_id}/runs/{run_id}?{api_version}",
            headers=context.headers,
        )
        context.last_status_code = context.last_response.status_code
        payload = get_json_response(context)
        context.run_status = payload.get("status", "")

        print(f"Attempt {attempt}/{max_attempts} — run status: {context.run_status}")
        allure.attach(
            f"Attempt {attempt} — Run Status: {context.run_status}",
            name="run_poll",
            attachment_type=allure.attachment_type.TEXT,
        )

        # Stop polling as soon as we reach a terminal status
        if context.run_status.lower() in terminal_statuses:
            return

        time.sleep(poll_interval)

    raise AssertionError(
        f"Run did not reach a terminal status after {max_attempts} attempts "
        f"({max_attempts * poll_interval}s). Last status: {context.run_status}"
    )


@then("the AI Search run status should eventually be completed")
def verify_run_completed(context):
    # Confirm the final run status is "completed" (not failed, cancelled, or expired)
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert context.run_status.lower() == "completed", (
        f"Expected run status 'completed' but got '{context.run_status}'"
    )


# ============================================================
# SCENARIO 31 — List Messages
# ============================================================

@given('the AI Search run is complete in region "{region}"')
def setup_ai_search_client_for_list_messages(context, region):
    # Fail immediately if Scenarios 9 or 10 did not complete successfully
    _restore(context, region, "assistant_id", "thread_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Scenario 26 (Create Agent) must pass before this step."
    )
    assert getattr(context, "thread_id", None), (
        "thread_id is missing — Scenario 27 (Create Thread) must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
        "x-assistant-id": context.assistant_id,
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I list messages in the AI Search thread for project "{project_id}"')
def list_ai_search_messages(context, project_id):
    api_version = _AGENTS_API_VERSION
    # Send a GET request to list all messages in the thread
    thread_id = (
        getattr(context, "thread_id", None)
        or getattr(context.config, "thread_id", None)
    )
    assert thread_id, "No thread_id available. Run Scenario 27 (Create Thread) first."
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/threads/{thread_id}/messages?{api_version}"
    context.request_params = None
    context.last_response = context.client.get(
        f"/api/projects/{project_id}/threads/{thread_id}/messages?{api_version}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    get_json_response(context)


@then("the messages should be listed successfully")
def verify_messages_listed(context):
    # Check the response: HTTP 200 means the messages were listed successfully
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"


# ============================================================
# SCENARIO 32 — Delete Thread
# ============================================================

@given('the AI Search thread is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_thread(context, region):
    _restore(context, region, "assistant_id", "thread_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Create Agent scenario must pass before this step."
    )
    assert getattr(context, "thread_id", None), (
        "thread_id is missing — Create Thread scenario must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
        "x-assistant-id": context.assistant_id,
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I delete the AI Search thread for project "{project_id}"')
def delete_ai_search_thread(context, project_id):
    api_version = _AGENTS_API_VERSION
    thread_id = getattr(context, "thread_id", None) or getattr(context.config, "thread_id", None)
    assert thread_id, "No thread_id available. Run Create Thread scenario first."
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/threads/{thread_id}?{api_version}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/api/projects/{project_id}/threads/{thread_id}?{api_version}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the AI Search thread should be deleted successfully")
def verify_ai_search_thread_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 33 — Delete Agent
# ============================================================

@given('the AI Search agent is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_agent(context, region):
    _restore(context, region, "assistant_id")
    assert getattr(context, "assistant_id", None), (
        "assistant_id is missing — Create Agent scenario must pass before this step."
    )
    context.client = Service(region, auth_profile="agents", use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@when('I delete the AI Search agent for project "{project_id}"')
def delete_ai_search_agent(context, project_id):
    api_version = _AGENTS_API_VERSION
    assistant_id = getattr(context, "assistant_id", None) or getattr(context.config, "assistant_id", None)
    assert assistant_id, "No assistant_id available. Run Create Agent scenario first."
    context.request_url = context.client.base_url + f"/api/projects/{project_id}/assistants/{assistant_id}?{api_version}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/api/projects/{project_id}/assistants/{assistant_id}?{api_version}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the AI Search agent should be deleted successfully")
def verify_ai_search_agent_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


def _delete_ai_search_resource_by_name(context, collection: str, resource_name: str) -> None:
    encoded_name = quote(resource_name, safe="")
    candidate_endpoints = [
        f"/search/azure/{collection}('{encoded_name}')",
        f"/search/azure/{collection}/{encoded_name}",
    ]
    context.request_params = {"api-version": "2025-09-01"}

    for endpoint in candidate_endpoints:
        context.request_url = context.client.base_url + f"{endpoint}?api-version=2025-09-01"
        context.last_response = context.client.delete(
            endpoint,
            headers=context.headers,
            params=context.request_params,
        )
        context.last_status_code = context.last_response.status_code
        if context.last_status_code in (200, 202, 204):
            return


# ============================================================
# SCENARIO 34 — Delete Indexer
# ============================================================

@given('the AI Search indexer is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_indexer(context, region):
    _restore(context, region, "indexer_name")
    assert getattr(context, "indexer_name", None), (
        "indexer_name is missing — Create Indexer scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search indexer by name")
def delete_ai_search_indexer_by_name(context):
    _delete_ai_search_resource_by_name(context, "indexers", context.indexer_name)


@then("the AI Search indexer should be deleted successfully")
def verify_ai_search_indexer_deleted(context):
    assert context.last_status_code in (200, 202, 204), f"Expected HTTP 200, 202, or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 35 — Delete Skillset
# ============================================================

@given('the AI Search skillset is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_skillset(context, region):
    _restore(context, region, "skillset_name")
    assert getattr(context, "skillset_name", None), (
        "skillset_name is missing — Create Skillset scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search skillset by name")
def delete_ai_search_skillset_by_name(context):
    _delete_ai_search_resource_by_name(context, "skillsets", context.skillset_name)


@then("the AI Search skillset should be deleted successfully")
def verify_ai_search_skillset_deleted(context):
    assert context.last_status_code in (200, 202, 204), f"Expected HTTP 200, 202, or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 36 — Delete Index
# ============================================================

@given('the AI Search index is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_index(context, region):
    _restore(context, region, "index_name")
    assert getattr(context, "index_name", None), (
        "index_name is missing — Create Index scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search index by name")
def delete_ai_search_index_by_name(context):
    _delete_ai_search_resource_by_name(context, "indexes", context.index_name)


@then("the AI Search index should be deleted successfully")
def verify_ai_search_index_deleted(context):
    assert context.last_status_code in (200, 202, 204), f"Expected HTTP 200, 202, or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 37 — Delete Data Source
# ============================================================

@given('the AI Search data source is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_data_source(context, region):
    _restore(context, region, "data_source_name")
    assert getattr(context, "data_source_name", None), (
        "data_source_name is missing — Create Data Source scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search data source by name")
def delete_ai_search_data_source_by_name(context):
    _delete_ai_search_resource_by_name(context, "datasources", context.data_source_name)


@then("the AI Search data source should be deleted successfully")
def verify_ai_search_data_source_deleted(context):
    assert context.last_status_code in (200, 202, 204), f"Expected HTTP 200, 202, or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 38 — Delete Catalog Source
# ============================================================

@given('the AI Search catalog source is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_catalog_source(context, region):
    _restore(context, region, "catalog_id", "source_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Create Catalog scenario must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Create Catalog Source scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search catalog source")
def delete_ai_search_catalog_source(context):
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the AI Search catalog source should be deleted successfully")
def verify_ai_search_catalog_source_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 39 — Delete Catalog
# ============================================================

@given('the AI Search catalog is ready to be deleted in region "{region}"')
def setup_ai_search_client_for_delete_catalog(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Create Catalog scenario must pass before this step."
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }


@when("I delete the AI Search catalog")
def delete_ai_search_catalog(context):
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/rag/kpmg/catalog/{context.catalog_id}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the AI Search catalog should be deleted successfully")
def verify_ai_search_catalog_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 40 — Negative: Data Source Invalid Type
# ============================================================

@given('the AI Search data source negative test setup is ready in region "{region}"')
def setup_negative_data_source_test(context, region):
    _restore(
        context,
        region,
        "catalog_id",
        "source_id",
        "subscription_id",
        "storage_resource_group",
        "storage_account_name",
    )
    assert getattr(context, "catalog_id", None), "catalog_id is missing for negative data source scenario."
    assert getattr(context, "source_id", None), "source_id is missing for negative data source scenario."
    assert getattr(context, "subscription_id", None), "subscription_id is missing for negative data source scenario."
    assert getattr(context, "storage_resource_group", None), "storage_resource_group is missing for negative data source scenario."
    assert getattr(context, "storage_account_name", None), "storage_account_name is missing for negative data source scenario."

    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/datasources?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create or update an AI Search data source with invalid type")
def create_or_update_data_source_invalid_type(context):
    invalid_name = f"negative-ds-{context.catalog_id}-{context.source_id}"
    request_body = _build_data_source_request_body(
        context,
        invalid_name,
        context.subscription_id,
        context.storage_resource_group,
        context.storage_account_name,
    )
    request_body["type"] = "invalid-type"

    context.request_url = context.client.base_url + "/search/azure/datasources?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/datasources",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)
    allure.attach(json.dumps(request_body, indent=2), name="negative_data_source_request_body", attachment_type=allure.attachment_type.JSON)


@then("the invalid data source type request should fail with HTTP 400 and expected message")
def verify_negative_data_source_invalid_type(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    error_message = _extract_error_message(context.last_payload)
    expected = "Data source type 'invalid-type' is not supported"
    assert expected in error_message, f"Expected error message containing '{expected}' but got '{error_message}'"


# ============================================================
# SCENARIO 41 — Negative: Index Missing Mandatory Parameters
# ============================================================

@given('the AI Search index negative test setup is ready in region "{region}"')
def setup_negative_index_test(context, region):
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexes?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create an AI Search index with missing mandatory parameters")
def create_index_missing_mandatory_parameters(context):
    request_body = {
        "name": "Negative-TC-for-Index",
    }
    context.request_url = context.client.base_url + "/search/azure/indexes?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/indexes",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)
    allure.attach(json.dumps(request_body, indent=2), name="negative_index_request_body", attachment_type=allure.attachment_type.JSON)


@then("the missing mandatory index parameters request should fail with HTTP 400 and expected message")
def verify_negative_index_missing_parameters(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    error_message = _extract_error_message(context.last_payload)
    expected = "The request is invalid. Details: fields : Index definition must contain one or more valid fields"
    assert expected in error_message, f"Expected error message containing '{expected}' but got '{error_message}'"


# ============================================================
# SCENARIO 42 — Negative: Skillset Missing Parameters
# ============================================================

@given('the AI Search skillset negative test setup is ready in region "{region}"')
def setup_negative_skillset_test(context, region):
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create an AI Search skillset with missing parameters")
def create_skillset_missing_parameters(context):
    request_body = {
        "name": "negative-tc-for-skillset",
        "description": "Validating the negative case for skillset",
    }
    context.request_url = context.client.base_url + "/search/azure/skillsets?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/skillsets",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)
    allure.attach(json.dumps(request_body, indent=2), name="negative_skillset_request_body", attachment_type=allure.attachment_type.JSON)


@then("the missing skillset parameters request should fail with HTTP 400 and expected message")
def verify_negative_skillset_missing_parameters(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    error_message = _extract_error_message(context.last_payload)
    expected = "Skillset requires at least one skill"
    assert expected in error_message, f"Expected error message containing '{expected}' but got '{error_message}'"


# ============================================================
# SCENARIO 43 — Negative: Indexer Missing Parameters
# ============================================================

@given('the AI Search indexer negative test setup is ready in region "{region}"')
def setup_negative_indexer_test(context, region):
    _restore(context, region, "data_source_name", "catalog_id", "source_id")
    assert getattr(context, "data_source_name", None), "data_source_name is missing for negative indexer scenario."
    assert getattr(context, "catalog_id", None), "catalog_id is missing for negative indexer scenario."
    assert getattr(context, "source_id", None), "source_id is missing for negative indexer scenario."

    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + "/search/azure/indexers?api-version=2025-09-01",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create an AI Search indexer with missing parameters")
def create_indexer_missing_parameters(context):
    desired_indexer_name = f"negative-indexer-{context.catalog_id}-{context.source_id}"
    request_body = {
        "name": desired_indexer_name,
        "dataSourceName": context.data_source_name,
        "parameters": {
            "configuration": {
                "dataToExtract": "contentAndMetadata",
                "parsingMode": "default",
            },
        },
        "fieldMappings": [
            {
                "sourceFieldName": "metadata_storage_name",
                "targetFieldName": "metadata_storage_name",
            },
            {
                "sourceFieldName": "metadata_storage_path",
                "targetFieldName": "metadata_storage_path",
            },
        ],
        "outputFieldMappings": [],
    }

    context.request_url = context.client.base_url + "/search/azure/indexers?api-version=2025-09-01"
    context.request_params = {"api-version": "2025-09-01"}
    context.last_response = context.client.post(
        "/search/azure/indexers",
        json=request_body,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.last_payload = get_json_response(context)
    allure.attach(json.dumps(request_body, indent=2), name="negative_indexer_request_body", attachment_type=allure.attachment_type.JSON)


@then("the missing indexer parameters request should fail with HTTP 400 and expected message")
def verify_negative_indexer_missing_parameters(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    error_message = _extract_error_message(context.last_payload)
    expected = "An indexer must have a valid target index name"
    assert expected in error_message, f"Expected error message containing '{expected}' but got '{error_message}'"

