# ============================================================
# RAG Text Chunking Regression - Step Definitions
# ============================================================

from __future__ import annotations

import json

import allure
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()


def _configure_client(context, region: str) -> None:
    """Configure API client and common headers."""
    context.client = Service(region, use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _get_json_response(context, allow_empty: bool = False) -> dict | list:
    """Parse and attach JSON response for diagnostics."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    response_text = (response.text or "").strip()
    if allow_empty and not response_text:
        allure.attach(
            "N/A",
            name="response_body",
            attachment_type=allure.attachment_type.TEXT,
        )
        return {}

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _attach_request_details(context, request_body: dict | None = None) -> None:
    """Attach request URL and request body for consistent Allure diagnostics."""
    allure.attach(
        getattr(context, "request_url", "N/A") or "N/A",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(request_body, indent=2) if request_body is not None else "N/A",
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )


# ============================================================
# SCENARIO 1 - Create Chunks
# ============================================================


@given('the RAG Text Chunking chunking API client is configured with region "{region}"')
def setup_chunking_client(context, region):
    _configure_client(context, region)


@when("I create a list of chunks from the specified input string")
def create_chunk_list(context):
    endpoint = "/text-chunking/microsoft/simple/simple"
    request_body = {
        "extractedFileContent": (
            "RAG (Retrieval-Augmented Generation) is a method used in AI systems to improve how data is fetched and used to generate responses. "
            "Instead of relying only on pre-trained knowledge, the system first retrieves relevant data from a database or documents. "
            "Then it uses that data to generate a more accurate and context-based answer.\n"
            "In simple terms, RAG works like a smart data transfer process where information is first searched (retrieved) and then passed "
            "to an AI model to create the final output. This helps ensure that the response is based on real and updated data rather than "
            "just assumptions. In projects like Workbench, RAG is used to pull data from stored sources and generate meaningful outputs for users.\n"
            "RAG is important because it improves accuracy and reliability in data handling. By fetching the right information before generating "
            "results, it reduces errors and ensures better data flow between systems."
        ),
        "format": "text",
        "algorithm": "line",
        "tokensPerChunk": 5,
        "overlapTokens": 1,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.chunking_payload = _get_json_response(context)


@then("the chunk list should be created successfully")
def verify_chunk_list_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "chunking_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected chunking response payload to be a JSON object or array."


# ============================================================
# SCENARIO 2 - Health Check
# ============================================================


@given('the RAG Text Chunking health check API client is configured with region "{region}"')
def setup_health_check_client(context, region):
    _configure_client(context, region)


@when("I get the RAG Text Chunking health check status")
def get_text_chunking_health(context):
    endpoint = "/text-chunking/microsoft/simple/health-check/self"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.health_payload = _get_json_response(context)


@then("the RAG Text Chunking health check should be returned successfully")
def verify_text_chunking_health(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "health_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected health-check response payload to be a JSON object or array."


# ============================================================
# SCENARIO 3 - Version
# ============================================================


@given('the RAG Text Chunking version API client is configured with region "{region}"')
def setup_version_client(context, region):
    _configure_client(context, region)


@when("I get the RAG Text Chunking API version")
def get_text_chunking_version(context):
    endpoint = "/text-chunking/microsoft/simple/version"
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context)
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
        params=context.request_params,
    )
    context.last_status_code = context.last_response.status_code
    context.version_payload = _get_json_response(context)


@then("the RAG Text Chunking API version should be returned successfully")
def verify_text_chunking_version(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "version_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected version response payload to be a JSON object or array."


# ============================================================
# SCENARIO 4 - Negative Case: Empty extractedFileContent
# ============================================================


@given('the RAG Text Chunking negative case API client is configured with region "{region}"')
def setup_negative_case_client(context, region):
    _configure_client(context, region)


@when("I create a list of chunks with empty extractedFileContent")
def create_chunk_list_with_empty_content(context):
    endpoint = "/text-chunking/microsoft/simple/simple"
    request_body = {
        "extractedFileContent": "",
        "format": "text",
        "algorithm": "line",
        "tokensPerChunk": 5,
        "overlapTokens": 1,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.empty_chunking_payload = _get_json_response(context)


@then("the empty extractedFileContent response should contain the expected validation error")
def verify_empty_extracted_content_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "empty_chunking_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected error response payload to be a JSON object."
    assert payload.get("error") == "Invalid JSON format", (
        f"Expected error 'Invalid JSON format' but got: {payload.get('error')}"
    )


# ============================================================
# SCENARIO 5 - Negative Case: Invalid overlapToken value
# ============================================================


@given('the RAG Text Chunking overlap tokens negative case API client is configured with region "{region}"')
def setup_overlap_negative_case_client(context, region):
    _configure_client(context, region)


@when("I create a list of chunks with overlapTokens greater than tokensPerChunk")
def create_chunk_list_with_invalid_overlap_tokens(context):
    endpoint = "/text-chunking/microsoft/simple/simple"
    request_body = {
        "extractedFileContent": (
            "This is a sample text to be chunked. It will be split into smaller chunks "
            "based on the specified parameters."
        ),
        "format": "text",
        "algorithm": "line",
        "tokensPerChunk": 50,
        "overlapTokens": 100,
    }
    context.request_params = None
    context.request_url = context.client.base_url + endpoint
    _attach_request_details(context, request_body=request_body)
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
        params=context.request_params,
        json=request_body,
    )
    context.last_status_code = context.last_response.status_code
    context.invalid_overlap_payload = _get_json_response(context)


@then("the overlapTokens validation response should contain the expected error message")
def verify_invalid_overlap_tokens_error(context):
    assert context.last_status_code == 400, f"Expected HTTP 400 but got {context.last_status_code}"
    payload = getattr(context, "invalid_overlap_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected validation error response payload to be a JSON object."
    assert payload.get("message") == (
        "Overlap Tokens should be an integer greater than 0 and less than Token per Chunk."
    ), f"Expected overlapTokens validation message but got: {payload.get('message')}"
