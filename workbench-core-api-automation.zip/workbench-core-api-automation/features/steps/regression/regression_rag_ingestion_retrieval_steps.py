# ============================================================
# RAG Ingestion and Retrieval Regression - Step Definitions
# ============================================================

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import allure
from azure.storage.blob import BlobServiceClient, ContainerSasPermissions, generate_container_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()

_rag_ingestion_retrieval_store: dict = {}


def _store(context, **kwargs) -> None:
    """Save key/value pairs into the region-specific slot of the module store."""
    region = context.headers.get("x-kpmg-region-override", "unknown")
    _rag_ingestion_retrieval_store.setdefault(region, {}).update(kwargs)


def _restore(context, region, *keys) -> None:
    """Load stored values for a region back into context."""
    data = _rag_ingestion_retrieval_store.get(region, {})
    for key in keys:
        setattr(context, key, data.get(key))


def generate_reg_source_sas_uri(storage_account_name: str) -> str:
    """Build a SAS URI for reg-source/sourceData using container-level permissions."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }
    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"

    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."

    container_name = "reg-source"
    directory_name = "sourceData"
    sas_token = generate_container_sas(
        account_name=account_name,
        container_name=container_name,
        account_key=account_key,
        permission=ContainerSasPermissions(read=True, add=True, create=True, write=True, delete=True, list=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )
    return f"https://{account_name}.blob.core.windows.net/{container_name}/{directory_name}?{sas_token}"


def _get_json_response(context) -> dict | list:
    """Parse last HTTP response as JSON and attach payload to Allure report."""
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."

    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(
            f"Expected JSON response but got status {response.status_code}: {response.text[:1000]}"
        ) from exc

    allure.attach(
        json.dumps(payload, indent=2),
        name="response_body",
        attachment_type=allure.attachment_type.JSON,
    )
    return payload


def _configure_client(context, region: str) -> None:
    """Configure API client and common headers."""
    context.client = Service(region, use_implicit_auth=getattr(context, "use_implicit_auth", False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _mask_sas_sig(uri: str) -> str:
    """Mask only the SAS signature value while preserving other URI query params for debugging."""
    try:
        parsed = urlsplit(uri)
        params = parse_qsl(parsed.query, keep_blank_values=True)
        masked_params = [(k, "<REDACTED>" if k.lower() == "sig" else v) for k, v in params]
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(masked_params), parsed.fragment))
    except Exception:
        # Fallback: do not expose secrets if parsing fails.
        return uri.split("?", 1)[0] + "?<REDACTED>"


# ============================================================
# SCENARIO 1 - Gets the health check status of the API
# ============================================================


@given('the RAG Ingestion and Retrieval health check API client is configured with region "{region}"')
def setup_rag_ingestion_retrieval_health_client(context, region):
    _configure_client(context, region)
    allure.attach(
        context.client.base_url + "/rag/kpmg/health-check/self",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the RAG Ingestion and Retrieval health check status")
def get_rag_ingestion_retrieval_health_check(context):
    endpoint = "/rag/kpmg/health-check/self"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.health_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval health check should be returned successfully")
def verify_rag_ingestion_retrieval_health_check(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "health_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected health-check response payload to be a JSON object or array."


# ============================================================
# SCENARIO 2 - Gets the version of the API
# ============================================================


@given('the RAG Ingestion and Retrieval version API client is configured with region "{region}"')
def setup_rag_ingestion_retrieval_version_client(context, region):
    _configure_client(context, region)
    allure.attach(
        context.client.base_url + "/rag/kpmg/version",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the RAG Ingestion and Retrieval API version")
def get_rag_ingestion_retrieval_api_version(context):
    endpoint = "/rag/kpmg/version"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.version_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval API version should be returned successfully")
def verify_rag_ingestion_retrieval_api_version(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "version_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected version response payload to be a JSON object or array."


# ============================================================
# SCENARIO 3 - Creates a catalog
# ============================================================


@given('the API client for RAG Ingestion and Retrieval is configured with region "{region}"')
def setup_rag_ingestion_retrieval_client(context, region):
    _configure_client(context, region)
    allure.attach(
        context.client.base_url + "/rag/kpmg/catalog",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when('I create a RAG Ingestion and Retrieval catalog named "{catalog_name}"')
def create_rag_ingestion_retrieval_catalog(context, catalog_name):
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_catalog_name = f"{catalog_name}_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    request_body = {
        "displayName": unique_catalog_name,
        "backendDatabase": "mongodb",
        "configurationJson": {
            "cosmosSearchSettings": {
                "strategy": "diskann",
                "options": {
                    "dimensions": 1536,
                    "similarity": "cos",
                    "maxDegree": 64,
                    "lBuild": 100,
                },
            }
        },
    }

    context.request_url = context.client.base_url + "/rag/kpmg/catalog"
    context.last_response = context.client.post(
        "/rag/kpmg/catalog",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.create_catalog_payload = _get_json_response(context)
    context.catalog_id = context.create_catalog_payload.get("catalogId")

    _store(
        context,
        catalog_id=context.catalog_id,
        catalog_display_name=unique_catalog_name,
    )
    allure.attach(
        json.dumps(request_body, indent=2),
        name="catalog_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the RAG Ingestion and Retrieval catalog should be created successfully and catalog id should be saved")
def verify_rag_ingestion_retrieval_catalog_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "catalog_id", None), "catalog_id was not returned in the response."
    allure.attach(str(context.catalog_id), name="catalog_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 4 - Gets a catalog
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready in region "{region}" with name "{catalog_name}"')
def setup_rag_ingestion_retrieval_with_catalog(context, region, catalog_name):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the RAG Ingestion and Retrieval catalog")
def get_rag_ingestion_retrieval_catalog(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.get_catalog_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval catalog should be fetched successfully")
def verify_rag_ingestion_retrieval_catalog_fetched(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "get_catalog_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected catalog response payload to be a JSON object."
    returned_catalog_id = payload.get("catalogId") or payload.get("id")
    assert returned_catalog_id, "Expected catalog identifier in response payload."


# ============================================================
# SCENARIO 5 - Lists all catalogs
# ============================================================


@given('the RAG Ingestion and Retrieval catalogs listing API client is configured with region "{region}"')
def setup_rag_ingestion_retrieval_catalog_listing_client(context, region):
    _configure_client(context, region)
    allure.attach(
        context.client.base_url + "/rag/kpmg/catalog",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all RAG Ingestion and Retrieval catalogs")
def list_all_rag_ingestion_retrieval_catalogs(context):
    endpoint = "/rag/kpmg/catalog"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.list_catalogs_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval catalogs should be listed successfully")
def verify_rag_ingestion_retrieval_catalogs_listed(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "list_catalogs_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected list catalogs response payload to be a JSON object or array."

    if isinstance(payload, dict):
        catalogs = payload.get("items") or payload.get("value") or payload.get("catalogs")
        assert catalogs is not None, "Expected catalog list field in response payload."
    else:
        assert len(payload) >= 0, "Expected list payload to be an array."


# ============================================================
# SCENARIO 6 - Creates a catalog source
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready for RAG Ingestion and Retrieval in region "{region}"')
def setup_rag_ingestion_retrieval_for_catalog_source_creation(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/blob",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when('I create a RAG Ingestion and Retrieval catalog source named "{catalog_source_name}" with storage account "{storage_account_name}"')
def create_rag_ingestion_retrieval_catalog_source(context, catalog_source_name, storage_account_name):
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_source_name = f"{catalog_source_name}_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    source_uri = generate_reg_source_sas_uri(storage_account_name)

    request_body = {
        "displayName": unique_source_name,
        "uri": source_uri,
    }
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/source/blob"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.post(
        endpoint,
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.create_catalog_source_payload = _get_json_response(context)
    context.source_id = context.create_catalog_source_payload.get("sourceId")
    _store(context, source_id=context.source_id, source_display_name=unique_source_name)

    redacted_request_body = {
        "displayName": unique_source_name,
        "uri": _mask_sas_sig(source_uri),
    }
    allure.attach(
        json.dumps(redacted_request_body, indent=2),
        name="catalog_source_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the RAG Ingestion and Retrieval catalog source should be created successfully and source id should be saved")
def verify_rag_ingestion_retrieval_catalog_source_created(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "source_id", None), "source_id was not returned in the response."
    allure.attach(str(context.source_id), name="source_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 7 - Gets a catalog source
# ============================================================


@given('the RAG Ingestion and Retrieval catalog source is ready in region "{region}"')
def setup_rag_ingestion_retrieval_with_catalog_source(context, region):
    _restore(context, region, "catalog_id", "source_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 6 (Creates a catalog source) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the RAG Ingestion and Retrieval catalog source")
def get_rag_ingestion_retrieval_catalog_source(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.get_catalog_source_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval catalog source should be fetched successfully")
def verify_rag_ingestion_retrieval_catalog_source_fetched(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "get_catalog_source_payload", None) or _get_json_response(context)
    assert isinstance(payload, dict), "Expected catalog source response payload to be a JSON object."
    returned_source_id = payload.get("sourceId") or payload.get("id")
    assert returned_source_id, "Expected source identifier in response payload."


# ============================================================
# SCENARIO 8 - Gets all catalog sources
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready for listing sources in region "{region}"')
def setup_rag_ingestion_retrieval_for_catalog_sources_listing(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source?includeDeleted=false",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all RAG Ingestion and Retrieval catalog sources")
def list_all_rag_ingestion_retrieval_catalog_sources(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/source?includeDeleted=false"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.list_catalog_sources_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval catalog sources should be listed successfully")
def verify_rag_ingestion_retrieval_catalog_sources_listed(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    payload = getattr(context, "list_catalog_sources_payload", None) or _get_json_response(context)
    assert isinstance(payload, (dict, list)), "Expected list catalog sources response payload to be a JSON object or array."

    if isinstance(payload, dict):
        sources = payload.get("items") or payload.get("value") or payload.get("sources")
        assert sources is not None, "Expected catalog source list field in response payload."
    else:
        assert len(payload) >= 0, "Expected list payload to be an array."


# ============================================================
# SCENARIO 9 - Starts a new ingestion job
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready for ingestion in region "{region}"')
def setup_rag_ingestion_retrieval_for_ingestion_start(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I start a new RAG Ingestion and Retrieval ingestion job")
def start_new_rag_ingestion_retrieval_ingestion_job(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/ingest"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.start_ingestion_payload = _get_json_response(context)
    context.ingestion_job_id = context.start_ingestion_payload.get("ingestionJobId")
    _store(context, ingestion_job_id=context.ingestion_job_id)


@then("the RAG Ingestion and Retrieval ingestion job should be accepted and ingestion job id should be saved")
def verify_rag_ingestion_retrieval_ingestion_job_started(context):
    assert context.last_status_code == 202, f"Expected HTTP 202 but got {context.last_status_code}"
    assert getattr(context, "ingestion_job_id", None), "ingestion_job_id was not returned in the response."
    allure.attach(str(context.ingestion_job_id), name="ingestion_job_id", attachment_type=allure.attachment_type.TEXT)


# ============================================================
# SCENARIO 10 - Gets the status of an ingestion job
# ============================================================


@given('the RAG Ingestion and Retrieval ingestion job is ready in region "{region}"')
def setup_rag_ingestion_retrieval_for_ingestion_job_status(context, region):
    _restore(context, region, "catalog_id", "ingestion_job_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "ingestion_job_id", None), (
        "ingestion_job_id is missing — Scenario 9 (Starts a new ingestion job) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I get the status of the RAG Ingestion and Retrieval ingestion job")
def get_status_of_rag_ingestion_retrieval_ingestion_job(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}"
    context.request_url = context.client.base_url + endpoint

    max_attempts = 120
    poll_interval_seconds = 5
    terminal_statuses = ("Ingested", "IngestionFailed")

    for attempt in range(1, max_attempts + 1):
        context.last_response = context.client.get(
            endpoint,
            headers=context.headers,
        )
        context.last_status_code = context.last_response.status_code
        context.ingestion_job_status_payload = _get_json_response(context)

        payload = context.ingestion_job_status_payload
        if isinstance(payload, list):
            payload = payload[0] if payload else {}

        context.ingestion_status = (payload or {}).get("ingestionStatus")

        print(f"Attempt {attempt}/{max_attempts} - ingestion status: {context.ingestion_status}")
        allure.attach(
            f"Attempt {attempt} - Status: {context.ingestion_status}",
            name="ingestion_poll",
            attachment_type=allure.attachment_type.TEXT,
        )

        if context.ingestion_status in terminal_statuses:
            _store(
                context,
                ingestion_status=context.ingestion_status,
                ingestion_status_succeeded=(context.ingestion_status == "Ingested"),
            )
            return

        if attempt < max_attempts:
            time.sleep(poll_interval_seconds)

    raise AssertionError(
        f"Ingestion did not finish after {max_attempts} attempts "
        f"({max_attempts * poll_interval_seconds}s). Last status: {context.ingestion_status}"
    )


@then("the RAG Ingestion and Retrieval ingestion job status should be returned successfully")
def verify_rag_ingestion_retrieval_ingestion_job_status(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "ingestion_status", "") == "Ingested", (
        f"Expected ingestion status to be 'Ingested' in Scenario 10, but got "
        f"'{getattr(context, 'ingestion_status', 'unknown')}'."
    )


# ============================================================
# SCENARIO 11 - Gets all ingestion jobs for a catalog
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready for listing ingestion jobs in region "{region}"')
def setup_rag_ingestion_retrieval_for_ingestion_jobs_listing(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all ingestion jobs for the RAG Ingestion and Retrieval catalog")
def list_all_ingestion_jobs_for_rag_ingestion_retrieval_catalog(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/ingest"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.list_ingestion_jobs_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval ingestion jobs should be listed successfully")
def verify_rag_ingestion_retrieval_ingestion_jobs_listed(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"


# ============================================================
# SCENARIO 12 - Gets all ingestion files in a ingestion job
# ============================================================


@given('the RAG Ingestion and Retrieval ingestion job is ready for listing files in region "{region}"')
def setup_rag_ingestion_retrieval_for_ingestion_job_files(context, region):
    _restore(context, region, "catalog_id", "ingestion_job_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "ingestion_job_id", None), (
        "ingestion_job_id is missing — Scenario 9 (Starts a new ingestion job) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}/files",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all files for the RAG Ingestion and Retrieval ingestion job")
def list_all_files_for_rag_ingestion_retrieval_ingestion_job(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}/files"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.ingestion_job_files_payload = _get_json_response(context)


@then("the RAG Ingestion and Retrieval ingestion job files should be returned successfully")
def verify_rag_ingestion_retrieval_ingestion_job_files(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"


# ============================================================
# SCENARIO 13 - Gets all files in a catalog source
# ============================================================


@given('the RAG Ingestion and Retrieval catalog source is ready for listing files in region "{region}"')
def setup_rag_ingestion_retrieval_catalog_source_for_file_listing(context, region):
    _restore(context, region, "catalog_id", "source_id", "ingestion_status")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 6 (Creates a catalog source) must pass before this step."
    )
    assert getattr(context, "ingestion_status", None) == "Ingested", (
        "Scenario 13 blocked: Scenario 10 ingestion status must be 'Ingested' before listing catalog source files. "
        f"Current status: {getattr(context, 'ingestion_status', 'unknown') or 'unknown'}."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}/files",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I list all files in the RAG Ingestion and Retrieval catalog source")
def list_all_files_in_rag_ingestion_retrieval_catalog_source(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}/files"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.get(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.list_catalog_source_files_payload = _get_json_response(context)

    payload = context.list_catalog_source_files_payload
    if isinstance(payload, dict):
        files = payload.get("items") or payload.get("value") or payload.get("files") or []
    else:
        files = payload or []
    context.catalog_source_files_count = len(files)


@then("the RAG Ingestion and Retrieval catalog source files should be listed successfully")
def verify_rag_ingestion_retrieval_catalog_source_files_listed(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "catalog_source_files_count", 0) > 0, (
        "Expected at least one file in catalog source listing, but got none."
    )


# ============================================================
# SCENARIO 14 - Performs a search against the specified catalog
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready for search in region "{region}"')
def setup_rag_ingestion_retrieval_for_catalog_search(context, region):
    _restore(context, region, "catalog_id", "ingestion_job_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 1 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "ingestion_job_id", None), (
        "ingestion_job_id is missing — Scenario 9 (Starts a new ingestion job) must pass before this step."
    )
    _configure_client(context, region)

    # Keep this lightweight: check ingestion status once before search.
    status_endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}"
    status_response = context.client.get(status_endpoint, headers=context.headers)
    status_payload = status_response.json() if status_response.content else {}
    if isinstance(status_payload, list):
        status_payload = status_payload[0] if status_payload else {}

    raw_status = (
        (status_payload or {}).get("ingestionStatus")
        or (status_payload or {}).get("status")
        or (status_payload or {}).get("jobStatus")
        or (status_payload or {}).get("state")
        or ""
    )
    ingestion_status = str(raw_status).strip().lower()
    failed_statuses = {"failed", "error", "cancelled", "canceled"}
    assert ingestion_status not in failed_statuses, (
        f"Ingestion job {context.ingestion_job_id} is in failure state: {ingestion_status or 'unknown'}"
    )

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/search",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I perform a RAG Ingestion and Retrieval catalog search")
def perform_rag_ingestion_retrieval_catalog_search(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/search"
    request_body = {
        "count": 5,
        "search": "Logging",
    }
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.post(
        endpoint,
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    context.search_payload = _get_json_response(context)
    allure.attach(
        json.dumps(request_body, indent=2),
        name="catalog_search_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the RAG Ingestion and Retrieval search results should be returned successfully")
def verify_rag_ingestion_retrieval_catalog_search(context):
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"


# ============================================================
# SCENARIO 15 - Deletes a catalog source
# ============================================================


@given('the RAG Ingestion and Retrieval catalog source is ready to be deleted in region "{region}"')
def setup_rag_ingestion_retrieval_for_delete_catalog_source(context, region):
    _restore(context, region, "catalog_id", "source_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 3 (Creates a catalog) must pass before this step."
    )
    assert getattr(context, "source_id", None), (
        "source_id is missing — Scenario 6 (Creates a catalog source) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I delete the RAG Ingestion and Retrieval catalog source")
def delete_rag_ingestion_retrieval_catalog_source(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.delete(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the RAG Ingestion and Retrieval catalog source should be deleted successfully")
def verify_rag_ingestion_retrieval_catalog_source_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 16 - Deletes a catalog
# ============================================================


@given('the RAG Ingestion and Retrieval catalog is ready to be deleted in region "{region}"')
def setup_rag_ingestion_retrieval_for_delete_catalog(context, region):
    _restore(context, region, "catalog_id")
    assert getattr(context, "catalog_id", None), (
        "catalog_id is missing — Scenario 3 (Creates a catalog) must pass before this step."
    )
    _configure_client(context, region)

    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I delete the RAG Ingestion and Retrieval catalog")
def delete_rag_ingestion_retrieval_catalog(context):
    endpoint = f"/rag/kpmg/catalog/{context.catalog_id}"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.delete(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the RAG Ingestion and Retrieval catalog should be deleted successfully")
def verify_rag_ingestion_retrieval_catalog_deleted(context):
    assert context.last_status_code in (200, 204), f"Expected HTTP 200 or 204 but got {context.last_status_code}"


# ============================================================
# SCENARIO 17 - Creates a catalog with missing displayName
# ============================================================


@given('the RAG Ingestion and Retrieval negative create catalog API client is configured with region "{region}"')
def setup_rag_ingestion_retrieval_negative_create_catalog_client(context, region):
    _configure_client(context, region)
    allure.attach(
        context.client.base_url + "/rag/kpmg/catalog",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I create a RAG Ingestion and Retrieval catalog with missing displayName")
def create_rag_ingestion_retrieval_catalog_with_missing_display_name(context):
    request_body = {
        "backendDatabase": "mongodb",
        "configurationJson": {
            "cosmosSearchSettings": {
                "strategy": "diskann",
                "options": {
                    "dimensions": 1536,
                    "similarity": "cos",
                    "maxDegree": 64,
                    "lBuild": 100,
                },
            }
        },
    }

    context.request_url = context.client.base_url + "/rag/kpmg/catalog"
    context.last_response = context.client.post(
        "/rag/kpmg/catalog",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code

    allure.attach(
        json.dumps(request_body, indent=2),
        name="catalog_missing_display_name_request_body",
        attachment_type=allure.attachment_type.JSON,
    )


@then("the RAG Ingestion and Retrieval create catalog request should fail with a client error")
def verify_rag_ingestion_retrieval_create_catalog_missing_display_name_failed(context):
    assert 400 <= context.last_status_code < 500, (
        f"Expected HTTP 4xx for missing displayName, but got {context.last_status_code}"
    )


# ============================================================
# SCENARIO 18 - Starts a new ingestion job with invalid catalog id
# ============================================================


@given('the RAG Ingestion and Retrieval negative ingestion API client is configured with region "{region}"')
def setup_rag_ingestion_retrieval_negative_ingestion_client(context, region):
    _configure_client(context, region)
    context.invalid_catalog_id = "3392fb12-377b-4a7f-a4d1-449634742f21"
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.invalid_catalog_id}/ingest",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )


@when("I start a new RAG Ingestion and Retrieval ingestion job with invalid catalog id")
def start_new_rag_ingestion_retrieval_ingestion_job_with_invalid_catalog_id(context):
    endpoint = f"/rag/kpmg/catalog/{context.invalid_catalog_id}/ingest"
    context.request_url = context.client.base_url + endpoint
    context.last_response = context.client.post(
        endpoint,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then("the RAG Ingestion and Retrieval ingestion start request should fail with a client error")
def verify_rag_ingestion_retrieval_ingestion_start_invalid_catalog_failed(context):
    expected_invalid_catalog_id = "3392fb12-377b-4a7f-a4d1-449634742f21"
    actual_invalid_catalog_id = getattr(context, "invalid_catalog_id", "")
    assert actual_invalid_catalog_id == expected_invalid_catalog_id, (
        f"Expected invalid catalog id '{expected_invalid_catalog_id}', but got '{actual_invalid_catalog_id}'."
    )

    assert f"/rag/kpmg/catalog/{expected_invalid_catalog_id}/ingest" in str(context.request_url), (
        f"Expected request URL to include invalid catalog id '{expected_invalid_catalog_id}', got '{context.request_url}'."
    )

    assert 400 <= context.last_status_code < 500, (
        f"Expected HTTP 4xx for invalid catalog id, but got {context.last_status_code}"
    )