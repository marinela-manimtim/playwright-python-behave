"""Behave step definitions package."""

from __future__ import annotations

import sys
from importlib import import_module


_SMOKE_STEP_MODULES = [
	"features.steps.smoke.agents_steps",
	"features.steps.smoke.rag_mongodb_steps",
	"features.steps.smoke.rag_smart_chunking_steps",
	"features.steps.smoke.rag_text_chunking_steps",
	"features.steps.smoke.smoke_ai_translator_steps",
]

_REGRESSION_STEP_MODULES = [
	"features.steps.smoke.agents_steps",
	"features.steps.regression.blob_data_transfer_steps",
	"features.steps.regression.speech_api_steps",
	"features.steps.regression.ai_search_steps",
	"features.steps.regression.assistants_steps",
	"features.steps.regression.regression_rag_enrichment_steps",
	"features.steps.regression.regression_rag_ingestion_retrieval_steps",
	"features.steps.regression.regression_rag_azure_extraction_steps",
	"features.steps.regression.regression_rag_text_chunking_steps",
	"features.steps.regression.regression_rag_smart_chunking_steps",
	"features.steps.regression.regression_rag_extraction_validation_steps",
	"features.steps.regression.reg_ai_translator_steps",
	"features.steps.regression.malware_scanning_steps",
	"features.steps.regression.developer_portal",
	"features.steps.regression.bing_search_steps",
	"features.steps.regression.feature_flags_steps",
]


def _get_tags_expression() -> str:
	for arg in sys.argv:
		if arg.startswith("--tags="):
			return arg.split("=", 1)[1].strip().lower()
	return ""


def _load_modules(module_names: list[str]) -> None:
	for module_name in module_names:
		import_module(module_name)


_tags_expression = _get_tags_expression()

if "@regression" in _tags_expression and "@smoke" not in _tags_expression:
	_load_modules(_REGRESSION_STEP_MODULES)
elif "@smoke" in _tags_expression and "@regression" not in _tags_expression:
	_load_modules(_SMOKE_STEP_MODULES)
elif _tags_expression:
	_load_modules(_REGRESSION_STEP_MODULES)
else:
	_load_modules(_SMOKE_STEP_MODULES)
	_load_modules(_REGRESSION_STEP_MODULES)

__all__: list[str] = []