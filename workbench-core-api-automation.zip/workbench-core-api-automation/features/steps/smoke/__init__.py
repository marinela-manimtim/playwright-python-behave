"""Smoke step definitions package."""
