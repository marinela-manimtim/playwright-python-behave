# ============================================================
# RAG Workflow — Smart Chunking Step Definitions
# ============================================================

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timedelta, timezone

import allure
from azure.storage.blob import BlobServiceClient, ContainerSasPermissions, generate_container_sas
from behave import given, then, when
from dotenv import load_dotenv

from helpers.service import Service

load_dotenv()

# Module-level store keyed by region — persists across all scenarios for the entire test run.
# Storing per-region because Behave runs all rows of Scenario 1 before Scenario 2,
# so each region must keep its own catalog_id, source_id etc. independently.
_rag_store: dict = {}  # { region: { "catalog_id": ..., "source_id": ..., ... } }


def _store(context, **kwargs) -> None:
    """Save key/value pairs into the region-specific slot of _rag_store."""
    region = context.headers.get("x-kpmg-region-override", "unknown")
    _rag_store.setdefault(region, {}).update(kwargs)


def _restore(context, region, *keys) -> None:
    """Load stored values for a region back into context."""
    data = _rag_store.get(region, {})
    for key in keys:
        setattr(context, key, data.get(key))


def attach_json_to_report(name: str, payload: dict) -> None:
    allure.attach(
        json.dumps(payload, indent=2),
        name=name,
        attachment_type=allure.attachment_type.JSON,
    )


def get_json_response(context) -> dict:
    """
    Parse the last HTTP response as JSON, attach it to the Allure report, and return the payload.
    Raises AssertionError if the response is not JSON.
    """
    response = getattr(context, "last_response", None)
    assert response is not None, "No response found. Run a request step first."
    error_message = f"Unexpected response:\nStatus Code: {response.status_code}\nRequest URL: {response.url}\nContent-Type: {response.headers.get('Content-Type', 'N/A')}\nResponse Body (first 1000 chars): {response.text[:1000]}"
    try:
        payload = response.json()
    except ValueError as exc:
        raise AssertionError(error_message) from exc
    allure.attach(json.dumps(payload, indent=2), name="response_body", attachment_type=allure.attachment_type.JSON)
    return payload


def generate_reg_source_sas_uri(storage_account_name: str) -> str:
    """Build a SAS URI for reg-source/sourceData using the connection string for the given storage account."""
    conn_str_env_by_account = {
        "dlsapimregwbapacaueqa": "AZURE_STORAGE_CONNECTION_STRING_AUSTRALIAEAST",
        "dlsapimregwbameruseqa": "AZURE_STORAGE_CONNECTION_STRING_EASTUS",
        "dlsapimregwbemeaweuqa": "AZURE_STORAGE_CONNECTION_STRING_WESTEUROPE",
    }

    conn_str_env = conn_str_env_by_account.get(storage_account_name)
    assert conn_str_env, f"Unsupported storage account: {storage_account_name}"

    connection_string = os.getenv(conn_str_env)
    assert connection_string, f"Missing env var: {conn_str_env}"

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    account_name = blob_service_client.account_name
    account_key = getattr(blob_service_client.credential, "account_key", None)
    assert account_key, f"Connection string in {conn_str_env} must include an AccountKey to generate SAS tokens."

    container_name = "reg-source"
    directory_name = "sourceData"
    sas_token = generate_container_sas(
        account_name=account_name,
        container_name=container_name,
        account_key=account_key,
        permission=ContainerSasPermissions(read=True, add=True, create=True, write=True, delete=True, list=True),
        expiry=datetime.now(timezone.utc) + timedelta(hours=24),
    )

    return f"https://{account_name}.blob.core.windows.net/{container_name}/{directory_name}?{sas_token}"


# ============================================================
# SCENARIO 1 — Create a catalog with smart chunking configuration
# ============================================================

@given('the API client for RAG smart chunking is configured with region "{region}"')
def setup_rag_smart_client(context, region):
    # Set up the API client and fetch available models for smart chunking configuration
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False), skip_region_override_australiaeast=skip_region_override_australiaeast)
    context.headers = {
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)

    _models_by_region = {
        "eastus": {
            "chat": "gpt-4o-mini-2024-07-18-dzs-eus",
            "embedding": "text-embedding-3-small-1-std-eus",
        },
        "australiaeast": {
            "chat": "gpt-4o-mini-2024-07-18-gs-ae",
            "embedding": "text-embedding-3-small-1-std-ae",
        },
        "westeurope": {
            "chat": "gpt-4o-mini-2024-07-18-dzs-we",
            "embedding": "text-embedding-3-small-1-gs-sdc",
        },
    }
    region_models = _models_by_region.get(region)
    assert region_models, f"No model config defined for region '{region}'. Expected one of: {list(_models_by_region)}"
    context.smart_chat_model_id = region_models["chat"]
    context.smart_embedding_model = region_models["embedding"]
    context.headers["x-openai-deployment-id"] = context.smart_chat_model_id
    context.headers["x-openai-deployment-id-embeddings"] = context.smart_embedding_model
    context.headers["x-openai-api-version"] = "2024-06-01"
    allure.attach(
        context.client.base_url + "/rag/kpmg/catalog",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    allure.attach(
        json.dumps(
            {
                "chatModelName": context.smart_chat_model_id,
                "embeddingsModelName": context.smart_embedding_model,
            },
            indent=2,
        ),
        name="smart_chunking_model_config",
        attachment_type=allure.attachment_type.JSON,
    )


@when('I create a catalog named "{catalog_name}" with smart chunking settings')
def create_catalog_with_smart_chunking(context, catalog_name):
    # Append an IST timestamp to ensure the display name is unique across test runs
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_catalog_name = f"{catalog_name}_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    # Send a request to create a catalog with smart chunking configuration
    request_body = {
        "displayName": unique_catalog_name,
        "configurationJson": {
            "chunkingSettings": {
                "strategy": "Smart",
                "options": {
                    "chatModelName": context.smart_chat_model_id,
                    "embeddingsModelName": context.smart_embedding_model,
                },
            }
        },
    }
    context.request_url = context.client.base_url + "/rag/kpmg/catalog"
    context.request_params = None
    context.last_response = context.client.post(
        "/rag/kpmg/catalog",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.catalog_id = payload.get("catalogId")
    _store(context, catalog_id=context.catalog_id)
    allure.attach(json.dumps(request_body, indent=2), name="catalog_request_body", attachment_type=allure.attachment_type.JSON)


# ============================================================
# SCENARIO 2 — Create a catalog source for smart chunking
# ============================================================

@given('a smart chunking catalog is ready for RAG in region "{region}" with name "{catalog_name}"')
def use_existing_smart_catalog(context, region, catalog_name):
    # Restore catalog_id for this region from module-level store
    _restore(context, region, "catalog_id")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/blob",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Catalog is already available. Catalog ID: {context.catalog_id}")


@when('I create a smart chunking catalog source with uri for "{storage_account_name}"')
def create_smart_catalog_source(context, storage_account_name):
    # Append an IST timestamp to ensure the source display name is unique across test runs
    ist = timezone(timedelta(hours=5, minutes=30))
    unique_source_name = f"Smoke_RAG_Smart_Chunking_Source_{datetime.now(ist).strftime('%Y%m%d_%H%M%S')}"
    # Send a request to attach a blob storage source to the catalog
    sas_uri = generate_reg_source_sas_uri(storage_account_name)
    request_body = {
        "displayName": unique_source_name,
        "uri": sas_uri,
    }
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/blob"
    context.request_params = None
    context.last_response = context.client.post(
        f"/rag/kpmg/catalog/{context.catalog_id}/source/blob",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.source_id = payload.get("sourceId")
    _store(context, source_id=context.source_id)
    allure.attach(json.dumps(request_body, indent=2), name="catalog_source_request_body", attachment_type=allure.attachment_type.JSON)

@then('the smart chunking catalog source should be created successfully and source id should be saved')
def verify_smart_catalog_source_created(context):
    # Check the response: HTTP 200 means success, and we must have got back a source ID
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert getattr(context, "source_id", None), "source_id was not returned in the response."

# ============================================================
# SCENARIO 3 — Start ingestion for smart chunking
# ============================================================

@given('a smart chunking catalog with source is ready for RAG in region "{region}" with name "{catalog_name}"')
def use_smart_catalog_with_source(context, region, catalog_name):
    # Restore ids for this region from module-level store
    _restore(context, region, "catalog_id", "source_id")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    assert context.source_id, f"source_id is missing for region '{region}' — run Scenario 2 first."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Reusing already created Catalog ID: {context.catalog_id}")
    allure.attach(str(context.catalog_id), name="reused_catalog_id", attachment_type=allure.attachment_type.TEXT)


@when('I start ingestion for the prepared smart chunking catalog')
def start_smart_ingestion(context):
    # Send a request to kick off the ingestion job
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest"
    context.request_params = None
    context.last_response = context.client.post(
        f"/rag/kpmg/catalog/{context.catalog_id}/ingest",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.ingestion_job_id = payload.get("ingestionJobId")
    _store(context, ingestion_job_id=context.ingestion_job_id)


@then('the smart chunking ingestion job should be accepted and ingestion job id should be saved')
def verify_smart_ingestion_started(context):
    # Check the response: HTTP 202 (Accepted) means the job was queued, and we must have a job ID
    assert context.last_status_code == 202, f"Expected HTTP 202 but got {context.last_status_code}"
    assert getattr(context, "ingestion_job_id", None), "ingestion_job_id was not returned in the response."

# ============================================================
# SCENARIO 4 — Check ingestion status for smart chunking
# ============================================================

@given('a smart chunking ingestion job is running for RAG in region "{region}" with name "{catalog_name}"')
def use_running_smart_ingestion(context, region, catalog_name):
    # Restore catalog_id and ingestion_job_id for this region from module-level store
    _restore(context, region, "catalog_id", "ingestion_job_id")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    assert context.ingestion_job_id, f"ingestion_job_id is missing for region '{region}' — run Scenario 3 first."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Reusing Catalog ID: {context.catalog_id}, Ingestion Job ID: {context.ingestion_job_id}")
    allure.attach(str(context.catalog_id), name="reused_catalog_id", attachment_type=allure.attachment_type.TEXT)
    allure.attach(str(context.ingestion_job_id), name="reused_ingestion_job_id", attachment_type=allure.attachment_type.TEXT)


@when('I check ingestion status for the prepared smart chunking catalog')
def check_smart_ingestion_status(context):
    # Keep checking every 5 seconds until ingestion finishes or we run out of attempts
    max_attempts = 120   # 120 × 5 seconds = 10 minutes max
    poll_interval = 5    # seconds between each check

    for attempt in range(1, max_attempts + 1):
        # Hit the endpoint and save the current status
        context.last_response = context.client.get(
            f"/rag/kpmg/catalog/{context.catalog_id}/ingest/{context.ingestion_job_id}",
            headers=context.headers,
        )
        context.last_status_code = context.last_response.status_code
        payload = get_json_response(context)
        context.ingestion_status = payload.get("ingestionStatus")
        _store(context, ingestion_status=context.ingestion_status)

        print(f"Attempt {attempt}/{max_attempts} — ingestion status: {context.ingestion_status}")
        allure.attach(
            f"Attempt {attempt} — Status: {context.ingestion_status}",
            name="ingestion_poll",
            attachment_type=allure.attachment_type.TEXT,
        )

        # Stop polling as soon as we reach a final status (pass or fail)
        if context.ingestion_status in ("Ingested", "IngestionFailed"):
            return

        # Not done yet — wait before trying again
        time.sleep(poll_interval)

    # If we get here, all attempts were used up without a final status
    raise AssertionError(
        f"Ingestion did not finish after {max_attempts} attempts ({max_attempts * poll_interval}s). "
        f"Last status: {context.ingestion_status}"
    )


@then('smart chunking ingestion status should eventually be "Ingested"')
def verify_smart_ingestion_status(context):
    # Confirm the final status is "Ingested" (not "IngestionFailed")
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert context.ingestion_status == "Ingested", f"Expected status 'Ingested' but got '{context.ingestion_status}'"

# ============================================================
# SCENARIO 5 — Perform a search against the smart chunking catalog
# ============================================================

@given('an ingested smart chunking catalog is ready for RAG in region "{region}" with name "{catalog_name}"')
def use_ingested_smart_catalog(context, region, catalog_name):
    # Restore values for this region from module-level store
    _restore(context, region, "catalog_id", "ingestion_status")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    assert context.ingestion_status == "Ingested", (
        f"Catalog is not ingested for region '{region}'. Status: {context.ingestion_status}"
    )
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/search",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Reusing already created Catalog ID: {context.catalog_id}")
    allure.attach(str(context.catalog_id), name="reused_catalog_id", attachment_type=allure.attachment_type.TEXT)

@when('I search the prepared smart chunking catalog with query "{search_query}"')
def search_smart_catalog(context, search_query):
    # Send a search request to the catalog with the given query
    request_body = {"count": 5, "search": search_query}
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/search"
    context.request_params = None
    allure.attach(json.dumps(request_body, indent=2), name="search_request_body", attachment_type=allure.attachment_type.JSON)
    context.last_response = context.client.post(
        f"/rag/kpmg/catalog/{context.catalog_id}/search",
        json=request_body,
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code
    payload = get_json_response(context)
    context.search_results = payload.get("value", [])


@then('smart chunking search should return results successfully')
def verify_smart_search_results(context):
    # Confirm we got HTTP 200 and at least one result back
    assert context.last_status_code == 200, f"Expected HTTP 200 but got {context.last_status_code}"
    assert len(context.search_results) > 0, "Search returned zero results — expected at least one."


# ============================================================
# SCENARIO 6 — Delete catalog source for smart chunking
# ============================================================

@given('the smart chunking catalog source for "{catalog_name}" in region "{region}" is ready to be deleted')
def use_smart_catalog_for_source_cleanup(context, catalog_name, region):
    # Restore ids for this region from module-level store
    _restore(context, region, "catalog_id", "source_id")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    assert context.source_id, f"source_id is missing for region '{region}' — run Scenario 2 first."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Reusing Catalog ID: {context.catalog_id} and Source ID: {context.source_id}")
    allure.attach(str(context.catalog_id), name="catalog_id", attachment_type=allure.attachment_type.TEXT)
    allure.attach(str(context.source_id), name="source_id", attachment_type=allure.attachment_type.TEXT)


@when('I delete the smart chunking catalog source')
def delete_smart_catalog_source(context):
    # Send a DELETE request to remove the catalog source
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/rag/kpmg/catalog/{context.catalog_id}/source/{context.source_id}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then('the smart chunking catalog source should be deleted successfully')
def verify_smart_catalog_source_deleted(context):
    # Check the response: HTTP 200 or 204 means the source was deleted
    assert context.last_status_code in (200, 204), (
        f"Expected HTTP 200 or 204 but got {context.last_status_code}"
    )
    allure.attach(
        str(context.last_status_code),
        name="delete_source_status_code",
        attachment_type=allure.attachment_type.TEXT,
    )


# ============================================================
# SCENARIO 7 — Delete catalog for smart chunking
# ============================================================

@given('the smart chunking catalog "{catalog_name}" in region "{region}" is ready to be deleted')
def use_smart_catalog_after_source_deletion(context, catalog_name, region):
    # Restore catalog_id for this region from module-level store
    _restore(context, region, "catalog_id")
    assert context.catalog_id, f"catalog_id is missing for region '{region}' — run Scenario 1 first."
    context.client = Service(region, use_implicit_auth=getattr(context, 'use_implicit_auth', False))
    context.headers = {
        "x-kpmg-region-override": region,
        "x-kpmg-charge-code": "1",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)
    allure.attach(
        context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}",
        name="request_url",
        attachment_type=allure.attachment_type.TEXT,
    )
    print(f"Reusing Catalog ID: {context.catalog_id}")
    allure.attach(str(context.catalog_id), name="catalog_id", attachment_type=allure.attachment_type.TEXT)


@when('I delete the smart chunking catalog')
def delete_smart_catalog(context):
    # Send a DELETE request to remove the catalog
    context.request_url = context.client.base_url + f"/rag/kpmg/catalog/{context.catalog_id}"
    context.request_params = None
    context.last_response = context.client.delete(
        f"/rag/kpmg/catalog/{context.catalog_id}",
        headers=context.headers,
    )
    context.last_status_code = context.last_response.status_code


@then('the smart chunking catalog should be deleted successfully')
def verify_smart_catalog_deleted(context):
    # Check the response: HTTP 200 or 204 means the catalog was deleted
    assert context.last_status_code in (200, 204), (
        f"Expected HTTP 200 or 204 but got {context.last_status_code}"
    )
    allure.attach(
        str(context.last_status_code),
        name="delete_catalog_status_code",
        attachment_type=allure.attachment_type.TEXT,
    )
