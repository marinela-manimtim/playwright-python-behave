from __future__ import annotations

import json
import re

import allure
from behave import given, then, when

@given("I prepare a valid request body for generating a completion with structured output for gemini and claude models")
def step_impl(context):

    if context.text:
        request_body = json.loads(context.text)
    else:
        request_body = [{  "model": "gemini-3-flash-preview",  "contents": [    {      "role": "user",      "parts": [        {          "text": "Here is some text:\n\nHi, I'm Alice and I'm 25 years old. I live in New York.\nMy name is Bob, aged 30, from Los Angeles.\nCharlie here, 22, living in Chicago.\nI'm Dana, 27 years old, currently based in San Francisco.\n\nExtract each person's details as a JSON array."        }      ]    }  ]}]

    context.request_body = request_body

    allure.attach(
        json.dumps(request_body, indent=2),
        name="request_body",
        attachment_type=allure.attachment_type.JSON,
    )   