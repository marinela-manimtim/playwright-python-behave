from __future__ import annotations
import inspect
import json
from urllib import response
import allure
from behave import given, then

from helpers.assertions import assert_status_code, extract_json_path
from helpers.service import Service


def _resolve_assistant_id_for_region(context, region: str) -> str | None:
    assistant_id = None
    if region:
        assistant_id = getattr(context.config, "assistant_ids_by_region", {}).get(region)
    if not assistant_id:
        assistant_id = getattr(context, "assistant_id", None)
    if not assistant_id:
        assistant_id = getattr(context.config, "assistant_id", None)
    return str(assistant_id) if assistant_id else None


def _configure_agents_client(context, region: str, require_assistant_id: bool = False) -> None:
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        auth_profile="agents",
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )

    assistant_id = _resolve_assistant_id_for_region(context, region)
    if require_assistant_id:
        assert assistant_id, (
            "No assistant id available for this step. "
            "Run the create-agent scenario first and store the assistant id from the response."
        )

    context.headers = {
        "x-kpmg-charge-code": "",
        "x-kpmg-approval-group": "qa",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    if assistant_id:
        context.headers["x-assistant-id"] = assistant_id

    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


def _configure_assistants_client(context, region: str, require_assistant_id: bool = False) -> None:
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        auth_profile="assistants",
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )

    assistant_id = _resolve_assistant_id_for_region(context, region)
    if require_assistant_id:
        assert assistant_id, (
            "No assistant id available for this step. "
            "Run the create-assistant scenario first and store the assistant id from the response."
        )

    context.headers = {
        "x-kpmg-charge-code": "",
        "x-kpmg-approval-group": "qa",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    if assistant_id:
        context.headers["x-assistant-id"] = assistant_id

    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@given('the API client is configured with region "{region}"')
def step_api_client_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(region, skip_auth=skip_auth, use_implicit_auth=use_implicit_auth, skip_region_override_australiaeast=skip_region_override_australiaeast)
    context.headers = {}
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)

@given('the API client for chat completions is configured with region "{region}"')
def step_api_client_for_chat_completions_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )
    context.headers = {"x-kpmg-charge-code": "1", "x-kpmg-approval-group": "qa", "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420"}
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)


@given('the API client for chat completions is configured with region "{region}" for inference')
def step_api_client_for_chat_completions_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )

    context.headers = {"x-kpmg-charge-code": "1", "x-kpmg-approval-group": "qa", "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420"}
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)

@given('the API client for feature flags is configured with region "{region}"')
def step_api_client_for_feature_flags_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )

    context.headers = {"x-kpmg-charge-code": "1", "x-kpmg-approval-group": "qa", "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420"}
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)    

@given('the API client for gemini and claude models is configured with region "{region}"')
def step_api_client_for_gemini_and_claude_models_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )

    context.headers = {"x-kpmg-charge-code": "1", "x-kpmg-approval-group": "qa", "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420"}
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)       

@given('the API client for agents is configured with region "{region}"')
def step_api_client_for_agents_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    _configure_agents_client(context, region, require_assistant_id=False)

@given('the API client for agents is configured with region "{region}" with {{{{assistantId}}}}')
def step_api_client_for_agents_configured_with_region_and_assistant_id(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    _configure_agents_client(context, region, require_assistant_id=True)

@given('the API client for assistants is configured with region "{region}"')
def step_api_client_for_assistants_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    _configure_assistants_client(context, region, require_assistant_id=False)

@given('the API client for assistants is configured with region "{region}" with {{{{assistantId}}}}')
def step_api_client_for_assistants_configured_with_region_and_assistant_id(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    _configure_assistants_client(context, region, require_assistant_id=True)

@given('the API client for AI Translator is configured with region "{region}"')
def step_api_client_for_ai_translator_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        auth_profile="ai_translator",
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )
    context.headers = {
        "x-kpmg-charge-code": "12345",
        "x-kpmg-approval-group": "qa",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)

@given('the API client for Speech API is configured with region "{region}"')
def step_api_client_for_speech_api_configured_with_region(context, region: str) -> None:
    print("Service module:", Service.__module__)
    print("Service init signature:", inspect.signature(Service.__init__))
    timeout_override = getattr(context, "timeout_override", None)
    skip_auth = getattr(context, "skip_auth", False)
    use_implicit_auth = getattr(context, "use_implicit_auth", False)
    skip_region_override_australiaeast = getattr(context, "skip_region_override_australiaeast", False)
    context.client = Service(
        region,
        timeout=timeout_override,
        skip_auth=skip_auth,
        auth_profile="speech_api",
        use_implicit_auth=use_implicit_auth,
        skip_region_override_australiaeast=skip_region_override_australiaeast,
    )
    context.current_region = region
    context.headers = {
        "x-kpmg-charge-code": "1",
        "x-kpmg-approval-group": "qa",
        "x-kpmg-config-group": "97dbda91-bc6a-4b4f-85ec-57b85bfeb420",
    }
    # Skip region override header for australiaeast region when flag is set
    if not (skip_region_override_australiaeast and region == "australiaeast"):
        context.headers["x-kpmg-region-override"] = region
    allure.attach(region, name="region", attachment_type=allure.attachment_type.TEXT)

@then("the response status code should be {status_code:d}")
def step_validate_status_code(context, status_code: int) -> None:
    assert_status_code(context.last_response, status_code)

@then('the model "{model}" should be listed in the response')
def step_validate_model_name_in_list(context, model: str) -> None:
    deployments = context.last_response.json().get("value", [])
    model_names = [
        d.get("properties", {}).get("model", {}).get("name")
        for d in deployments
    ]
    assert model in model_names, (
        f"Expected model '{model}' to be listed, but found: {model_names}"
    )

@then('the following models should be listed in the response')
def step_validate_all_models_in_list(context) -> None:
    deployments = context.last_response.json().get("value", [])
    actual_models = {
        d.get("properties", {}).get("model", {}).get("name")
        for d in deployments
    }
    expected_models = {row["model"] for row in context.table}
    missing = expected_models - actual_models
    assert not missing, (
        f"The following models were not found in the response: {sorted(missing)}\n"
        f"Available models: {sorted(m for m in actual_models if m)}"
    )


@given('the deployment name for model type "{model_type}" in region "{region}" is resolved')
def step_resolve_deployment_name(context, model_type: str, region: str) -> None:
    """Resolve a model instance name for *model_type* in *region*.

    Uses a feature-level cache (context.model_access_map) so the
    ``GET /deployments/access`` call is made at most once per region per
    feature run. The endpoint returns ``models[].instanceName`` values;
    we resolve by exact match first, then normalized prefix match where
    dots and hyphens are treated equivalently (e.g. ``gpt-5.2`` -> ``gpt-5-2``).
    """
    model_access_map = getattr(context, "model_access_map", {})

    if region not in model_access_map:
        response = context.client.get("/deployments/access", headers=context.headers)
        assert response.status_code == 200, (
            f"Failed to fetch model access list for region '{region}': HTTP {response.status_code}\n"
            f"{response.text[:400]}"
        )

        access_models = response.json().get("models", [])
        model_access_map[region] = [
            model.get("instanceName")
            for model in access_models
            if model.get("instanceName")
        ]
        context.model_access_map = model_access_map

    available_model_names = model_access_map.get(region, [])
    normalized_target = model_type.lower().replace(".", "-").strip()

    deployment_name = next(
        (name for name in available_model_names if name.lower() == model_type.lower()),
        None,
    )
    if not deployment_name:
        deployment_name = next(
            (
                name
                for name in available_model_names
                if name.lower().replace(".", "-").startswith(normalized_target)
            ),
            None,
        )

    assert deployment_name, (
        f"No model instance found for model type '{model_type}' in region '{region}'.\n"
        f"Available instance names: {sorted(available_model_names)}"
    )

    context.resolved_model_name = deployment_name
    allure.attach(
        deployment_name,
        name="resolved_deployment_name",
        attachment_type=allure.attachment_type.TEXT,
    )
