Feature: Models API
	As an API automation engineer
	I want to validate the Models API for Gemini and Claude models
	So that I can ensure the API is working as expected and the models are generating completions correctly


@gemini_claude_deployments @implicit
Scenario Outline: Verify the structured output capability of the models for the given region
        Given the API client for gemini and claude models is configured with region "<region>"
        And I prepare a valid request body for generating a completion with structured output for gemini and claude models
        When I send a POST request to "/genai/genai/geap/gemini/stream-generate-content"
        Then the response status code should be 200

    Examples:
    | region        | 
    | eastus        | 
    | westeurope    |