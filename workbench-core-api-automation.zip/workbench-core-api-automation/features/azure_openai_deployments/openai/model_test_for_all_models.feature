Feature: Models API
	As an API automation engineer
	I want to validate the Models API for Azure OpenAI deployments
	So that I can ensure the API is working as expected and the models are generating completions correctly

   @all_models @implicit @invalid_oauth_token @timeout_override
   Scenario Outline: Verify the response of the model with invalid OAuth2 token
		Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for chat completions with streaming disabled
      When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>" with an invalid OAuth2 token
		Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview         | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |
   

	@446297 @446298 @446299 @499083 @all_models @region_override @implicit @timeout_override
	Scenario Outline: Verify the response of the model with invalid header value
		Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for chat completions with streaming disabled
      When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>" with region-override "<region-override>" and charge-code "<charge-code>"
		Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        | region-override | charge-code |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview | eastus          | 1234567890  |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview | EMPTY           | 1234567890  |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview | EMPTY           | 1234567890  |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview | EMPTY           | 1234567890  |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview | EMPTY           | 1234567890  |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview | westeurope      | 1234567890  |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview | eastus          | 1234567890  |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview | westeurope      | 1234567890  |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview | eastus          | 1234567890  |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview | westeurope      | 1234567890  |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview | eastus          | 1234567890  |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview | westeurope      | 1234567890  |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview | westeurope      | 1234567890  |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview | eastus          | 1234567890  |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview | eastus          | 1234567890  |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | australiaeast           | 1234567890  | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview | westeurope | 1234567890 |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview | westeurope | 1234567890 |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview | eastus     | 123456     |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview | eastus     | 123456     |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview | westeurope | 123456     |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview | westeurope | 123456     |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview | EMPTY      | 123456     |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview | EMPTY      | 123456     |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview | EMPTY      | 123456     |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview | EMPTY      | 123456     |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview | EMPTY      | 123456     |
   

	@446290 @all_models @implicit @timeout_override
	Scenario Outline: Verify the model's capability to generate completions for chat messages with streaming disabled
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
		#add assertion to verify that the response is not streamed
   	Examples:
   | region     | model_name                         | api_version        |
   | eastus     | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | westeurope | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus     | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus     | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus     | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus     | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus     | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus     | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |

	@446289 @all_models @implicit @timeout_override
	Scenario Outline: Verify the model's capability to generate completions for chat messages with streaming enabled
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming enabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
		#add assertion to verify that the response is streamed
   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |

	
   @all_models @499081 @implicit @timeout_override
	Scenario Outline: Verify the response of the model with invalid model name
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 404

   	Examples:
   | region        | model_name                               | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus1          | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus1               | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus1          | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus1          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae1           | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae1                | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae1                | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae1          | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc1          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc1          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc1          | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc1               | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2-invalid      | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2-invalid | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2-invalid | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we-invalid          | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we-invalid     | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we-invalid     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we-invalid        | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we-invalid             | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we-invalid        | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc-invalid       | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc-invalid       | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2-1     | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc-1             | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc-1        | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc-1        | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc-1      | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2-invalid    | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2-invalid  | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae-invalid              | 2024-12-01-preview |
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc-invalid       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc-invalid     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2-invalid     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2-invalid   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2-invalid    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2-invalid    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2-invalid  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2-invalid   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2-invalid | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc-invalid      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc-invalid    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc-invalid     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc-invalid     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc-invalid   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc-invalid    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc-invalid  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae-invalid       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae-invalid     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae-invalid      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae-invalid          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae-invalid     | 2024-12-01-preview |


	@499082 @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model with invalid api version
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 404

   	Examples:
   | region        | model_name                         | api_version                |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview-invalid |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview-invalid |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview-invalid |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview-invalid |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview-invalid |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview-invalid |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview-invalid |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview-invalid |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview-invalid |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview-invalid | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview-invalid |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview-invalid |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview-invalid |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview-invalid |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview-invalid |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview-invalid |


	
   @499076 @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model when the mandatory parameter is missing in the request body
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an invalid request body for chat completions with missing mandatory parameter messages
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 400

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview             | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |



	@499073 @all_models @implicit @timeout_override
	Scenario Outline: Verify the model for its image capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with an image input
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |



	@499075 @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model for invalid image format
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an invalid request body for chat completions with an image input
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 400

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@498606 @no_auth @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model for completion no auth
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 401

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@498599 @all_models @timeout_override @implicit
	Scenario Outline: Verify the response of the model for completion with message reasoning - medium
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with message reasoning - medium
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@498600 @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model for its structured output capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with structured output
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
   	
	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@498601 @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model for its function calling capability with multiple tools
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with function calling
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
		#And the response should contain tool calls for function calling with tools "extract_sales,analyze_duplicates"
   	
	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |



	@498597 @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model for its multilingual capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with multilingual input
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@498613 @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model with exceeded parameter range
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with exceeded parameter range
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 400

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@parallel_tool_calls @all_models @implicit @timeout_override
	Scenario Outline: Verify the response of the model for its parallel function calling capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with parallel function calling
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                       | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2       | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2  | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae         | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae         | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae   | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc        | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2 | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we     | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we        | 2024-12-01-preview |
#   | westeurope | o3-2025-04-16-dzs-we             | 2024-12-01-preview | --> not supported
#   | westeurope | o4-mini-2025-04-16-dzs-we        | 2024-12-01-preview | --> not supported
   | westeurope | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus     | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus     | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus     | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@code_generation @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model for its code generation capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with code generation input
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@reasoning_flags @all_models @timeout_override @implicit
	Scenario Outline: Verify the response of the model for its reasoning flags capability - medium reasoning
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with reasoning flags enabled - medium reasoning
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |

	@json_mode @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model for its json mode capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with json as response format
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
		And the response should be in json format

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@content_filter_trigger @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model for content that triggers content filter
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with content that triggers content filter
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 400
		#And the response should indicate that the content was filtered

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |

	@content_filter_trigger @timeout_override @all_models @implicit
	Scenario Outline: Verify the response of the model for content that triggers content filter with response 200
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with content that triggers content filter
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200
		And the response should contain a sorry message indicating that the content was filtered

   	Examples:
   | region     | model_name           | api_version        |
   | westeurope | o3-2025-04-16-dzs-we | 2024-12-01-preview |


	@multiple_config_group_negative @all_models @implicit @timeout_override @try
	Scenario Outline: Verify chat completions fails for multiple config group negative scenario
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request for multiple config group negative scenario
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@large_max_completion_tokens_boundary @timeout_override @all_models @implicit
	Scenario Outline: Verify model behavior when content filter is triggered with large max_completion_tokens
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request that triggers the content filter with large max_completion_tokens
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |


	@multiple_config_group_positive @all_models @implicit @timeout_override
	Scenario Outline: Verify chat completions with multiple message roles configured successfully
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request for multiple config group positive scenario
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?api-version=<api_version>"
		Then the response status code should be 200

   	Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-5-3-chat-2026-03-03-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-5-2026-04-24-gs-eus2         | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-gs-eus2    | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-4-2026-03-05-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-gs-ae           | 2024-12-01-preview |
   | australiaeast | gpt-4-1-mini-2025-04-14-std-ae     | 2024-12-01-preview |
   | westeurope    | gpt-5-3-chat-2026-03-03-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-nano-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-4-mini-2026-03-17-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-gs-sdc          | 2024-12-01-preview |
   | eastus        | gpt-5-2-2025-12-11-dzs-eus2        | 2024-12-01-preview |
   | eastus        | gpt-5-4-mini-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-4-nano-2026-03-17-dzs-eus2   | 2024-12-01-preview |
   | westeurope    | gpt-5-2025-08-07-dzs-we            | 2024-12-01-preview |
   | westeurope    | gpt-5-mini-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-nano-2025-08-07-dzs-we       | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-we          | 2024-12-01-preview |
   | westeurope    | o3-2025-04-16-dzs-we               | 2024-12-01-preview |
   | westeurope    | o4-mini-2025-04-16-dzs-we          | 2024-12-01-preview |
   | westeurope    | gpt-5-4-2026-03-05-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-5-5-2026-04-24-dzs-sdc         | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-05-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-4-1-2025-04-14-dzs-sdc         | 2024-12-01-preview |
   | westeurope    | gpt-4-1-mini-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-4-1-nano-2025-04-14-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-05-gs-sdc  | 2024-12-01-preview |
   | eastus        | gpt-5-chat-2025-10-03-gs-eus2      | 2024-12-01-preview |
   | eastus        | gpt-5-2-chat-2026-02-10-gs-eus2    | 2024-12-01-preview |
   #| australiaeast | gpt-5-chat-2025-10-03-gs-ae        | 2024-12-01-preview | --> Retired model
   | westeurope    | gpt-5-chat-2025-10-03-gs-sdc       | 2024-12-01-preview |
   | westeurope    | gpt-5-2-chat-2026-02-10-gs-sdc     | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-gs-eus2     | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-gs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-gs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-sol-2026-07-09-dzs-eus2    | 2024-12-01-preview |
   | eastus        | gpt-5-6-terra-2026-07-09-dzs-eus2  | 2024-12-01-preview |
   | eastus        | gpt-5-6-luna-2026-07-09-dzs-eus2   | 2024-12-01-preview |
   | eastus        | gpt-chat-latest-2026-05-28-gs-eus2 | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-gs-sdc      | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-gs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-gs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-sol-2026-07-09-dzs-sdc     | 2024-12-01-preview |
   | westeurope    | gpt-5-6-terra-2026-07-09-dzs-sdc   | 2024-12-01-preview |
   | westeurope    | gpt-5-6-luna-2026-07-09-dzs-sdc    | 2024-12-01-preview |
   | westeurope    | gpt-chat-latest-2026-05-28-gs-sdc  | 2024-12-01-preview |
   | australiaeast | gpt-5-6-sol-2026-07-09-gs-ae       | 2024-12-01-preview |
   | australiaeast | gpt-5-6-terra-2026-07-09-gs-ae     | 2024-12-01-preview |
   | australiaeast | gpt-5-6-luna-2026-07-09-gs-ae      | 2024-12-01-preview |
   | australiaeast | gpt-5-2-2025-12-11-dzs-ae          | 2024-12-01-preview |
   | australiaeast | gpt-5-4-mini-2026-03-17-dzs-ae     | 2024-12-01-preview |

