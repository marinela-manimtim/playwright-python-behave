Feature: Azure OpenAI Deployments API
	As an API automation engineer
	I want to retrieve information about Azure OpenAI deployments
	So I can use this information for further testing and validation for the Chat and Completions API

	@446286 @499069 @model_access @implicit
	Scenario Outline: Successfully retrieve Azure OpenAI models with access for each region
		Given the API client is configured with region "<region>"
		When I send a GET request to "/deployments/access"
		Then the response status code should be 200

		Examples:
   | region        |
   | eastus        |
   | australiaeast |
   | westeurope    |

	@446286 @499069 @deployments
	Scenario Outline: Successfully retrieve Azure OpenAI deployments for each region
		Given the API client is configured with region "<region>"
		When I send a GET request to "/deployments/openai"
		Then the response status code should be 200

		Examples:
   | region        |
   | eastus        |
   | australiaeast |
   | westeurope    |
