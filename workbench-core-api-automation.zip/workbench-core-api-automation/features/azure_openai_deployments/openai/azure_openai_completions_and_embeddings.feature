Feature: Models API
	As an API automation engineer
	I want to validate the Models API for Azure OpenAI deployments
	So that I can ensure the API is working as expected and the models are generating completions correctly
  
	@446297 @446298 @446299 @499083 @old_model
	Scenario Outline: Verify the response of the model with invalid header value
		Given the API client for chat completions is configured with region "<region>"
		#And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>" with region-override "<region-override>" and charge-code "<charge-code>"
		Then the response status code should be 400

		Examples:
   | region        | model_name | api_version                    | region-override | charge-code |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview | EMPTY           | 1234567890  |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview | eastus          | EMPTY       |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview | EMPTY           | 1234567890  |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview | australiaeast   | EMPTY       |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview | EMPTY           | 1234567890  |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview | westeurope      | EMPTY       |

	@446290 @old_model
	Scenario Outline: Verify the model's capability to generate completions for chat messages with streaming disabled
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200
		#add assertion to verify that the response is not streamed
		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@446289 @old_model
	Scenario Outline: Verify the model's capability to generate completions for chat messages with streaming enabled
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming enabled
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200
		#add assertion to verify that the response is streamed
		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-4.1    | api-version=2024-12-01-preview |
   | westeurope    | gpt-4.1    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@499081 @old_model
	Scenario Outline: Verify the response of the model with invalid model name
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 404

		Examples:
   | region        | model_name                   | api_version                    |
   | eastus        | gpt-5-2-2025-12-11-gs-eus123 | api-version=2024-12-01-preview |
   | australiaeast | gpt-5-2025-08-07-gs-ae123    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5-2-2025-12-11-gs-eus123 | api-version=2024-12-01-preview |

	@499082 @old_model
	Scenario Outline: Verify the response of the model with invalid api version
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 404

		Examples:
   | region        | model_name | api_version             |
   | eastus        | gpt-5.2    | api-version=2024-10-211 |
   | westeurope    | gpt-5.2    | api-version=2024-10-211 |
   | australiaeast | gpt-5      | api-version=2024-10-211 |

	@499076 @old_model
	Scenario Outline: Verify the response of the model when the mandatory parameter is missing in the request body
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an invalid request body for chat completions with missing mandatory parameter messages
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 400

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@499073 @old_model
	Scenario Outline: Verify the model for its image capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with an image input
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@499075 @old_model
	Scenario Outline: Verify the response of the model for invalid image format
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an invalid request body for chat completions with an image input
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 400

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498063 @timeout_override @sendRequestSubseq @skip
	Scenario Outline: Verify the response of the model for message token limit
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an valid request body for chat completions with message tokens exceeding the limit
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 429

		Examples:
   | region        | model_name                | api_version                    |
   | eastus        | gpt-4o-2024-11-20-dzs-eus | api-version=2024-12-01-preview |
   | westeurope    | gpt-4o-2024-08-06-dzs-sdc | api-version=2024-12-01-preview |
   | australiaeast | gpt-4o-2024-11-20-std-ae  | api-version=2024-12-01-preview |

	@498064 @timeout_override @skip
	Scenario Outline: Verify the response of the model for message rate limit
		Given the API client for chat completions is configured with region "<region>"
		And I prepare an valid request body for chat completions with message rate exceeding the limit
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 429

		Examples:
   | region        | model_name                | api_version                    |
   | eastus        | gpt-4o-2024-11-20-dzs-eus | api-version=2024-12-01-preview |
   | westeurope    | gpt-4o-2024-08-06-dzs-sdc | api-version=2024-12-01-preview |
   | australiaeast | gpt-4o-2024-11-20-std-ae  | api-version=2024-12-01-preview |

	@498606 @no_auth @old_model
	Scenario Outline: Verify the response of the model for completion no auth
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with streaming disabled
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 401

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498599 @timeout_override @old_model
	Scenario Outline: Verify the response of the model for completion with message reasoning
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with message reasoning
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498600 @old_model
	Scenario Outline: Verify the response of the model for its structured output capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with structured output
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498601 @old_model
	Scenario Outline: Verify the response of the model for its function calling capability with multiple tools
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with function calling
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200
		#And the response should contain tool calls for function calling with tools "extract_sales,analyze_duplicates"

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498602 @skip
	Scenario Outline: Verify the response of the model if id is being saved in proxy logs
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions for proxy log verification
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200
		And the response should contain an id
		And the id should be saved in proxy logs

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |
 
	@498597 @timeout_override @old_model
	Scenario Outline: Verify the response of the model for its multilingual capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with multilingual input
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@498613 @timeout_override @old_model
	Scenario Outline: Verify the response of the model with exceeded parameter range
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with exceeded parameter range
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 400

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@parallel_tool_calls @old_model
	Scenario Outline: Verify the response of the model for its parallel function calling capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with parallel function calling
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@code_generation @timeout_override @old_model
	Scenario Outline: Verify the response of the model for its code generation capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with code generation input
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@reasoning_flags @timeout_override @old_model
	Scenario Outline: Verify the response of the model for its reasoning flags capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with reasoning flags enabled
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@json_mode @timeout_override @old_model
	Scenario Outline: Verify the response of the model for its json mode capability
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with json as response format
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azureopenai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200
		And the response should be in json format

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@content_filter_trigger @timeout_override @old_model
	Scenario Outline: Verify the response of the model for content that triggers content filter
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid request body for chat completions with content that triggers content filter
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 400
		#And the response should indicate that the content was filtered

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |
		
	@multiple_config_group_negative @old_model
	Scenario Outline: Verify chat completions fails for multiple config group negative scenario
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request for multiple config group negative scenario
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@large_max_completion_tokens_boundary @timeout_override @old_model
	Scenario Outline: Verify model behavior when content filter is triggered with large max_completion_tokens
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request that triggers the content filter with large max_completion_tokens
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |

	@multiple_config_group_positive @old_model
	Scenario Outline: Verify chat completions with multiple message roles configured successfully
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid chat completions request for multiple config group positive scenario
		And the deployment name for model type "<model_name>" in region "<region>" is resolved
		When I send a POST request to "/genai/azure/openai/deployments/<model_name>/chat/completions?<api_version>"
		Then the response status code should be 200

		Examples:
   | region        | model_name | api_version                    |
   | eastus        | gpt-5.2    | api-version=2024-12-01-preview |
   | westeurope    | gpt-5.2    | api-version=2024-12-01-preview |
   | australiaeast | gpt-5      | api-version=2024-12-01-preview |
