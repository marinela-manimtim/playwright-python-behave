Feature: Inference API
	As an API automation engineer
	I want to validate the Inference API for Azure OpenAI deployments
	So that I can ensure the API is working as expected and the models are generating completions correctly

   @implicit @timeout_override @inference @regression
   Scenario Outline: Verify retrieval of API routes with descriptions
	  Given the API client for chat completions is configured with region "<region>" for inference
      When I send a GET request to "/genai/azure/inference/listRoutes?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-04-01-preview |

   @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the completion with open ai model
	  Given the API client for chat completions is configured with region "<region>"
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-04-01-preview |

  @implicit @timeout_override @inference @regression @skip
  #only works with llama models
   Scenario Outline: Verify the retrieval of model metadata
	  Given the API client for chat completions is configured with region "<region>"
      When I send a POST request to "/genai/azure/inference/info?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-04-01-preview |

  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the completion with open ai model_invalid subscripton key
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for completions for inference
      And I set an invalid subscription key in the request header
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |


  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the completion with open ai model_invalid request body parameter
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare an invalid request body for completions for inference
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

  @implicit @timeout_override @inference @regression 
   Scenario Outline: Verify the chat completion with open ai model
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for chat completions for inference
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the completion with open ai model_invalid subscripton key
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for chat completions for inference
      And I set an invalid subscription key in the request header
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |


  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the completion with open ai model_invalid request body parameter
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare an invalid request body for chat completions for inference
      When I send a POST request to "/genai/azure/inference/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 400

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

@implicit @timeout_override @inference @regression
   Scenario Outline: Verify the embeddings with open ai model
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for embeddings for inference
      When I send a POST request to "/genai/azure/inference/embeddings?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

  @implicit @timeout_override @inference @regression
   Scenario Outline: Verify the embeddings with open ai model_invalid subscripton key
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for embeddings for inference
      And I set an invalid subscription key in the request header
      When I send a POST request to "/genai/azure/inference/embeddings?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |


  @implicit @timeout_override @inference @regression
   Scenario Outline: Verify the embeddings with open ai model_invalid request body parameter
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare an invalid request body for embeddings for inference
      When I send a POST request to "/genai/azure/inference/embeddings?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 400

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

@implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the image embeddings with open ai model
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for image embeddings for inference
      When I send a POST request to "/genai/azure/inference/chat/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 200

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the image embeddings with open ai model_invalid subscripton key
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare a valid request body for image embeddings for inference
      And I set an invalid subscription key in the request header
      When I send a POST request to "/genai/azure/inference/embeddings?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 401

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |

  @implicit @timeout_override @inference @regression @skip
   Scenario Outline: Verify the image embeddings with open ai model_invalid request body parameter
	  Given the API client for chat completions is configured with region "<region>"
      And I prepare an invalid request body for image embeddings for inference
      When I send a POST request to "/genai/azure/inference/chat/completions?api-version=<api_version>" with azureml-model-deployment header set to "<model_name>"
	  Then the response status code should be 400

		Examples:
   | region        | model_name                         | api_version        |
   | eastus        | gpt-4o-mini-2024-07-18-dzs-wus     | 2024-05-01-preview |