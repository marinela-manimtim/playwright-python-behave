Feature: Regression test for RAG Smart Chunking workflow
  As an API automation engineer
  I want to perform regression tests for RAG Smart Chunking
  So that I can ensure chunking, health, and version APIs work as expected

  @rag_smart_chunking_regression @regression @implicit
  Scenario Outline: Create a list of chunks from a specified input string
    Given the RAG Smart Chunking chunking API client is configured with region "<region>"
    When I create a smart chunking list of chunks from the specified input string
    Then the smart chunk list should be created successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_smart_chunking_regression @regression @implicit
  Scenario Outline: Gets the health check status of the API
    Given the RAG Smart Chunking health check API client is configured with region "<region>"
    When I get the RAG Smart Chunking health check status
    Then the RAG Smart Chunking health check should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_smart_chunking_regression @regression @implicit
  Scenario Outline: Gets the version of the API
    Given the RAG Smart Chunking version API client is configured with region "<region>"
    When I get the RAG Smart Chunking API version
    Then the RAG Smart Chunking API version should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_smart_chunking_regression @regression @implicit
  Scenario Outline: Create smart chunks with invalid request body returns validation error
    Given the RAG Smart Chunking negative case API client is configured with region "<region>"
    When I create a smart chunking request with invalid body values
    Then the smart chunking invalid body response should contain the expected validation error

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_smart_chunking_regression @regression @implicit
  Scenario Outline: Create smart chunks with Invalid header values returns validation error
    Given the RAG Smart Chunking invalid OpenAI headers API client is configured with region "<region>"
    When I create a smart chunking request with invalid OpenAI headers
    Then the smart chunking invalid OpenAI headers response should contain validation details

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |
