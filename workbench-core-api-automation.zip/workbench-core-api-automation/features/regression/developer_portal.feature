Feature: Regression test for developer portal
	As an API automation engineer
	I want to perform regression tests for developer portal functionality
    So that I can ensure the basic functionality of the developer portal is working as expected

@developer_portal @verify_login_network_interruption @regression
Scenario Outline: Verify login is blocked during a network interruption
    Given I am on the developer portal login page for "<qa_environment>"
    When I attempt to sign in during a network interruption for "<qa_environment>"
    Then I should see that login is blocked due to network interruption

    Examples:
      | qa_environment |
      #| eastus         |
      | australiaeast  |
      #| westeurope     |
      
@developer_portal_login @developer_portal @regression
Scenario Outline: Verify the developer portal login functionality
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    Then I should be redirected to the developer portal dashboard

    Examples:
      | qa_environment        |
     # | eastus             |
      | australiaeast      |
    #| westeurope         |

@developer_portal_homepage @developer_portal @regression
Scenario Outline: Verify the developer portal homepage
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    Then I should be redirected to the developer portal dashboard
    And I should verify developer portal navigation endpoints

    Examples:
      | qa_environment     |
      #| eastus             |
      | australiaeast      |
      #| westeurope         |    

@developer_portal @verify_api_search @regression
Scenario Outline: Verify the API search functionality in the developer portal
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    And I am on the APIs page
    When I search for an API "<api_name>" in the search bar
    Then I should see the API "<api_name>" in the search results
    And I should verify the different API endpoints are accessible

    Examples:
      | qa_environment     | api_name          |
      #| eastus             | Agents    |
      | australiaeast      | Agents    |
      #| westeurope         | Agents    |

@developer_portal @verify_api_filter @regression
Scenario Outline: Verify the API filter functionality in the developer portal
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    And I am on the APIs page
    When I select a filter tag
    Then I should see the filtered APIs in the search results

    Examples:
      | qa_environment     | api_name          |
      #| eastus             | Agents    |
      | australiaeast      | Agents    |
      #| westeurope         | Agents    |    

@developer_portal @verify_api_try_it_out @regression
Scenario Outline: Verify the API try-it-out functionality in the developer portal
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    And I am on the APIs page
    When I search for an API "<api_name>" in the search bar
    And I click on the API link for "<api_name>"
    Then I should be redirected to the API documentation page for "<api_name>"
    And I click on the "Try it" button for the API "<api_name>"
    Then I should be able to execute the API request and receive a response

    Examples:
      | qa_environment     | api_name          |
      #| eastus             |Azure AI Translator - Text API|
      | australiaeast      |Azure AI Translator - Text API|
      #| westeurope         |Azure AI Translator - Text API|  

@developer_portal @verify_api_user_profile @regression
Scenario Outline: Verify the API user profile page in the developer portal
    Given I am on the developer portal login page for "<qa_environment>"
    When I enter valid credentials for "<qa_environment>"
    And I am on the User Profile page
    Then I should be redirected to the User Profile page
    And I should be able to verify my account information

    Examples:
      | qa_environment     | api_name          |
      #| eastus             | Azure AI Translator - Text API    |
      | australiaeast      | Azure AI Translator - Text API    |
      #| westeurope         | Azure AI Translator - Text API    |      