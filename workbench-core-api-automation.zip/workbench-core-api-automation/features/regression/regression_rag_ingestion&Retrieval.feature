Feature: Regression test for RAG Ingestion and Retrieval workflow
  As an API automation engineer
  I want to perform regression tests for RAG Ingestion and Retrieval
  So that I can ensure health, version, and catalog APIs work as expected

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets the health check status of the API
    Given the RAG Ingestion and Retrieval health check API client is configured with region "<region>"
    When I get the RAG Ingestion and Retrieval health check status
    Then the RAG Ingestion and Retrieval health check should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets the version of the API
    Given the RAG Ingestion and Retrieval version API client is configured with region "<region>"
    When I get the RAG Ingestion and Retrieval API version
    Then the RAG Ingestion and Retrieval API version should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Creates a catalog
    Given the API client for RAG Ingestion and Retrieval is configured with region "<region>"
    When I create a RAG Ingestion and Retrieval catalog named "<catalog_name>"
    Then the RAG Ingestion and Retrieval catalog should be created successfully and catalog id should be saved

    Examples:
      | region        | catalog_name     |
      | eastus        | Regression_RAG_I&R_Catalog_Amer  |
      | australiaeast | Regression_RAG_I&R_Catalog_Aspac |
      | westeurope    | Regression_RAG_I&R_Catalog_Emea  |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets a catalog
    Given the RAG Ingestion and Retrieval catalog is ready in region "<region>" with name "<catalog_name>"
    When I get the RAG Ingestion and Retrieval catalog
    Then the RAG Ingestion and Retrieval catalog should be fetched successfully

    Examples:
      | region        | catalog_name     |
      | eastus        | Regression_RAG_I&R_Catalog_Amer  |
      | australiaeast | Regression_RAG_I&R_Catalog_Aspac |
      | westeurope    | Regression_RAG_I&R_Catalog_Emea  |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Lists all catalogs
    Given the RAG Ingestion and Retrieval catalogs listing API client is configured with region "<region>"
    When I list all RAG Ingestion and Retrieval catalogs
    Then the RAG Ingestion and Retrieval catalogs should be listed successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Creates a catalog source
    Given the RAG Ingestion and Retrieval catalog is ready for RAG Ingestion and Retrieval in region "<region>"
    When I create a RAG Ingestion and Retrieval catalog source named "<catalog_source_name>" with storage account "<storage_account_name>"
    Then the RAG Ingestion and Retrieval catalog source should be created successfully and source id should be saved

    Examples:
      | region        | catalog_source_name            | storage_account_name   |
      | eastus        | Regression_RAG_I&R_CS_Amer     | dlsapimregwbameruseqa  |
      | australiaeast | Regression_RAG_I&R_CS_Aspac    | dlsapimregwbapacaueqa  |
      | westeurope    | Regression_RAG_I&R_CS_Emea     | dlsapimregwbemeaweuqa  |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets a catalog source
    Given the RAG Ingestion and Retrieval catalog source is ready in region "<region>"
    When I get the RAG Ingestion and Retrieval catalog source
    Then the RAG Ingestion and Retrieval catalog source should be fetched successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets all catalog sources
    Given the RAG Ingestion and Retrieval catalog is ready for listing sources in region "<region>"
    When I list all RAG Ingestion and Retrieval catalog sources
    Then the RAG Ingestion and Retrieval catalog sources should be listed successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Starts a new ingestion job
    Given the RAG Ingestion and Retrieval catalog is ready for ingestion in region "<region>"
    When I start a new RAG Ingestion and Retrieval ingestion job
    Then the RAG Ingestion and Retrieval ingestion job should be accepted and ingestion job id should be saved

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets the status of an ingestion job
    Given the RAG Ingestion and Retrieval ingestion job is ready in region "<region>"
    When I get the status of the RAG Ingestion and Retrieval ingestion job
    Then the RAG Ingestion and Retrieval ingestion job status should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets all ingestion jobs for a catalog
    Given the RAG Ingestion and Retrieval catalog is ready for listing ingestion jobs in region "<region>"
    When I list all ingestion jobs for the RAG Ingestion and Retrieval catalog
    Then the RAG Ingestion and Retrieval ingestion jobs should be listed successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets all ingestion files in a ingestion job
    Given the RAG Ingestion and Retrieval ingestion job is ready for listing files in region "<region>"
    When I list all files for the RAG Ingestion and Retrieval ingestion job
    Then the RAG Ingestion and Retrieval ingestion job files should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Gets all files in a catalog source
    Given the RAG Ingestion and Retrieval catalog source is ready for listing files in region "<region>"
    When I list all files in the RAG Ingestion and Retrieval catalog source
    Then the RAG Ingestion and Retrieval catalog source files should be listed successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Performs a search against the specified catalog
    Given the RAG Ingestion and Retrieval catalog is ready for search in region "<region>"
    When I perform a RAG Ingestion and Retrieval catalog search
    Then the RAG Ingestion and Retrieval search results should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Deletes a catalog source
    Given the RAG Ingestion and Retrieval catalog source is ready to be deleted in region "<region>"
    When I delete the RAG Ingestion and Retrieval catalog source
    Then the RAG Ingestion and Retrieval catalog source should be deleted successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Deletes a catalog
    Given the RAG Ingestion and Retrieval catalog is ready to be deleted in region "<region>"
    When I delete the RAG Ingestion and Retrieval catalog
    Then the RAG Ingestion and Retrieval catalog should be deleted successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Creates a catalog with missing displayName
    Given the RAG Ingestion and Retrieval negative create catalog API client is configured with region "<region>"
    When I create a RAG Ingestion and Retrieval catalog with missing displayName
    Then the RAG Ingestion and Retrieval create catalog request should fail with a client error

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_ingestion_retrieval_regression @regression @implicit
  Scenario Outline: Starts a new ingestion job with invalid catalog id
    Given the RAG Ingestion and Retrieval negative ingestion API client is configured with region "<region>"
    When I start a new RAG Ingestion and Retrieval ingestion job with invalid catalog id
    Then the RAG Ingestion and Retrieval ingestion start request should fail with a client error

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |