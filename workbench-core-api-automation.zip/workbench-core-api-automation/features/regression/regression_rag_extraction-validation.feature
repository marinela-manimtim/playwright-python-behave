Feature: Regression test for RAG Extraction Validation workflow
  As an API automation engineer
  I want to perform regression tests for RAG Extraction Validation
  So that I can ensure validation reports can be created and retrieved successfully

  @extraction_validation_regression @regression @implicit
  Scenario Outline: Create a validation report
    Given the Extraction Validation API client is configured with region "<region>"
    When I create a validation report with storage account "<storage_account_name>"
    Then the validation report should be created successfully and report id should be saved

    Examples:
      | region        | storage_account_name       |
      | eastus        | dlsapimregwbameruseqa      |
      | australiaeast | dlsapimregwbapacaueqa      |
      | westeurope    | dlsapimregwbemeaweuqa      |

  @extraction_validation_regression @regression @implicit
  Scenario Outline: Get a validation report
    Given the Extraction Validation API client is configured with region "<region>" and report id from previous scenario
    When I get the validation report by id
    Then the validation report should be retrieved successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @extraction_validation_regression @regression @implicit
  Scenario Outline: Create Validation Report with missing urlSource
    Given the Extraction Validation blank urlSource client is configured with region "<region>"
    When I create a validation report with blank urlSource
    Then the validation report blank urlSource request should be created successfully and report id should be saved
    When I get the validation report by id
    Then the validation report for blank urlSource should fail with status 404 and message "No report found for given validation id. Please check the validation id and try again."

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |
