Feature: Regression test for feature flags
	As an API automation engineer
	I want to perform regression tests for feature flags
    So that I can ensure the basic functionality of feature flags is working as expected

@feature_flags @regression @implicit
Scenario Outline: Verify the creation of feature flags for the given region
        Given the API client for feature flags is configured with region "<region>"
        And I prepare a valid request body for creating a feature flag
        When I send a POST request to "/configuration/feature-flags/admin/api/add-approval-group"
        Then the response status code should be 200
        #And the response should contain the feature flags for the given region

    	Examples:
    | region        | 
    | eastus        | 
    | australiaeast | 
    | westeurope    |

