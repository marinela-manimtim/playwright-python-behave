Feature: Regression test for assistants
	As an API automation engineer
	I want to perform regression tests for assistants functionality
    So that I can ensure the basic functionality of assistants is working as expected

@create_assistant @assistants @implicit @regression @try_agents
Scenario Outline: Create a new assistant and verify its creation
		Given the API client for assistants is configured with region "<region>"
		And I prepare a valid request body for creating an assistant with model "<model>"
        When I send a POST request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
		Then the response status code should be 200
        And I store the assistant id from the response

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@regression @implicit @assistants
Scenario Outline: Get assistant details and verify its information 
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/assistants/{{assistantId}}?api-version=<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview |

@regression @list_assistants @implicit @assistants 
Scenario Outline: List all assistants in a project
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview |

@regression @implicit @assistants
Scenario Outline: Update an assistant and verify the update
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for updating an assistant with model "<model>"
        When I send a PUT request to "/api/projects/<projectId>/assistants/{{assistantId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@regression @create_thread @assistants @implicit 
Scenario Outline: Create a conversational thread and verify its creation
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for creating a thread
        When I send a POST request to "/api/projects/<projectId>/threads?api-version=<api-version>"
        Then the response status code should be 200
        And I store the thread id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview |

@regression @implicit @assistants 
Scenario Outline: Get thread detail
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/messages?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@regression @implicit @assistants 
Scenario Outline: Update a thread metadata
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for updating a thread metadata
        When I send a PUT request to "/api/projects/<projectId>/threads/{{threadId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@create_message @assistants @implicit @regression
Scenario Outline: Create a new message and verify its creation
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for creating a message
        When I send a POST request to "/api/projects/<projectId>/threads/{{threadId}}/messages?<api-version>"
        Then the response status code should be 200
        And I store the message id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@get_message @assistants @implicit @regression 
Scenario Outline: Get a message and verify its details
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/messages/{{messageId}}?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@regression @implicit @assistants
Scenario Outline: Update a message
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for updating a message
        When I send a PUT request to "/api/projects/<projectId>/threads/{{threadId}}/messages/{{messageId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@list_messages @assistants @implicit @regression 
Scenario Outline: List messages in a thread and verify their details
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/messages?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@create_run @assistants @implicit @regression 
Scenario Outline: Create a new run and verify its creation
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for creating a run
        When I send a POST request to "/api/projects/<projectId>/threads/{{threadId}}/runs?<api-version>"
        Then the response status code should be 200
        And I store the run id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@get_run @assistants @implicit @regression 
Scenario Outline: Get a run and verify its details
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@regression @implicit @assistants
Scenario Outline: Update a run
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for updating a run metadata
        When I send a PUT request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@list_run_steps @assistants @implicit @regression
Scenario Outline: List execution steps of a run
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}/steps?<api-version>"
        Then the response status code should be 200
        And I store one step id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@list_run_steps @assistants @implicit @regression 
Scenario Outline: List execution steps of a run
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}/steps?<api-version>"
        Then the response status code should be 200
        And I store one step id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@get_run @assistants @implicit @regression
Scenario Outline: Get a specific run step
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}/steps/{{stepId}}?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@list_run @assistants @implicit @regression 
Scenario Outline: List runs 
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs?<api-version>&limit=20"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@regression @implicit @assistants 
Scenario Outline: Delete a thread
        Given the API client for assistants is configured with region "<region>"
        When I send a DELETE request to "/api/projects/<projectId>/threads/{{threadId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@regression @implicit @assistants 
Scenario Outline: Delete an assistant
        Given the API client for assistants is configured with region "<region>"
        When I send a DELETE request to "/api/projects/<projectId>/assistants/{{assistantId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |


