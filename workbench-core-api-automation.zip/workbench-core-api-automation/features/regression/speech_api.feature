Feature: Regression test for Speech API
	As an API automation engineer
	I want to perform regression tests for Speech API functionality
    So that I can ensure the basic functionality of Speech API is working as expected

#API Version Guide
#Speech to Text: 2024-11-15
#Text to Speech: 2024-04-

@speech_to_text @implicit @regression @speech_api
Scenario Outline: Verify getting a list of supported locales for offline transcriptions
		Given the API client for Speech API is configured with region "<region>"
        When I send a GET request to "/genai/azure/speech/speechtotext/transcriptions/locales?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |

@speech_api @439063 @regression @implicit_auth @submit_transcription_job @speech_to_text
Scenario Outline: Verify Submits a new transcription job
		Given the API client for Speech API is configured with region "<region>"
		And I prepare a valid request body for submitting a transcription job
        When I send a POST request to "/genai/azure/speech/speechtotext/transcriptions:submit?api-version=<api-version>"
        Then the response status code should be 200
        And I store the transcription job id from the response	

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |
    #Gets 200 but status is Not Started. The container access is denied. Need to check with the service team if there is any issue with the container access or if there is any additional configuration needed to access the container for the transcription job.

@speech_to_text @implicit @regression @speech_api
Scenario Outline: Verify getting the transcription identified by the given id
		Given the API client for Speech API is configured with region "<region>"
		And I have a valid transcription job id stored from the previous scenario outline
        When I send a GET request to "/genai/azure/speech/speechtotext/transcriptions/{{transcriptionJobId}}?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |        

@speech_api @439067 @regression @implicit_auth @speech_to_text @synchronous_transcription
Scenario Outline:  Verify Synchronous transcription of an audio file
		Given the API client for Speech API is configured with region "<region>"
		And I prepare a valid request body for synchronous transcription of an audio file
        When I send a POST request to "/genai/azure/speech/speechtotext/transcriptions:transcribe?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |

@regression @implicit @speech_to_text @update_transcription @speech_api
Scenario Outline:  Verify updating the mutable details of the transcription identified by its ID
		Given the API client for Speech API is configured with region "<region>"
		And I prepare a valid request body for updating the mutable details of the transcription identified by its ID
        When I send a POST request to "/genai/azure/speech/speechtotext/transcriptions/{{transcriptionJobId}}?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |

@speech_api @439072 @regression @implicit_auth @speech_to_text
Scenario Outline:  Verify Gets the files of the transcription job identified by the transcription job id with 3mb wav file size
		Given the API client for Speech API is configured with region "<region>"
		And I have a valid transcription job id stored from the previous scenario outline
        When I send a GET request to "/genai/azure/speech/speechtotext/transcriptions/{{transcriptionJobId}}/files?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-11-15  |
    | australiaeast | 2024-11-15  |
    | westeurope    | 2024-11-15  |

@speech_api @439048 @regression @implicit_auth @text_to_speech @skip
Scenario Outline: Verify submit text to speech
		Given the API client for Speech API is configured with region "<region>"
		And I prepare a valid request body for submitting text to speech
        When I send a POST request to "/genai/azure/speech/texttospeech"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-04-01  |
    | australiaeast | 2024-04-01  |
    | westeurope    | 2024-04-01  |

@speech_api @439072 @regression @implicit_auth @speech_api
Scenario Outline: Verify Creates a batch synthesis job for hindi language
		Given the API client for Speech API is configured with region "<region>"
		And I generate a unique batch synthesis job id
		And I prepare a valid request body for creating a batch synthesis job
        When I send a POST request to "/genai/azure/speech/texttospeech/batchsyntheses/{{batchSynthesisId}}?api-version=<api-version>"
		Then the response status code should be 200
        And I store the batch synthesis job id from the response

    	Examples:
    | region        | api-version |
    | eastus        | 2024-04-01  |
    | australiaeast | 2024-04-01  |
    | westeurope    | 2024-04-01  |
    
@speech_api @439072 @regression @implicit_auth
Scenario Outline: Verify Gets the status of a batch synthesis job identified by the batch synthesis job id for hindi language
		Given the API client for Speech API is configured with region "<region>"
		And I have a valid batch synthesis job id stored from the previous scenario outline
        When I send a GET request to "/genai/azure/speech/texttospeech/batchsyntheses/{{batchSynthesisId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-04-01  |
    | australiaeast | 2024-04-01  |
    | westeurope    | 2024-04-01  |

@speech_api @regression @implicit_auth
Scenario Outline: Verify the deletion of the batch synthesis identified by the given ID
		Given the API client for Speech API is configured with region "<region>"
		And I have a valid batch synthesis job id stored from the previous scenario outline
        When I send a DELETE request to "/genai/azure/speech/texttospeech/batchsyntheses/{{batchSynthesisId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 2024-04-01  |
    | australiaeast | 2024-04-01  |
    | westeurope    | 2024-04-01  |