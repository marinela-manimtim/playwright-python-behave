Feature: Regression test for AI Search end-to-end workflow
  As an API automation engineer
  I want to perform regression tests for the AI Search end-to-end pipeline
  So that I can ensure catalog ingestion, Azure AI Search indexing, and agent Q&A all work as expected

  @create_catalog @ai_search @regression @implicit
  Scenario Outline: Create a catalog for AI Search end-to-end test
    Given the API client for AI Search is configured with region "<region>"
    When I create an AI Search catalog named "<catalog_name>"
    Then the AI Search catalog should be created successfully and catalog id should be saved

    Examples:
      | region        | catalog_name                      |
      | eastus        | Regression_aisearch_catalog_amer        |
      | australiaeast | Regression_aisearch_catalog_aspac       |
      | westeurope    | Regression_aisearch_catalog_emea        |

  @create_catalog_source @ai_search @regression @implicit
  Scenario Outline: Create a catalog source for AI Search end-to-end test
    Given the AI Search catalog is ready for AI Search in region "<region>" with name "<catalog_name>"
    When I create an AI Search catalog source with storage account "<storage_account_name>"
    Then the AI Search catalog source should be created successfully and source id should be saved

    Examples:
      | region        | catalog_name                 | storage_account_name    |
      | eastus        | Regression_aisearch_catalog_amer  | dlsapimregwbameruseqa   |
      | australiaeast | Regression_aisearch_catalog_aspac | dlsapimregwbapacaueqa   |
      | westeurope    | Regression_aisearch_catalog_emea  | dlsapimregwbemeaweuqa   |

  @start_ingestion @ai_search @regression @implicit
  Scenario Outline: Start ingestion job for AI Search end-to-end test
    Given the AI Search catalog and source are ready for ingestion in region "<region>" with name "<catalog_name>"
    When I start an AI Search ingestion job
    Then the AI Search ingestion job should be accepted and ingestion job id should be saved

    Examples:
      | region        | catalog_name                 |
      | eastus        | Regression_aisearch_catalog_amer  |
      | australiaeast | Regression_aisearch_catalog_aspac |
      | westeurope    | Regression_aisearch_catalog_emea  |

  @get_ingestion_jobs @ai_search @regression @implicit
  Scenario Outline: Poll ingestion jobs until completion for AI Search end-to-end test
    Given the AI Search ingestion job is running in region "<region>" with name "<catalog_name>"
    When I poll the ingestion jobs for the AI Search catalog until complete
    Then the ingestion job status should eventually be completed

    Examples:
      | region        | catalog_name                 |
      | eastus        | Regression_aisearch_catalog_amer  |
      | australiaeast | Regression_aisearch_catalog_aspac |
      | westeurope    | Regression_aisearch_catalog_emea  |

@create_data_source @ai_search @regression @implicit 
Scenario Outline: Create an Azure AI Search data source for AI Search end-to-end test
    Given the AI Search ingestion is complete in region "<region>"
    When I create an AI Search data source with subscriptionId "<subscriptionId>" storageResourceGroup "<storageResourceGroup>" storageAccountName "<storageAccountName>"
    Then the data source should be created successfully and data source name should be saved

    Examples:
    | region        | subscriptionId                       | storageResourceGroup                      | storageAccountName           |
    | eastus        | 52d41c4b-f44f-474d-8a17-39d0a6fcabfe | rgp-ingestion-engine-wb-amer-use-qa       | dlsingestengwbameruseqa      |
    | australiaeast | 773e5b57-1bf3-4f99-be79-910d12e3d329 | rgp-ingestion-engine-wb-apac-aue-qa       | dlsingestengwbapacaueqa      |
    | westeurope    | 4322af52-c22c-456b-92ce-87dc4c530bc8 | rgp-ingestion-engine-wb-emea-weu-qa       | dlsingestengwbemeaweuqa      |

@get_data_source @ai_search @regression @implicit
Scenario Outline: Get an Azure AI Search data source by name for AI Search end-to-end test
    Given the AI Search data source has been created in region "<region>"
    When I get the AI Search data source by name
    Then the data source should be fetched successfully by name

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@update_data_source @ai_search @regression @implicit
Scenario Outline: Create or update an Azure AI Search data source for AI Search end-to-end test
    Given the AI Search data source is ready to be updated in region "<region>"
    When I create or update the AI Search data source with updated name
    Then the data source should be created or updated successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@list_data_sources @ai_search @regression @implicit
Scenario Outline: List all Azure AI Search data sources for AI Search end-to-end test
    Given the AI Search data source is ready to be listed in region "<region>"
    When I list all AI Search data sources
    Then the updated AI Search data source should be present in the list

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@create_index @ai_search @regression @implicit 
Scenario Outline: Create an Azure AI Search index for AI Search end-to-end test
    Given the AI Search data source is ready in region "<region>"
    When I create an AI Search index
    Then the index should be created successfully and index name should be saved

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@get_index @ai_search @regression @implicit
Scenario Outline: Get an Azure AI Search index by name for AI Search end-to-end test
    Given the AI Search index has been created in region "<region>"
    When I get the AI Search index by name
    Then the index should be fetched successfully by name

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@update_index @ai_search @regression @implicit
Scenario Outline: Create or update an Azure AI Search index for AI Search end-to-end test
    Given the AI Search index is ready to be updated in region "<region>"
    When I create or update the AI Search index with updated name
    Then the index should be created or updated successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@list_indexes @ai_search @regression @implicit
Scenario Outline: List all Azure AI Search indexes for AI Search end-to-end test
    Given the AI Search index is ready to be listed in region "<region>"
    When I list all AI Search indexes
    Then the updated AI Search index should be present in the list

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@get_index_statistics @ai_search @regression @implicit
Scenario Outline: Get Azure AI Search index statistics for AI Search end-to-end test
    Given the AI Search index is ready for statistics in region "<region>"
    When I get AI Search index statistics by name
    Then the index statistics should be fetched successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@analyze_index_text @ai_search @regression @implicit
Scenario Outline: Analyze text with Azure AI Search index analyzer for AI Search end-to-end test
    Given the AI Search index is ready for text analysis in region "<region>"
    When I analyze text using the AI Search index analyzer
    Then the text should be analyzed successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@create_skillset @ai_search @regression @implicit
Scenario Outline: Create an Azure AI Search skillset for AI Search end-to-end test
    Given the AI Search index is ready in region "<region>"
    When I create an AI Search skillset
    Then the skillset should be created successfully and skillset name should be saved

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@get_skillset @ai_search @regression @implicit
Scenario Outline: Get an Azure AI Search skillset by name for AI Search end-to-end test
    Given the AI Search skillset has been created in region "<region>"
    When I get the AI Search skillset by name
    Then the skillset should be fetched successfully by name

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@update_skillset @ai_search @regression @implicit
Scenario Outline: Create or update an Azure AI Search skillset for AI Search end-to-end test
    Given the AI Search skillset is ready to be updated in region "<region>"
    When I create or update the AI Search skillset with updated name
    Then the skillset should be created or updated successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@list_skillsets @ai_search @regression @implicit
Scenario Outline: List all Azure AI Search skillsets for AI Search end-to-end test
    Given the AI Search skillset is ready to be listed in region "<region>"
    When I list all AI Search skillsets
    Then the updated AI Search skillset should be present in the list

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@create_indexer @ai_search @regression @implicit
Scenario Outline: Create an Azure AI Search indexer for AI Search end-to-end test
    Given the AI Search skillset is ready in region "<region>"
    When I create an AI Search indexer
    Then the indexer should be created successfully and indexer name should be saved

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@get_indexer @ai_search @regression @implicit
Scenario Outline: Get an Azure AI Search indexer by name for AI Search end-to-end test
    Given the AI Search indexer has been created in region "<region>"
    When I get the AI Search indexer by name
    Then the indexer should be fetched successfully by name

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@update_indexer @ai_search @regression @implicit
Scenario Outline: Create or update an Azure AI Search indexer for AI Search end-to-end test
    Given the AI Search indexer is ready to be updated in region "<region>"
    When I create or update the AI Search indexer with updated name
    Then the indexer should be created or updated successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@get_indexer_status @ai_search @regression @implicit
Scenario Outline: Get Azure AI Search indexer status for AI Search end-to-end test
    Given the AI Search indexer is ready for status in region "<region>"
    When I get the AI Search indexer status by name
    Then the AI Search indexer status should be fetched successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@list_indexers @ai_search @regression @implicit
Scenario Outline: List all Azure AI Search indexers for AI Search end-to-end test
    Given the AI Search indexer is ready to be listed in region "<region>"
    When I list all AI Search indexers
    Then the updated AI Search indexer should be present in the list

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@reset_indexer @ai_search @regression @implicit
Scenario Outline: Reset an Azure AI Search indexer for AI Search end-to-end test
    Given the AI Search indexer is ready to be reset in region "<region>"
    When I reset the AI Search indexer by name
    Then the AI Search indexer should be reset successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@run_indexer_on_demand @ai_search @regression @implicit
Scenario Outline: Run an Azure AI Search indexer on-demand for AI Search end-to-end test
    Given the AI Search indexer is ready to be run on-demand in region "<region>"
    When I run the AI Search indexer on-demand
    Then the AI Search indexer run request should be accepted

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@create_agent @ai_search @regression @implicit
Scenario Outline: Create an AI Search agent for AI Search end-to-end test
    Given the AI Search agents client is configured with region "<region>"
    When I create an AI Search agent named "<agentName>" for project "<projectId>" with model "<modelName>"
    Then the agent should be created successfully and assistant id should be saved

    Examples:
    | region        | projectId              | agentName               | modelName                        |
    | eastus        | aif-prj-wb-amer-use-qa | agent-aisearch-amer     | gpt-4o-2024-11-20-gs-eus2        |
    | australiaeast | aif-prj-wb-apac-aue-qa | agent-aisearch-aspac    | gpt-4o-2024-11-20-std-ae         |
    | westeurope    | aif-prj-wb-emea-weu-qa | agent-aisearch-emea     | gpt-4o-2024-08-06-dzs-sdc        |

@create_thread @ai_search @regression @implicit
Scenario Outline: Create a thread for AI Search end-to-end test
    Given the AI Search agent is ready in region "<region>"
    When I create an AI Search thread for project "<projectId>"
    Then the thread should be created successfully and thread id should be saved

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@create_message @ai_search @regression @implicit
Scenario Outline: Create a user message for AI Search end-to-end test
    Given the AI Search thread is ready in region "<region>"
    When I create an AI Search message for project "<projectId>"
    Then the message should be created successfully and message id should be saved

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@create_run @ai_search @regression @implicit
Scenario Outline: Create a run for AI Search end-to-end test
    Given the AI Search thread is ready for run in region "<region>"
    When I create an AI Search run for project "<projectId>"
    Then the run should be created successfully and run id should be saved

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@get_run @ai_search @regression @implicit
Scenario Outline: Poll a run until completion for AI Search end-to-end test
    Given the AI Search run is started in region "<region>"
    When I poll the AI Search run until complete for project "<projectId>"
    Then the AI Search run status should eventually be completed

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@list_messages @ai_search @regression @implicit
Scenario Outline: List messages in the AI Search thread for AI Search end-to-end test
    Given the AI Search run is complete in region "<region>"
    When I list messages in the AI Search thread for project "<projectId>"
    Then the messages should be listed successfully

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@delete_thread @ai_search @regression @implicit
Scenario Outline: Delete thread for AI Search end-to-end test
    Given the AI Search thread is ready to be deleted in region "<region>"
    When I delete the AI Search thread for project "<projectId>"
    Then the AI Search thread should be deleted successfully

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@delete_agent @ai_search @regression @implicit
Scenario Outline: Delete agent for AI Search end-to-end test
    Given the AI Search agent is ready to be deleted in region "<region>"
    When I delete the AI Search agent for project "<projectId>"
    Then the AI Search agent should be deleted successfully

    Examples:
    | region        | projectId              |
    | eastus        | aif-prj-wb-amer-use-qa |
    | australiaeast | aif-prj-wb-apac-aue-qa |
    | westeurope    | aif-prj-wb-emea-weu-qa |

@delete_indexer @ai_search @regression @implicit
Scenario Outline: Delete indexer for AI Search end-to-end test
    Given the AI Search indexer is ready to be deleted in region "<region>"
    When I delete the AI Search indexer by name
    Then the AI Search indexer should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@delete_skillset @ai_search @regression @implicit
Scenario Outline: Delete skillset for AI Search end-to-end test
    Given the AI Search skillset is ready to be deleted in region "<region>"
    When I delete the AI Search skillset by name
    Then the AI Search skillset should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@delete_index @ai_search @regression @implicit
Scenario Outline: Delete index for AI Search end-to-end test
    Given the AI Search index is ready to be deleted in region "<region>"
    When I delete the AI Search index by name
    Then the AI Search index should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@delete_data_source @ai_search @regression @implicit
Scenario Outline: Delete data source for AI Search end-to-end test
    Given the AI Search data source is ready to be deleted in region "<region>"
    When I delete the AI Search data source by name
    Then the AI Search data source should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@delete_catalog_source @ai_search @regression @implicit
Scenario Outline: Delete catalog source for AI Search end-to-end test
    Given the AI Search catalog source is ready to be deleted in region "<region>"
    When I delete the AI Search catalog source
    Then the AI Search catalog source should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@delete_catalog @ai_search @regression @implicit
Scenario Outline: Delete catalog for AI Search end-to-end test
    Given the AI Search catalog is ready to be deleted in region "<region>"
    When I delete the AI Search catalog
    Then the AI Search catalog should be deleted successfully

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@negative_update_data_source_invalid_type @ai_search @regression @implicit
Scenario Outline: Create or update a data source with invalid data source type
    Given the AI Search data source negative test setup is ready in region "<region>"
    When I create or update an AI Search data source with invalid type
    Then the invalid data source type request should fail with HTTP 400 and expected message

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@negative_create_index_missing_fields @ai_search @regression @implicit
Scenario Outline: Create a new index with missing mandatory parameters
    Given the AI Search index negative test setup is ready in region "<region>"
    When I create an AI Search index with missing mandatory parameters
    Then the missing mandatory index parameters request should fail with HTTP 400 and expected message

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@negative_create_skillset_missing_parameters @ai_search @regression @implicit
Scenario Outline: Create a skillset with missing parameter
    Given the AI Search skillset negative test setup is ready in region "<region>"
    When I create an AI Search skillset with missing parameters
    Then the missing skillset parameters request should fail with HTTP 400 and expected message

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@negative_create_indexer_missing_parameters @ai_search @regression @implicit
Scenario Outline: Create a new indexer with missing parameters
    Given the AI Search indexer negative test setup is ready in region "<region>"
    When I create an AI Search indexer with missing parameters
    Then the missing indexer parameters request should fail with HTTP 400 and expected message

    Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

