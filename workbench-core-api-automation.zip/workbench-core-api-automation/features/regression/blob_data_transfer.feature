Feature: Regression test for blob data transfer
	As an API automation engineer
	I want to perform regression tests for blob data transfer functionality
    So that I can ensure the basic functionality of blob data transfer is working as expected

@api_version @blob_data_transfer @364909 @regression @implicit @skip_region_override_australiaeast
Scenario Outline: Verify the api version for the blob data transfer endpoint
		Given the API client for chat completions is configured with region "<region>"
		When I send a GET request to "/data-transfer/azure/azcopy/version"
		Then the response status code should be 200

    	Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@health_check @blob_data_transfer @364908 @regression @implicit @skip_region_override_australiaeast
Scenario Outline: Verify the health check status of the api for the blob data transfer endpoint
		Given the API client for chat completions is configured with region "<region>"
		When I send a GET request to "/data-transfer/azure/azcopy/health-check/self"
		Then the response status code should be 200

    	Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |

@data_transfer_job @364251 @blob_data_transfer @364256 @365427 @365431 @364259 @regression @implicit @skip_region_override_australiaeast
Scenario Outline: Create a new data transfer job and verify its status
		Given the API client for chat completions is configured with region "<region>"
		And I prepare a valid payload for creating a data transfer job
		When I send a POST request to "/data-transfer/azure/azcopy/azure/azcopysync"
		Then the response status code should be 202
		And I store the ingestion job id from the response
		When I poll the data transfer job status until completion
		Then the data transfer job should be completed successfully

    	Examples:
    | region        |
    | eastus        |
    | australiaeast |
    | westeurope    |