Feature: Regression test for RAG Enrichment workflow
  As an API automation engineer
  I want to perform regression tests for RAG Enrichment
  So that I can ensure text analysis job submission, job status retrieval, and runtime analysis work as expected

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Submit Analyze Text Job
    Given the RAG Enrichment API client is configured with region "<region>"
    When I submit the Analyze Text Job
    Then the Analyze Text Job should be accepted and operation-location should be saved

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Get Analyze Text Job Status
    Given the Analyze Text Job is started in region "<region>"
    When I get the Analyze Text Job status
    Then the Analyze Text Job status should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Text Analysis Runtime
    Given the RAG Enrichment API client is configured with region "<region>"
    When I submit the Text Analysis Runtime job
    Then the Text Analysis Runtime job should be accepted and operation-location should be saved

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Submit Analyze Text Job with malformed JSON format
    Given the RAG Enrichment malformed analyze text request client is configured with region "<region>"
    When I submit the Analyze Text Job API request with malformed JSON format
    Then the Submit Analyze Text Job malformed JSON error should return status 400 with message "Invalid Request."

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Get Analyze Text Job Status with invalid or non-existing job id
    Given the RAG Enrichment invalid analyze text job status client is configured with region "<region>"
    When I get the Analyze Text Job status using invalid or non-existing job id "abcde12345"
    Then the Get Analyze Text Job Status invalid job id error should return status 400 with message "Invalid Request."

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_enrichment_regression @regression @implicit
  Scenario Outline: Text Analysis Runtime with invalid request body
    Given the RAG Enrichment invalid text analysis runtime client is configured with region "<region>"
    When I submit the Text Analysis Runtime job with invalid request body
    Then the Text Analysis Runtime invalid request body error should return status 400

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |