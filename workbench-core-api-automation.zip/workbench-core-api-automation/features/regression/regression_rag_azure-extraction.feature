Feature: Regression test for RAG Azure Extraction workflow
  As an API automation engineer
  I want to perform regression tests for RAG Azure Extraction
  So that I can ensure model discovery and document analysis APIs work as expected

  @rag_azure_extraction @regression @implicit 
  Scenario Outline: List Models for RAG Azure Extraction
    Given the API client for RAG Azure Extraction list models is configured with region "<region>"
    When I list RAG Azure Extraction models
    Then the RAG Azure Extraction models should be listed successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_azure_extraction @regression @implicit 
  Scenario Outline: Get Model for RAG Azure Extraction
    Given the API client for RAG Azure Extraction get model is configured with region "<region>"
    When I get the first listed RAG Azure Extraction model
    Then the RAG Azure Extraction model should be fetched successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_azure_extraction @regression @implicit 
  Scenario Outline: Analyze Document for RAG Azure Extraction
    Given the API client for RAG Azure Extraction analyze document is configured with region "<region>"
    When I analyze a document using the first listed RAG Azure Extraction model with storage account "<storage_account_name>"
    Then the RAG Azure Extraction analyze request should be accepted and analyze result id should be saved

    Examples:
      | region        | storage_account_name   |
      | eastus        | dlsapimregwbameruseqa  |
      | australiaeast | dlsapimregwbapacaueqa  |
      | westeurope    | dlsapimregwbemeaweuqa  |

  @rag_azure_extraction @regression @implicit 
  Scenario Outline: Get Analyze result for RAG Azure Extraction
    Given the RAG Azure Extraction analyze request is started in region "<region>"
    When I get the RAG Azure Extraction analyze result for the first listed model
    Then the RAG Azure Extraction analyze result should be fetched successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_azure_extraction @regression @implicit
  Scenario Outline: Analyze Document for RAG Azure Extraction with invalid model id
    Given the API client for RAG Azure Extraction invalid model analyze document is configured with region "<region>"
    When I analyze a document using an invalid RAG Azure Extraction modelId "invalid-model" with storage account "<storage_account_name>"
    Then the RAG Azure Extraction invalid model analyze response should contain validation details

    Examples:
      | region        | storage_account_name   |
      | eastus        | dlsapimregwbameruseqa  |
      | australiaeast | dlsapimregwbapacaueqa  |
      | westeurope    | dlsapimregwbemeaweuqa  |
