Feature: Regression test for RAG Text Chunking workflow
  As an API automation engineer
  I want to perform regression tests for RAG Text Chunking
  So that I can ensure chunking, health, and version APIs work as expected

  @rag_text_chunking_regression @regression @implicit
  Scenario Outline: Create a list of chunks from a specified input string
    Given the RAG Text Chunking chunking API client is configured with region "<region>"
    When I create a list of chunks from the specified input string
    Then the chunk list should be created successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_text_chunking_regression @regression @implicit
  Scenario Outline: Gets the health check status of the API
    Given the RAG Text Chunking health check API client is configured with region "<region>"
    When I get the RAG Text Chunking health check status
    Then the RAG Text Chunking health check should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_text_chunking_regression @regression @implicit
  Scenario Outline: Gets the version of the API
    Given the RAG Text Chunking version API client is configured with region "<region>"
    When I get the RAG Text Chunking API version
    Then the RAG Text Chunking API version should be returned successfully

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_text_chunking_regression @regression @implicit
  Scenario Outline: Create chunks with empty extractedFileContent returns validation error
    Given the RAG Text Chunking negative case API client is configured with region "<region>"
    When I create a list of chunks with empty extractedFileContent
    Then the empty extractedFileContent response should contain the expected validation error

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |

  @rag_text_chunking_regression @regression @implicit
  Scenario Outline: Create chunks with invalid overlapToken value returns validation error
    Given the RAG Text Chunking overlap tokens negative case API client is configured with region "<region>"
    When I create a list of chunks with overlapTokens greater than tokensPerChunk
    Then the overlapTokens validation response should contain the expected error message

    Examples:
      | region        |
      | eastus        |
      | australiaeast |
      | westeurope    |
