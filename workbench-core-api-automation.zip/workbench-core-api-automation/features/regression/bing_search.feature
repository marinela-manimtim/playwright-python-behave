Feature: Regression test for bing search
	As an API automation engineer
	I want to perform regression tests for bing search functionality
    So that I can ensure the basic functionality of bing search is working as expected

@create_agent @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Create a new agent with bing search enabled and verify its creation
		Given the API client for agents is configured with region "<region>"
		And I prepare a valid request body for creating an agent with model "<model>" with bing search enabled
        When I send a POST request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
		Then the response status code should be 200
        And I store the agent assistant id from the response

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@create_agent @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Create a new agent with bing search enabled with invalid model name
		Given the API client for agents is configured with region "<region>"
		And I prepare a valid request body for creating an agent with model "<model>" with bing search enabled
        When I send a POST request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
		Then the response status code should be 400

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae-invalid |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae-invalid |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc-invalid |

@create_agent @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Create a new agent with bing search enabled with missing tool type
		Given the API client for agents is configured with region "<region>"
		And I prepare a valid request body for creating an agent with model "<model>" with bing search enabled with missing tool type
        When I send a POST request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
		Then the response status code should be 403

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae-invalid |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae-invalid |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc-invalid |

@regression @implicit @assistants @bing_search @regression
Scenario Outline: Get assistant details and verify its information 
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/assistants/{{assistantId}}?api-version=<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview |

@regression @list_assistants @implicit @assistants @bing_search @regression
Scenario Outline: List all assistants in a project
        Given the API client for assistants is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/assistants?api-version=<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview |

@regression @implicit @assistants @bing_search @regression
Scenario Outline: Update an assistant and verify the update
        Given the API client for assistants is configured with region "<region>"
        And I prepare a valid request body for updating an assistant with model "<model>"
        When I send a PUT request to "/api/projects/<projectId>/assistants/{{assistantId}}?api-version=<api-version>"
        Then the response status code should be 200

    	Examples:
    | region        | projectId              | api-version                    | model                    |
    | eastus        | aif-prj-wb-amer-use-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | australiaeast | aif-prj-wb-apac-aue-qa | 2025-05-15-preview | gpt-4-1-2025-04-14-gs-ae |
    | westeurope    | aif-prj-wb-emea-weu-qa | 2025-05-15-preview | gpt-4o-2024-11-20-gs-sdc |

@create_thread @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Create a new thread and verify its creation
    Given the API client for agents is configured with region "<region>"
    And I prepare a valid request body for creating an agent thread
    When I send a POST request to "/api/projects/<projectId>/threads?<api-version>"
    Then the response status code should be 200
    And I store the agent thread id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@create_run @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Create a new run and verify its creation
    Given the API client for agents is configured with region "<region>"
    And I prepare a valid request body for creating an agent run
    When I send a POST request to "/api/projects/<projectId>/threads/{{threadId}}/runs?<api-version>"
    Then the response status code should be 200
    And I store the agent run id from the response
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |

@get_run @agents @525527 @implicit_auth @bing_search @regression
Scenario Outline: Get a run and verify its details
        Given the API client for agents is configured with region "<region>"
        When I send a GET request to "/api/projects/<projectId>/threads/{{threadId}}/runs/{{runId}}?<api-version>"
        Then the response status code should be 200
 
        Examples:
    | region        | projectId              | api-version                    |
    | eastus        | aif-prj-wb-amer-use-qa | api-version=2025-05-15-preview |
    | australiaeast | aif-prj-wb-apac-aue-qa | api-version=2025-05-15-preview |
    | westeurope    | aif-prj-wb-emea-weu-qa | api-version=2025-05-15-preview |