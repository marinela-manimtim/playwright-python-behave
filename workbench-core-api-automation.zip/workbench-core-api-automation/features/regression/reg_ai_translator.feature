Feature: Regression test for AI Translator
	As an API automation engineer
	I want to perform regression tests for AI Translator functionality
    So that I can ensure the basic functionality of AI Translator is working as expected

@regression @ai_translator @reg_translator @implicit 
Scenario Outline: Verify the list of languages supported by the API
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/text/languages?api-version=<api-version>"
		Then the response status code should be 200

    Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

#@regression @ai_translator @reg_translator @implicit
#Scenario Outline: Verify the set of languages that are supported by the API
#		Given the API client for AI Translator is configured with region "<region>"
#		And I prepare a valid request body for detecting language from a piece of text
#        When I send a POST request to "/translator/azure/text/languages?api-version=<api-version>"
#		Then the response status code should be 200
#
#    	Examples:
#   | region        | api-version |
#    | eastus        | 2024-05-01         |
#    | australiaeast | 2024-05-01         |
#    | westeurope    | 2024-05-01         |

@regression @ai_translator @reg_translator @implicit
Scenario Outline: Verify the set of languages that are supported by the API with missing mandatory parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for detecting language from a piece of text
        When I send a POST request to "/translator/azure/text/languages?api-version=<api-version>"
		Then the response status code should be 404

    	Examples:
    | region        | api-version |
    | eastus        | EMPTY       |
    | australiaeast | EMPTY       |
    | westeurope    | EMPTY       |

@regression @ai_translator @363789 @implicit_auth @reg_translator @detect
Scenario Outline: Verify that the API can detect language from a piece of text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for detecting language from a piece of text
        When I send a POST request to "/translator/azure/text/detect?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 3.0         |
    | australiaeast | 3.0         |
    | westeurope    | 3.0         |

@regression @ai_translator @363778 @implicit_auth @reg_translator 
Scenario Outline: Verify the translation of text to the desired target language with mandatory parameters only
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for translating a piece of text with mandatory parameters only
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | to |
    | eastus        | 3.0         | hi |
    | australiaeast | 3.0         | hi |
    | westeurope    | 3.0         | hi |

@regression @ai_translator @363778 @implicit_auth @reg_translator
Scenario Outline: Verify the translation of text to the desired target language with mandatory and optional parameters
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for translating a piece of text with mandatory and optional parameters
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>&textType=<textType>&category=<category>&profanityAction=<profanityAction>&profanityMarker=<profanityMarker>&includeAlignment=<includeAlignment>&includeSentenceLength=<includeSentenceLength>&allowFallback=<allowFallback>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | to | textType | category | profanityAction | profanityMarker | includeAlignment | includeSentenceLength | allowFallback |
    | eastus        | 3.0         | hi | plain    | general  | NoAction        | Asterisk        | false            | false                 | true          |
    | australiaeast | 3.0         | hi | plain    | general  | NoAction        | Asterisk        | false            | false                 | true          |
    | westeurope    | 3.0         | hi | plain    | general  | NoAction        | Asterisk        | false            | false                 | true          |

@regression @ai_translator @363778 @implicit_auth @reg_translator
Scenario Outline: Verify the translation of text to the desired target language with mandatory parameters only
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for translating a piece of text with mandatory parameters only
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>"
		Then the response status code should be 200
        #should return error message for invalid target language

    	Examples:
    | region        | api-version | to    |
    | eastus        | 3.0         | hi |
    | australiaeast | 3.0         | hi |
    | westeurope    | 3.0         | hi |

@regression @ai_translator @363778 @implicit_auth @reg_translator 
Scenario Outline: Verify the translation of text with missing mandatory parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for translating a piece of text with mandatory parameters only
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | to |
    | eastus        | EMPTY       | hi |
    | australiaeast | EMPTY       | hi |
    | westeurope    | EMPTY       | hi |

@regression @ai_translator @363782 @implicit_auth @reg_translator 
Scenario Outline: Verify the transliteration of text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for transliterating a piece of text
        When I send a POST request to "/translator/azure/text/transliterate?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | hi       | Deva       | Latn     |
    | australiaeast | 3.0         | hi       | Deva       | Latn     |
    | westeurope    | 3.0         | hi       | Deva       | Latn     |

@regression @ai_translator @363782 @implicit_auth @reg_translator 
Scenario Outline: Verify the transliteration of text for unsupported language for the given from and to script
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for transliterating a piece of text
        When I send a POST request to "/translator/azure/text/transliterate?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | en       | Deva       | Latn     |
    | australiaeast | 3.0         | en       | Deva       | Latn     |
    | westeurope    | 3.0         | en       | Deva       | Latn     |

@regression @ai_translator @363782 @implicit_auth @reg_translator 
Scenario Outline: Verify the transliteration of text for missing mandatory parameters
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for transliterating a piece of text
        When I send a POST request to "/translator/azure/text/transliterate?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 400
        #should return error message for missing mandatory parameters

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | hi       | Deva       | EMPTY    |
    | australiaeast | 3.0         | hi       | Deva       | EMPTY    |
    | westeurope    | 3.0         | hi       | Deva       | EMPTY    |

@regression @reg_translator @implicit    
Scenario Outline: Verify the breaking of sentence by identifying the positioning of sentence boundaries in a piece of text with mandatory parameter only
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for breaking a sentence
        When I send a POST request to "/translator/azure/text/breaksentence?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 3.0         |
    | australiaeast | 3.0         |
    | westeurope    | 3.0         |

@regression @ai_translator @363786 @implicit_auth @reg_translator
Scenario Outline: Verify the breaking of sentence by identifying the positioning of sentence boundaries in a piece of text with mandatory as well as optional parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for breaking a sentence
        When I send a POST request to "/translator/azure/text/breaksentence?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | hi       | Deva       | latn     |
    | australiaeast | 3.0         | hi       | Deva       | latn     |
    | westeurope    | 3.0         | hi       | Deva       | latn     |

@regression @implicit @reg_translator 
Scenario Outline: Verify the breaking of sentence with invalid language in optional parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for breaking a sentence
        When I send a POST request to "/translator/azure/text/breaksentence?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | od       | Deva       | latn     |
    | australiaeast | 3.0         | od       | Deva       | latn     |
    | westeurope    | 3.0         | od       | Deva       | latn     |


@regression @implicit @reg_translator 
Scenario Outline: Verify the breaking of sentence with invalid script length in optional parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for breaking a sentence
        When I send a POST request to "/translator/azure/text/breaksentence?api-version=<api-version>&language=<language>&fromScript=<fromScript>&toScript=<toScript>"
		Then the response status code should be 400
        
    	Examples:
    | region        | api-version | language | fromScript | toScript |
    | eastus        | 3.0         | od       | De       | la     |
    | australiaeast | 3.0         | od       | De       | la     |
    | westeurope    | 3.0         | od       | De      | la     |

@regression @reg_translator @implicit 
Scenario Outline: Verify the detection of language from a piece of text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for detecting language from a piece of text
        When I send a POST request to "/translator/azure/text/detect?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version |
    | eastus        | 3.0         |
    | australiaeast | 3.0         |
    | westeurope    | 3.0         |
    
@regression @ai_translator @363790 @implicit_auth @reg_translator
Scenario Outline: Verify the dictionary examples for the provided texts
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary examples
        When I send a POST request to "/translator/azure/text/dictionary/examples?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | en   | es |
    | australiaeast | 3.0         | en   | es |
    | westeurope    | 3.0         | en   | es |

@regression @ai_translator @363790 @implicit_auth @reg_translator 
Scenario Outline: Verify the dictionary examples for unsupported dictionary language
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary examples
        When I send a POST request to "/translator/azure/text/dictionary/examples?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | en   | od |
    | australiaeast | 3.0         | en   | od |
    | westeurope    | 3.0         | en   | od |

@regression @ai_translator @363792 @implicit_auth @reg_translator
Scenario Outline: Verify the dictionary lookup for a given text
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary lookup
        When I send a POST request to "/translator/azure/text/dictionary/lookup?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | en   | es |
    | australiaeast | 3.0         | en   | es |
    | westeurope    | 3.0         | en   | es |

@regression @ai_translator @implicit_auth @reg_translator 
Scenario Outline: Verify the dictionary lookup for a given text with invalid pair dictionary languages
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for dictionary lookup
        When I send a POST request to "/translator/azure/text/dictionary/lookup?api-version=<api-version>&from=<from>&to=<to>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version | from | to |
    | eastus        | 3.0         | bn   | bg |
    | australiaeast | 3.0         | bn   | bg |
    | westeurope    | 3.0         | bn   | bg |

@regression @ai_translator @363794 @timeout_override @implicit_auth @reg_translator @start_batch_translation
Scenario Outline: Verify start batch translation for a single file
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for batch translation
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 202
        And I store the batch id from the response

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @timeout_override @implicit_auth @reg_translator
Scenario Outline: Verify start batch translation for an existing file
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for batch translation without cleanup
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 202

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @timeout_override @implicit_auth @reg_translator 
Scenario Outline: Verify the batch translation for missing source and target url
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare an invalid request body for batch translation with missing source and target url
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for a specific translation job for a single file
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}?api-version=<api-version>"
		Then the response status code should be 200
        And I verify the batch translation status in the response


    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for a specific translation job with invalid id
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/<invalidId>?api-version=<api-version>"
		Then the response status code should be 404

    Examples:
    | region        | api-version | invalidId |
    | eastus        | 2024-05-01  | invalidId12345 |
    | australiaeast | 2024-05-01  | invalidId12345 |
    | westeurope    | 2024-05-01  | invalidId12345 |

@regression @ai_translator @timeout_override @implicit @reg_translator 
Scenario Outline: Verify the status for a specific translation job with invalid api version
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}?api-version=<api-version>"
		Then the response status code should be 404

    	Examples:
    | region        | api-version |
    | eastus        | 0000-00-00  |
    | australiaeast | 0000-00-00  |
    | westeurope    | 0000-00-00  |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the supported document formats
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/formats?api-version=<api-version>&type=<type>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | type |
    | eastus        | 2024-05-01  | document |
    | australiaeast | 2024-05-01  | document |
    | westeurope    | 2024-05-01  | document |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the supported glossary formats
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/formats?api-version=<api-version>&type=<type>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | type |
    | eastus        | 2024-05-01  | glossary |
    | australiaeast | 2024-05-01  | glossary |
    | westeurope    | 2024-05-01  | glossary |

@regression @ai_translator @timeout_override @implicit @reg_translator 
Scenario Outline: Verify the supported formats using an invalid type
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/formats?api-version=<api-version>&type=<type>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version | type |
    | eastus        | 2024-05-01  | txt |
    | australiaeast | 2024-05-01  | txt |
    | westeurope    | 2024-05-01  | txt |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for all documents in a translation job with only mandatory parameters
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}/documents?api-version=<api-version>"
		Then the response status code should be 200
        And I store one document id from the response with status as Succeeded

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |


@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for all documents in a translation job with mandatory as well as optional parameters
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}/documents?api-version=<api-version>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | statuses |
    | eastus        | 2024-05-01  | Succeeded |
    | australiaeast | 2024-05-01  | Succeeded |
    | westeurope    | 2024-05-01  | Succeeded |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for all documents in a translation job with invalid id
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/<invalidId>/documents?api-version=<api-version>"
		Then the response status code should be 404

    Examples:
    | region        | api-version | invalidId |
    | eastus        | 2024-05-01  | invalidId12345 |
    | australiaeast | 2024-05-01  | invalidId12345 |
    | westeurope    | 2024-05-01  | invalidId12345 |

@regression @ai_translator @timeout_override @implicit @reg_translator 
Scenario Outline: Verify the status for a specific document
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/{{batchId}}/documents/{{documentId}}?api-version=<api-version>"
		Then the response status code should be 200
        And I verify the batch translation status in the response


    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @timeout_override @implicit @reg_translator
Scenario Outline: Verify the status for a specific document with invalid batch id and document id
		Given the API client for AI Translator is configured with region "<region>"
        When I send a GET request to "/translator/azure/document/translator/document/batches/<invalidBatchId>/documents/<invalidDocumentId>?api-version=<api-version>"
		Then the response status code should be 404

    	Examples:
    | region        | api-version | invalidBatchId | invalidDocumentId |
    | eastus        | 2024-05-01  | invalidBatchId12345 | invalidDocumentId12345 |
    | australiaeast | 2024-05-01  | invalidBatchId12345 | invalidDocumentId12345 |
    | westeurope    | 2024-05-01  | invalidBatchId12345 | invalidDocumentId12345 |

@regression @ai_translator @363794 @timeout_override @implicit_auth @reg_translator
Scenario Outline: Verify start batch translation for maximum document size exceeded
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for batch translation
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 202
        And I store the batch id from the response
        #would need a new source url with document exceeding the maximum size limit of 100MB to test this scenario

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @363794 @timeout_override @implicit_auth @reg_translator 
Scenario Outline: Verify the batch translation for multiple files
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for batch translation
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 202
        And I store the batch id from the response
        #would need a new source url with multiple documents to test this scenario

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

@regression @ai_translator @363794 @timeout_override @implicit_auth @reg_translator 
Scenario Outline: Verify start batch translation for a single file with missing language parameter
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a request body for batch translation with missing language parameter
        When I send a POST request to "/translator/azure/document/translator/document/batches?api-version=<api-version>"
		Then the response status code should be 400

    	Examples:
    | region        | api-version |
    | eastus        | 2024-05-01  |
    | australiaeast | 2024-05-01  |
    | westeurope    | 2024-05-01  |

#Verify the logs for the batch translation

@regression @ai_translator @363794 @timeout_override @implicit_auth @reg_translator 
Scenario Outline: Verify the consumption all the Text APIs
		Given the API client for AI Translator is configured with region "<region>"
		And I prepare a valid request body for verifying the consumption of all the Text APIs
        When I send a POST request to "/translator/azure/text/translate?api-version=<api-version>&to=<to>"
		Then the response status code should be 200

    	Examples:
    | region        | api-version | to |
    | eastus        | 3.0         | hi |
    | australiaeast | 3.0         | hi |
    | westeurope    | 3.0         | hi |