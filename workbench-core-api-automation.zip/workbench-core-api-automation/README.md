# Python BDD Allure API Automation

This project provides a Python API automation starter framework using Behave for BDD and Allure for reporting.

## Stack

- Python
- Behave
- Requests
- Allure Behave formatter
- python-dotenv

## Project Structure

- `features/` - feature files, hooks, and step definitions
- `helpers/` - reusable API client, config, and assertions
- `reports/` - generated test output
- `.env.example` - sample runtime configuration
- `behave.ini` - Behave defaults

## Setup

1. Create a virtual environment.
2. Activate it.
3. Install dependencies from `requirements.txt`.
4. Copy `.env.example` to `.env` and adjust values if needed.

`VERIFY_SSL` is set to `false` in the sample file so the starter can run in environments that use SSL inspection or self-signed corporate certificates. Set it back to `true` when your machine trusts the target API certificate chain.

## Run Tests

Standard Behave run:

`python -m behave`

The default Behave configuration now also writes Allure result files to `reports/allure-results` during `python -m behave`.

If `OPEN_ALLURE_ON_COMPLETE=true` and the Allure CLI is installed on your machine, the Allure dashboard is opened automatically after the test run finishes.

## Generate Allure Report

If the Allure command line tool is installed, generate the HTML report with:

`allure serve reports/allure-results`

If you want Behave to finish without opening the browser, set `OPEN_ALLURE_ON_COMPLETE=false` in `.env`.

## Sample Scenario

The included scenario calls the public JSONPlaceholder API and validates the response status and payload fields.

## Next Steps

- Add more feature files by resource or business flow.
- Add authenticated request helpers if your APIs require tokens.
- Externalize payload templates and test data for larger suites.
