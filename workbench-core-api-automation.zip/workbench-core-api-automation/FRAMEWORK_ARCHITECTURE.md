# Framework Guide

This document explains how the current Behave API automation framework is wired together and how requests flow from feature files to API execution.

## Core files

- [behave.ini](behave.ini) - Behave runtime configuration and Allure formatter output
- [features/environment.py](features/environment.py) - lifecycle hooks, dynamic model expansion, and skip handling
- [features/steps/common_steps.py](features/steps/common_steps.py) - shared Given/Then steps and deployment-name resolution
- [features/steps/azure_openai_steps.py](features/steps/azure_openai_steps.py) - request execution and Azure OpenAI specific checks
- [features/azure_openai_deployments/openai/azure_openai_deployments.feature](features/azure_openai_deployments/openai/azure_openai_deployments.feature) - deployment and model-access scenarios
- [features/azure_openai_deployments/openai/azure_openai_completions_and_embeddings.feature](features/azure_openai_deployments/openai/azure_openai_completions_and_embeddings.feature) - chat/completions scenarios
- [helpers/config.py](helpers/config.py) - environment-driven settings and region config
- [helpers/api_client.py](helpers/api_client.py) - reusable HTTP client
- [helpers/service.py](helpers/service.py) - service layer that wires auth and API client
- [helpers/assertions.py](helpers/assertions.py) - reusable validations
- [auth/auth_handler.py](auth/auth_handler.py) - OAuth2 client credentials token handler
- [auth/playwright_auth_handler.py](auth/playwright_auth_handler.py) - Playwright-based implicit auth handler and token cache
- [requirements.txt](requirements.txt) - framework dependencies
- [README.md](README.md) - setup and run instructions

## Execution flow diagram

```mermaid
flowchart TD
    A[Run python -m behave] --> B[behave.ini]
    B --> C[features/environment.py before_all]
    C --> D[helpers/config.py get_settings]

    B --> E[Load feature files]
    E --> F[features/environment.py before_feature]
    F --> G{feature in dynamic list?}
    G -- yes --> H[GET /deployments/access for eastus/australiaeast/westeurope]
    H --> I[Expand Scenario Outline model_name rows]
    I --> J[Re-wrap rebuilt scenarios for Allure]
    G -- no --> K[No dynamic expansion]

    E --> L[Scenario starts]
    L --> M[features/environment.py before_scenario]
    M --> N{skip tag present?}
    N -- yes --> O[scenario.skip]
    N -- no --> P[Initialize context + tag flags]

    P --> Q[Given step in common_steps.py]
    Q --> R[helpers/service.py Service]
    R --> S{auth mode}
    S -->|default| T[auth/auth_handler.py AuthHandler]
    S -->|implicit tags| U[auth/playwright_auth_handler.py PlaywrightAuthHandler]
    T --> V[helpers/config.py load_region_config]
    U --> V
    V --> W[.env region credentials]
    T --> X[Azure AD token endpoint]
    R --> Y[helpers/api_client.py ApiClient]

    P --> Z[Optional deployment resolution step]
    Z --> AA[GET deployments access model instance names]
    AA --> AB[context.resolved_model_name]

    Y --> AC[When step in azure_openai_steps.py]
    AB --> AC
    AC --> AD[context.last_response]
    AD --> AE[Then steps in common_steps.py / azure_openai_steps.py]
    AE --> AF[helpers/assertions.py]

    L --> AG[features/environment.py after_scenario]
    AG --> AH[Close browser/session resources]
    AH --> AI[features/environment.py after_all]
    AI --> AJ[Optional allure serve]
```

## How the framework works

### 1) Behave configuration

When `python -m behave` runs, Behave reads [behave.ini](behave.ini):

- features path is `features`
- console formatter is `pretty`
- Allure formatter writes to `reports/allure-results`
- stdout/stderr/log capture are disabled for transparent console output
- timings are enabled (`show_timings = true`)

### 2) Feature and scenario execution

Feature files define `Scenario` and `Scenario Outline` test behavior. Region values are used to:

- set `x-kpmg-region-override`
- map to region-specific credentials (`AMER`, `EMEA`, `ASPAC`) through [helpers/config.py](helpers/config.py)

Dynamic outline expansion currently applies only when:

- feature filename is `azure_openai_completions_and_embeddings.feature`
- scenario outline includes a step containing `deployment name for model type`
- examples table includes both `region` and `model_name` headings

### 3) Step modules

#### [features/steps/common_steps.py](features/steps/common_steps.py)

Contains shared steps and model resolution logic:

- API client setup by region and auth profile (`default`, `agents`, `assistants`, `ai_translator`, `speech_api`)
- status-code assertions
- model list assertions
- deployment/model name resolution for chat endpoints

`the deployment name for model type "{model_type}" in region "{region}" is resolved` now uses `/deployments/access` and resolves from `models[].instanceName` (exact match first, then normalized prefix match).

#### [features/steps/azure_openai_steps.py](features/steps/azure_openai_steps.py)

Contains transport and payload-oriented steps:

- GET/POST request execution
- optional endpoint substitution using `context.resolved_model_name`
- placeholder substitution for IDs in endpoints (assistant/thread/message/run/step/batch/document/file/batchSynthesis/transcriptionJob)
- request/response Allure attachments
- scenario-specific response assertions

### 4) Hook lifecycle in [features/environment.py](features/environment.py)

#### `before_all()`

- loads settings
- ensures Allure results directory exists
- initializes shared context defaults
- initializes region-keyed context storage for reusable IDs (`batch`, `message`, `thread`, `run`, `transcription`)
- registers Playwright browser lifecycle hooks (open/close) for implicit-auth runs

#### `before_feature()`

- applies only to configured dynamic-model features
- fetches `/deployments/access` for each configured region
- expands `Scenario Outline` example rows where `model_name` is present
- re-wraps rebuilt scenarios for `allure_behave` formatter compatibility

#### `before_scenario()`

- reads effective tags case-insensitively
- skips scenario when `@skip` is present
- clears global implicit-token cache when `@force_auth_browser` is present
- sets per-scenario flags (`timeout_override`, `skip_auth`, `use_implicit_auth`, `skip_region_override_australiaeast`)
- resets per-scenario runtime context

#### `after_scenario()`

- closes scenario HTTP session safely
- closes developer portal Playwright page/context/browser/instance when present

#### `after_all()`

- closes any remaining session
- optionally launches Allure dashboard when `OPEN_ALLURE_ON_COMPLETE=true`

## Dynamic model resolution flow

The framework uses `/deployments/access` in two places:

1. Feature-time expansion (`before_feature`) to generate model-specific examples.
2. Runtime resolution step in [features/steps/common_steps.py](features/steps/common_steps.py) to map a requested logical model (for example `gpt-5.2`) to an actual `instanceName` used in the request path.

The resolved value is stored in `context.resolved_model_name` and consumed by POST steps in [features/steps/azure_openai_steps.py](features/steps/azure_openai_steps.py).

## Context keys used across the run

| Context key | Set in | Purpose |
|---|---|---|
| `settings` | `before_all` | framework runtime settings |
| `allure_results_dir` | `before_all` | Allure output location |
| `deployment_map` | `before_all` / `before_feature` | dynamic models by region for outline expansion |
| `client` | Given steps / hooks | region-scoped service client |
| `headers` | Given steps / hooks | request headers (region override + optional extras) |
| `last_response` | When steps | latest HTTP response for assertions |
| `request_payload` | `before_all` / `before_scenario` | baseline request payload slot reset by hooks |
| `request_body` | payload Given steps | request payload passed to POST steps |
| `resolved_model_name` | model-resolution Given step | deployment/instance name inserted into endpoint |
| `model_access_map` | deployment-resolution Given step | per-region cache of `/deployments/access` instance names |
| `timeout_override` | `before_scenario` | longer timeout for tagged scenarios |
| `skip_auth` | `before_scenario` | disables auth for `@no_auth` scenarios |
| `use_implicit_auth` | `before_scenario` | switches auth mode to Playwright implicit flow |
| `skip_region_override_australiaeast` | `before_scenario` | omits `x-kpmg-region-override` for `australiaeast` when tagged |
| `current_region` | speech setup Given step | fallback region for endpoint placeholder resolution |

## Authentication and service layering

1. Step creates `Service(region, timeout?, skip_auth?, auth_profile?, use_implicit_auth?)`.
2. `Service` reads settings from [helpers/config.py](helpers/config.py).
3. If `skip_auth=False`, `Service` chooses:
    - [auth/auth_handler.py](auth/auth_handler.py) for client-credentials OAuth2, or
    - [auth/playwright_auth_handler.py](auth/playwright_auth_handler.py) when `use_implicit_auth=True`.
4. Handler loads region/profile credentials via `load_region_config(region, profile?)`.
5. `ApiClient` is initialized with base URL, timeout, SSL setting, and merged default/auth headers.
6. Step methods call `client.get/post/...`; responses are attached to Allure and stored on context.
7. On HTTP `401` (without an explicit per-call Authorization header), `Service` refreshes auth once and retries.
8. For implicit auth, browser lifecycle callbacks emit runtime events and tokens are cached by `(region, profile)`.

## Required `.env` values

```ini
# Universal
BASE_URL=https://api.qa.workbench.kpmg/genai/azure/deployments
TOKEN_URL=https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token
AGENT_TOKEN_URL=https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token
IGNORE_SSL_VERIFY=true
API_TIMEOUT=30
DEFAULT_HEADERS={"x-example":"value"}
ALLURE_RESULTS_DIR=reports/allure-results
OPEN_ALLURE_ON_COMPLETE=true

# AMER
AMER_TENANT_ID=...
AMER_CLIENT_ID=...
AMER_CLIENT_SECRET=...
AMER_SCOPE=...

# EMEA
EMEA_TENANT_ID=...
EMEA_CLIENT_ID=...
EMEA_CLIENT_SECRET=...
EMEA_SCOPE=...

# ASPAC
ASPAC_TENANT_ID=...
ASPAC_CLIENT_ID=...
ASPAC_CLIENT_SECRET=...
ASPAC_SCOPE=...

# Required only when using implicit Playwright auth
PLAYWRIGHT_LOGIN_URL=https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/authorize?...&client_id={CLIENT_ID}
PLAYWRIGHT_USERNAME=...
PLAYWRIGHT_PASSWORD=...

# Optional Playwright auth controls
PLAYWRIGHT_HEADLESS=true
PLAYWRIGHT_SCOPE=api://.../user_impersonation
PLAYWRIGHT_EXPECT_REDIRECT_PREFIX=https://oauth.pstmn.io/v1/callback
PLAYWRIGHT_TIMEOUT_MS=60000
```

## Simple mental model

- [features/*.feature](features) = what to test
- [features/environment.py](features/environment.py) = lifecycle hooks + dynamic scenario shaping + skip control
- [features/steps/common_steps.py](features/steps/common_steps.py) = shared setup/assertions/model resolution
- [features/steps/azure_openai_steps.py](features/steps/azure_openai_steps.py) = transport and API-specific behavior
- [helpers/service.py](helpers/service.py) = auth-mode selection + retry + client wiring
- [helpers/api_client.py](helpers/api_client.py) = HTTP execution
- [helpers/assertions.py](helpers/assertions.py) = reusable validations
- [behave.ini](behave.ini) = execution defaults and reporting