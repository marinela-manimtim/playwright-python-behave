# Git Commands Reference

Quick reference for common Git operations used in this project.

---

## Setup

Clone the repository:

```powershell
git clone <repository-url>
cd workbench-core-api-automation
```

Check current status at any time:

```powershell
git status
```

Check which branch you are on:

```powershell
git branch
```

---

## One-Time Setup

### Step 1 — Generate a Personal Access Token (PAT)

1. Go to **GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)**
2. Click **Generate new token (classic)**
3. Give it a descriptive name (e.g. `workbench-automation`)
4. Set an expiration date
5. Under **Select scopes**, tick **repo**
6. Click **Generate token**
7. Copy the token immediately — GitHub only shows it once

> Use the PAT as your password whenever Git prompts for credentials over HTTPS.

To cache credentials so Git does not prompt every time:

```powershell
git config --global credential.helper manager
```

---

### Step 2 — Configure Git identity

Run these once in your terminal. This sets your name and email on all commits:

```powershell
git config --global user.name "Your Name"
git config --global user.email "your_email@example.com"
```

Verify the values were saved:

```powershell
git config --global user.name
git config --global user.email
```

---

## Push Your Local Project to GitHub

### Step 1 — Navigate to your project folder

```powershell
cd path/to/workbench-core-api-automation
```

### Step 2 — Initialise Git (if not already)

```powershell
git init
```

### Step 3 — Add the remote repository

Replace the URL with your repository's HTTPS URL from GitHub:

```powershell
git remote add origin https://github.com/<username>/<repository-name>.git
```

### Step 4 — Stage and commit

```powershell
git add .
git commit -m "Initial skeleton framework"
```

### Step 5 — Push to GitHub

```powershell
git push -u origin main
```

If prompted for credentials, enter your GitHub username and paste the PAT as the password.

---

### Verify remote connection

```powershell
git remote -v
```

Expected output:

```
origin  https://github.com/<username>/<repository-name>.git (fetch)
origin  https://github.com/<username>/<repository-name>.git (push)
```

### Update remote URL

If the remote URL changes (e.g. repository renamed or migrated):

```powershell
git remote set-url origin https://github.com/<username>/<new-repository-name>.git
```

---

## Fetch

Downloads changes from remote without applying them. Safe to run at any time.

```powershell
# Fetch all branches from origin
git fetch origin

# Fetch a specific branch
git fetch origin <branch-name>
```

---

## Pull

Downloads and applies changes from remote into your current branch.

```powershell
# Pull latest changes into current branch
git pull

# Pull from a specific remote and branch
git pull origin <branch-name>

# Pull with rebase instead of merge (cleaner history)
git pull --rebase origin <branch-name>
```

---

## Branching

### Create a new branch

```powershell
# Create a branch and stay on current branch
git branch <branch-name>

# Create a branch and switch to it immediately (recommended)
git checkout -b <branch-name>

# Create a branch from a specific base branch
git checkout -b <branch-name> origin/<base-branch>
```

### Switch branch

```powershell
# Switch to an existing branch
git checkout <branch-name>

# Switch using the newer syntax
git switch <branch-name>
```

### List branches

```powershell
# List local branches
git branch

# List all branches including remote
git branch -a
```

### Delete a branch

```powershell
# Delete a local branch (safe — only if merged)
git branch -d <branch-name>

# Force delete a local branch
git branch -D <branch-name>
```

---

## Stage Changes

```powershell
# Stage a specific file
git add <file-path>

# Stage all changed files
git add .

# Stage specific files by pattern
git add features/
git add helpers/
git add *.feature
```

---

## Commit

```powershell
# Commit with a message
git commit -m "your commit message"

# Stage all tracked changes and commit in one step
git commit -am "your commit message"

# Amend the last commit message (before pushing)
git commit --amend -m "corrected message"
```

### Recommended commit message format

```
<type>: <short description>

Examples:
feat: add login step definition
fix: correct status code assertion
test: add post creation scenario
docs: update README setup steps
refactor: extract auth helper
```

---

## Push

```powershell
# Push current branch to origin
git push

# Push and set upstream tracking (first push of a new branch)
git push -u origin <branch-name>

# Push to a specific remote branch
git push origin <branch-name>

# Push to a specific branch with explicit mapping
git push origin <local-branch>:<remote-branch>
```

---

## Full workflow: working on a feature branch

```powershell
# 1. Get latest changes from main
git fetch origin
git checkout main
git pull origin main

# 2. Create and switch to your feature branch
git checkout -b feature/<your-feature-name>

# 3. Make your changes to feature, step, or helper files

# 4. Stage your changes
git add .

# 5. Commit with a clear message
git commit -m "feat: add <your-feature-name> step definitions"

# 6. Push the branch to remote
git push -u origin feature/<your-feature-name>

# 7. Open a pull request from your branch into main
```

---

## Full workflow: updating an existing branch with latest main

```powershell
# Fetch latest from remote
git fetch origin

# Merge main into your current branch
git merge origin/main

# Or rebase your branch on top of main (cleaner history)
git rebase origin/main
```

---

## Recovery workflow: changes were accidentally made on main

If QA or another contributor accidentally made changes directly on `main`, use this workflow to preserve the work and move it into `develop`.

### 1. Commit and push your changes to main

```powershell
git add .
git commit -m "Your commit message."
git push origin main
```

### 2. Switch to develop branch

```powershell
git checkout develop
```

### 3. Pull the changes from main into develop using rebase

```powershell
git rebase main
```

### 4. Push the updated develop branch

```powershell
git push origin develop
```

---

## Undo and recover

```powershell
# Unstage a file (keep changes)
git restore --staged <file-path>

# Discard changes to a file (irreversible)
git restore <file-path>

# Undo last commit but keep changes staged
git reset --soft HEAD~1

# Undo last commit and unstage changes
git reset --mixed HEAD~1

# View commit history
git log --oneline

# View changes not yet staged
git diff

# View staged changes
git diff --staged
```

---

## Suggested branch naming

| Type          | Pattern                         | Example                          |
|---------------|---------------------------------|----------------------------------|
| Feature       | `feature/<short-description>`   | `feature/login-step-definitions` |
| Bug fix       | `fix/<short-description>`       | `fix/status-code-assertion`      |
| Refactor      | `refactor/<short-description>`  | `refactor/auth-helper`           |
| Documentation | `docs/<short-description>`      | `docs/update-framework-guide`    |
| Test          | `test/<short-description>`      | `test/add-post-scenarios`        |

---

## How to Create Develop & Feature Branches and How to Merge Changes Between Branches

### 1. Clone your repository

If you haven't already:

```powershell
git clone https://github.com/your-username/your-repo.git
cd your-repo
```

### 2. Create the develop branch

The develop branch acts as the integration branch where features are merged before going to main.

```powershell
git checkout -b develop
git push -u origin develop
```

### 3. Create a feature branch

Feature branches are created off develop for isolated work.

```powershell
git checkout develop
git checkout -b feature/your-feature-name
git push -u origin feature/your-feature-name
git push --set-upstream origin feature/testcaseID-your-feature-name
```

> **Naming convention:** Use `feature/testcaseID-<short-description>` (e.g., `feature/499070-text-generation-capability`).

### 4. Work on your feature

Make changes, commit them:

```powershell
git add .
git commit -m "feature/499070-text-generation-capability"
git push
```

### 5. Merge feature branch back into develop

When the feature is complete:

```powershell
git checkout develop
git pull
git merge feature/your-feature-name
git push
```

Alternatively, you can open a Pull Request (PR) on GitHub from `feature/testcaseID-your-feature-name` → `develop`. This allows code review and CI checks.

### 6. Merge develop into main

Once several features are tested and stable:

```powershell
git checkout main
git pull
git merge develop
git push
```

### 7. Setting Upstream

If a branch has no upstream tracking set, use the following:

```powershell
# For main
git push --set-upstream origin main

# For develop
git push --set-upstream origin develop

# For a feature branch (replace with your actual name)
git push --set-upstream origin feature/testcaseID-your-feature-name
```

---

### Best Practices

- Keep `main` always deployable and stable.
- Use `develop` for ongoing integration.
- Create feature branches for each new task or bug fix.
- Prefer PRs over direct merges for visibility and review.
- Delete feature branches after merging to keep the repo clean.

---

## Delete a Feature Branch

After a feature branch has been merged, delete it locally and remotely to keep the repository clean.

### 1. Confirm the branch has been merged

```powershell
# Switch to develop (or main) first
git checkout develop

# Verify the feature branch appears in the merged list
git branch --merged
```

### 2. Delete the feature branch after merging

```powershell
# Safe delete — only works if the branch has been merged
git branch -d feature/<your-feature-name>

# Force delete — use if you are sure you no longer need the branch
git branch -D feature/<your-feature-name>

# Delete the remote branch
git push origin --delete feature/<your-feature-name>
```

### Deleting a feature branch without merging

If you want to abandon a feature branch without merging it into `develop` or `main`, use a force delete:

```powershell
# 1. Switch away from the branch first
git checkout develop

# 2. Force delete the local branch (discards all unmerged commits)
git branch -D feature/<your-feature-name>

# 3. Delete the remote branch
git push origin --delete feature/<your-feature-name>
```

> **Warning:** This permanently discards all commits on the branch that have not been merged elsewhere. Make sure you no longer need any of the work on that branch before proceeding.

### 3. Delete the remote branch

```powershell
git push origin --delete feature/<your-feature-name>
```

### 4. Verify the branch is gone

```powershell
# Confirm it no longer appears locally
git branch

# Confirm it no longer appears on the remote
git branch -r
```

### 5. Prune stale remote-tracking references (optional)

After the remote branch is deleted, clean up any stale references in your local repo:

```powershell
git fetch --prune
```

---

## Related files

- [README.md](README.md) - project overview and run instructions
- [FRAMEWORK_SETUP.md](FRAMEWORK_SETUP.md) - environment setup guide
- [FRAMEWORK_ARCHITECTURE.md](FRAMEWORK_ARCHITECTURE.md) - framework architecture guide
- [GHERKIN_STYLE_GUIDE.md](GHERKIN_STYLE_GUIDE.md) - Gherkin writing standards