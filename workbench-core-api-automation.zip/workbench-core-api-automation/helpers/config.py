from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env", override=True)

REGION_MAP = {
    # API region → env prefix
    "eastus": "AMER",
    "westeurope": "EMEA",
    "australiaeast": "ASPAC",
    # Also accept prefix directly
    "amer": "AMER",
    "emea": "EMEA",
    "aspac": "ASPAC",
}

TOKEN_URL = os.getenv("TOKEN_URL")
AGENT_TOKEN_URL = os.getenv("AGENT_TOKEN_URL")
BASE_URL = os.getenv("BASE_URL")


@dataclass(frozen=True)
class Settings:
    base_url: str
    timeout: int
    verify_ssl: bool
    default_headers: dict[str, str]
    allure_results_dir: str
    open_allure_on_complete: bool


def _parse_bool(value: str | None, default: bool = True) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_headers(value: str | None) -> dict[str, str]:
    if not value:
        return {}
    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise ValueError("DEFAULT_HEADERS must be a JSON object.")
    return {str(k): str(v) for k, v in parsed.items()}


def get_settings() -> Settings:
    base_url = os.getenv("BASE_URL", "").strip()
    if not base_url:
        raise ValueError("BASE_URL is not set.")
    return Settings(
        base_url=base_url,
        timeout=int(os.getenv("API_TIMEOUT", "30")),
        verify_ssl=_parse_bool(os.getenv("IGNORE_SSL_VERIFY"), default=True),
        default_headers=_parse_headers(os.getenv("DEFAULT_HEADERS")),
        allure_results_dir=os.getenv("ALLURE_RESULTS_DIR", "reports/allure-results"),
        open_allure_on_complete=_parse_bool(os.getenv("OPEN_ALLURE_ON_COMPLETE"), default=True),
    )


def get_region() -> str:
    return os.getenv("DEFAULT_REGION", "AMER").strip().lower()


def _get_profiled_env_value(prefix: str, key: str, profile: str | None = None) -> str | None:
    if profile:
        profiled_key = f"{prefix}_{profile.upper()}_{key}"
        profiled_value = os.getenv(profiled_key)
        if profiled_value:
            return profiled_value

    return os.getenv(f"{prefix}_{key}")


def load_region_config(region: str, profile: str | None = None) -> dict[str, str]:
    prefix = REGION_MAP.get(region.strip().lower())
    if not prefix:
        raise ValueError(
            f"Unsupported region: '{region}'. "
            f"Valid values: {', '.join(REGION_MAP.keys())}"
        )

    config = {
        "TENANT_ID": _get_profiled_env_value(prefix, "TENANT_ID", profile),
        "CLIENT_ID": _get_profiled_env_value(prefix, "CLIENT_ID", profile),
        "CLIENT_SECRET": _get_profiled_env_value(prefix, "CLIENT_SECRET", profile),
        "SCOPE": _get_profiled_env_value(prefix, "SCOPE", profile),
    }

    missing = [k for k, v in config.items() if not v]
    if missing:
        env_suffix = f"_{profile.upper()}" if profile else ""
        raise ValueError(
            f"Missing env vars for region '{region}' ({prefix}{env_suffix}): {', '.join(missing)}"
        )

    return config


def get_token_url(profile: str | None = None) -> str:
    if profile and profile.strip().lower() == "agents" and AGENT_TOKEN_URL:
        return AGENT_TOKEN_URL
    if TOKEN_URL:
        return TOKEN_URL
    raise ValueError("TOKEN_URL is not set.")


REGION = get_region()
REGION_CONFIG = load_region_config(REGION)
 
