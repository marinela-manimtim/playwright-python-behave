from __future__ import annotations

import os
from typing import Any

import requests
import urllib3
from requests import Response, Session


class ApiClient:
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        verify_ssl: bool = True,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session: Session = requests.Session()

        ignore_ssl = os.getenv("IGNORE_SSL_VERIFY", "false").lower() == "true"
        self.session.verify = False if ignore_ssl else verify_ssl

        if not self.session.verify:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        if default_headers:
            self.session.headers.update(default_headers)
            

    def request(self, method: str, endpoint: str, **kwargs: Any) -> Response:
        url = f"{self.base_url}{endpoint}"
        return self.session.request(method, url, timeout=self.timeout, **kwargs)

    def get(self, endpoint: str, **kwargs: Any) -> Response:
        return self.request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, **kwargs: Any) -> Response:
        return self.request("POST", endpoint, **kwargs)

    def put(self, endpoint: str, **kwargs: Any) -> Response:
        return self.request("PUT", endpoint, **kwargs)

    def patch(self, endpoint: str, **kwargs: Any) -> Response:
        return self.request("PATCH", endpoint, **kwargs)

    def delete(self, endpoint: str, **kwargs: Any) -> Response:
        return self.request("DELETE", endpoint, **kwargs)

    def close(self) -> None:
        self.session.close()