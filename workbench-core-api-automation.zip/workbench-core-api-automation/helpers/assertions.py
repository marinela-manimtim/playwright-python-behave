from __future__ import annotations

from typing import Any

from requests import Response


def assert_status_code(response: Response, expected_status_code: int) -> None:
    actual = response.status_code
    if actual != expected_status_code:
        raise AssertionError(
            f"Expected status code {expected_status_code}, but got {actual}. Response body: {response.text}"
        )


def extract_json_path(payload: Any, path: str) -> Any:
    current = payload
    for part in path.split("."):
        if isinstance(current, list):
            current = current[int(part)]
            continue

        if not isinstance(current, dict) or part not in current:
            raise AssertionError(f"JSON path '{path}' was not found in response body.")

        current = current[part]

    return current

