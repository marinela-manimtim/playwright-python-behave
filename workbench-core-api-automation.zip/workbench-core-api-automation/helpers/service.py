import os

import requests
from auth.auth_handler import AuthHandler
from auth.playwright_auth_handler import PlaywrightAuthHandler
from helpers.api_client import ApiClient
from helpers.config import get_settings


class Service:
    def __init__(
        self,
        region: str,
        timeout: int | None = None,
        skip_auth: bool = False,
        auth_profile: str | None = None,
        use_implicit_auth: bool = False,
        skip_region_override_australiaeast: bool = False,
    ):
        settings = get_settings()
        self.skip_auth = skip_auth
        self.auth_profile = auth_profile
        self.use_implicit_auth = use_implicit_auth
        self.skip_region_override_australiaeast = skip_region_override_australiaeast
        self.region = region
        self.auth_handler = None
        if not skip_auth:
            self.auth_handler = (
                PlaywrightAuthHandler(region, profile=auth_profile)
                if use_implicit_auth
                else AuthHandler(region, profile=auth_profile)
            )
        auth_headers = {} if skip_auth else self.auth_handler.get_auth_headers()

        default_headers = {
            **settings.default_headers,
            **auth_headers,
        }

        self.client = ApiClient(
            base_url=settings.base_url,
            timeout=timeout if timeout is not None else settings.timeout,
            verify_ssl=settings.verify_ssl,
            default_headers=default_headers,
        )

    @property
    def base_url(self) -> str:
        return self.client.base_url

    def _refresh_auth_header(self) -> None:
        if self.skip_auth or not self.auth_handler:
            return
        refreshed_headers = self.auth_handler.get_auth_headers(force_refresh=True)
        self.client.session.headers.update(refreshed_headers)

    def _request_with_retry(self, method_name: str, endpoint, **kwargs):
        method = getattr(self.client, method_name)
        response = method(endpoint, **kwargs)

        explicit_headers = kwargs.get("headers")
        has_explicit_auth_header = (
            isinstance(explicit_headers, dict)
            and any(str(key).lower() == "authorization" for key in explicit_headers)
        )

        if self.skip_auth or response.status_code != 401 or has_explicit_auth_header:
            return response

        self._refresh_auth_header()
        return method(endpoint, **kwargs)

    def get(self, endpoint, **kwargs):
        return self._request_with_retry("get", endpoint, **kwargs)

    def post(self, endpoint, **kwargs):
        return self._request_with_retry("post", endpoint, **kwargs)

    def put(self, endpoint, **kwargs):
        return self._request_with_retry("put", endpoint, **kwargs)

    def patch(self, endpoint, **kwargs):
        return self._request_with_retry("patch", endpoint, **kwargs)

    def delete(self, endpoint, **kwargs):
        return self._request_with_retry("delete", endpoint, **kwargs)