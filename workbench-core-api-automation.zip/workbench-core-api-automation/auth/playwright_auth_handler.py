"""
PlaywrightAuthHandler
=====================
Performs browser-based implicit authentication against Microsoft Entra ID
(Azure AD) using Playwright.

This handler is designed for authorize URLs like:

    https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/authorize
        ?response_type=token
        &client_id={CLIENT_ID}
        &scope=<REGION_RESOURCE>/user_impersonation
        &redirect_uri=https://oauth.pstmn.io/v1/callback

The token is extracted from the redirect URL fragment, for example:

    https://oauth.pstmn.io/v1/callback#access_token=...

Required .env variables
-----------------------
PLAYWRIGHT_LOGIN_URL      – Authorize URL template. Supports {TENANT_ID}
                            and {CLIENT_ID} placeholders.
PLAYWRIGHT_USERNAME       – User principal name (e.g. user@domain.com).
PLAYWRIGHT_PASSWORD       – User password. Store this in a secret manager in CI.

Optional .env variables
-----------------------
PLAYWRIGHT_ACCESS_TOKEN  – Pre-obtained bearer token OR full callback URL
                           containing access_token (manual implicit-flow
                           workaround). If present and not expired, this token
                           is used instead of browser automation.
PLAYWRIGHT_ACCESS_TOKEN_URL – Optional alias for full callback URL from
                           redirect (e.g. https://...#access_token=...).
PLAYWRIGHT_ACCESS_TOKEN_EXPIRES_AT – Optional Unix epoch (seconds) for the
                           above token expiry. If omitted, expiry is inferred
                           from JWT "exp" claim when available.
PLAYWRIGHT_MANUAL_LOGIN   – "true" to open browser for manual sign-in and
                           auto-extract the token from the redirect URL once
                           you complete login (including MFA). No copy/paste
                           needed. The browser stays open until redirect.
PLAYWRIGHT_MANUAL_LOGIN_TIMEOUT_MS – How long (ms) to wait for the redirect
                           when PLAYWRIGHT_MANUAL_LOGIN=true. Default 300000
                           (5 minutes).
PLAYWRIGHT_PROMPT_FOR_TOKEN – "true" to open browser for manual sign-in and
                           prompt in terminal to paste the token at runtime.
PLAYWRIGHT_HEADLESS       – "true" (default) | "false".
PLAYWRIGHT_SLOW_MO_MS     – Extra milliseconds between Playwright actions.
PLAYWRIGHT_TIMEOUT_MS     – Navigation / selector timeout in ms.
PLAYWRIGHT_EXPECT_REDIRECT_PREFIX – Expected redirect URL prefix. Defaults to
                            https://oauth.pstmn.io/v1/callback

Security note
-------------
Credentials are read exclusively from env vars / .env. They are never
logged, stored in files, or echoed in error messages.
"""

from __future__ import annotations

import json
import logging
import os
import time
import base64
import binascii
from pathlib import Path
from urllib.parse import parse_qs, parse_qsl, urlencode, urlparse, urlunparse
from typing import Any, Callable

from dotenv import load_dotenv
from helpers.config import load_region_config

ENV_FILE = Path(__file__).resolve().parents[1] / ".env"

load_dotenv(ENV_FILE, override=True)

logger = logging.getLogger(__name__)
_IMPLICIT_TOKEN_CACHE: dict[tuple[str, str | None], tuple[str, float]] = {}
_BROWSER_OPEN_HOOKS: list[Callable[[dict[str, Any]], None]] = []
_BROWSER_CLOSE_HOOKS: list[Callable[[dict[str, Any]], None]] = []

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _reload_env_file() -> None:
    load_dotenv(ENV_FILE, override=True)


def register_browser_lifecycle_hooks(
    on_open: Callable[[dict[str, Any]], None] | None = None,
    on_close: Callable[[dict[str, Any]], None] | None = None,
) -> None:
    """Register optional callbacks for Playwright browser open/close events."""
    if on_open and on_open not in _BROWSER_OPEN_HOOKS:
        _BROWSER_OPEN_HOOKS.append(on_open)
    if on_close and on_close not in _BROWSER_CLOSE_HOOKS:
        _BROWSER_CLOSE_HOOKS.append(on_close)


def _emit_browser_event(
    hooks: list[Callable[[dict[str, Any]], None]],
    event_name: str,
    event_payload: dict[str, Any],
) -> None:
    for hook in hooks:
        try:
            hook(event_payload)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Playwright %s hook raised an exception: %s", event_name, exc)

def _get_required_env(key: str) -> str:
    value = os.getenv(key, "").strip()
    if not value:
        raise ValueError(
            f"Required environment variable '{key}' is not set. "
            "Add it to your .env file or CI secret store."
        )
    return value


def _is_headless() -> bool:
    return os.getenv("PLAYWRIGHT_HEADLESS", "true").strip().lower() not in {"false", "0", "no", "off"}


def _slow_mo() -> float:
    raw = os.getenv("PLAYWRIGHT_SLOW_MO_MS", "0").strip()
    try:
        return float(raw)
    except ValueError:
        return 0.0


def _timeout_ms() -> float:
    raw = os.getenv("PLAYWRIGHT_TIMEOUT_MS", "60000").strip()
    try:
        return float(raw)
    except ValueError:
        return 60_000.0


def _parse_token_from_redirect_url(current_url: str) -> tuple[str, int] | None:
    """Parse an implicit-flow access token from a redirect URL fragment."""
    parsed = urlparse(current_url)
    if not parsed.fragment:
        return None

    fragment_params = parse_qs(parsed.fragment, keep_blank_values=True)
    access_token_values = fragment_params.get("access_token")
    expires_in_values = fragment_params.get("expires_in")

    if not access_token_values:
        return None

    access_token = access_token_values[0]
    try:
        expires_in = int((expires_in_values or ["3600"])[0])
    except (TypeError, ValueError):
        expires_in = 3600

    expires_at = int(time.time()) + max(0, expires_in)
    return access_token, expires_at


def _decode_jwt_expiry(token: str) -> int | None:
    """Best-effort decode of JWT 'exp' claim without signature verification."""
    parts = token.split(".")
    if len(parts) < 2:
        return None

    payload_b64 = parts[1]
    padding = "=" * (-len(payload_b64) % 4)
    try:
        payload_raw = base64.urlsafe_b64decode(payload_b64 + padding)
        payload = json.loads(payload_raw.decode("utf-8"))
        exp = payload.get("exp")
        if exp is None:
            return None
        return int(exp)
    except (ValueError, TypeError, binascii.Error, json.JSONDecodeError):
        return None


def _get_manual_token_from_env() -> tuple[str, int] | None:
    """Return (token, expires_at) from env when manually supplied."""
    _reload_env_file()
    token_source = os.getenv("PLAYWRIGHT_ACCESS_TOKEN", "").strip()
    token_source_name = "PLAYWRIGHT_ACCESS_TOKEN"
    if not token_source:
        token_source = os.getenv("PLAYWRIGHT_ACCESS_TOKEN_URL", "").strip()
        token_source_name = "PLAYWRIGHT_ACCESS_TOKEN_URL"

    token = _parse_token_input(token_source)
    if not token:
        return None

    expires_at_raw = os.getenv("PLAYWRIGHT_ACCESS_TOKEN_EXPIRES_AT", "").strip()
    expires_at: int | None = None
    if expires_at_raw:
        try:
            expires_at = int(expires_at_raw)
        except ValueError:
            raise ValueError(
                "PLAYWRIGHT_ACCESS_TOKEN_EXPIRES_AT must be a Unix epoch in seconds."
            )

    if expires_at is None:
        expires_at = _decode_jwt_expiry(token)

    if expires_at is None:
        expires_at = int(time.time()) + 300

    logger.info("Using manual implicit token from %s", token_source_name)
    print(f"Using manual implicit token from {token_source_name}.")
    return token, expires_at


def _parse_token_input(raw_value: str) -> str | None:
    """Accept either a raw JWT token or a callback URL containing access_token."""
    value = (raw_value or "").strip()
    if not value:
        return None

    if "access_token=" in value:
        parsed = urlparse(value)

        fragment_params = parse_qs(parsed.fragment, keep_blank_values=True)
        fragment_token = (fragment_params.get("access_token") or [None])[0]
        if fragment_token:
            return fragment_token

        query_params = parse_qs(parsed.query, keep_blank_values=True)
        query_token = (query_params.get("access_token") or [None])[0]
        if query_token:
            return query_token

    return value


# ---------------------------------------------------------------------------
# Public handler
# ---------------------------------------------------------------------------


class PlaywrightAuthHandler:
    """
    Browser-based auth handler that uses Playwright to sign in to an Azure AD
    protected application and extracts the MSAL access token from localStorage.

    Usage::

        handler = PlaywrightAuthHandler()
        headers = handler.get_auth_headers()   # {"Authorization": "Bearer <token>"}
    """

    def __init__(self, region: str, profile: str | None = None) -> None:
        self.region = region
        self.profile = profile
        self.region_config = load_region_config(region, profile=profile)
        self._login_url_template: str = _get_required_env("PLAYWRIGHT_LOGIN_URL")

        self._expected_redirect_prefix: str = os.getenv(
            "PLAYWRIGHT_EXPECT_REDIRECT_PREFIX",
            "https://oauth.pstmn.io/v1/callback",
        ).strip()
        self._access_token: str | None = None
        self._expires_at: float = 0.0

    def _build_login_url(self) -> str:
        """Resolve region-aware placeholders in the authorize URL template."""
        login_url = (
            self._login_url_template
            .replace("{TENANT_ID}", self.region_config["TENANT_ID"])
            .replace("{CLIENT_ID}", self.region_config["CLIENT_ID"])
        )

        # Ensure the delegated scope in authorize URL is region-correct to
        # avoid audience mismatches that produce 401 "token invalid" responses.
        resolved_scope = self._resolve_authorize_scope()
        parsed = urlparse(login_url)
        query_items = parse_qsl(parsed.query, keep_blank_values=True)
        updated_query: list[tuple[str, str]] = []
        scope_replaced = False
        for key, value in query_items:
            if key == "scope":
                updated_query.append(("scope", resolved_scope))
                scope_replaced = True
            else:
                updated_query.append((key, value))

        if not scope_replaced:
            updated_query.append(("scope", resolved_scope))

        return urlunparse(parsed._replace(query=urlencode(updated_query, doseq=True)))

    def _resolve_authorize_scope(self) -> str:
        """Resolve delegated scope for implicit authorize call."""
        explicit_scope_raw = os.getenv("PLAYWRIGHT_SCOPE", "")
        # Allow inline comments in .env (e.g. PLAYWRIGHT_SCOPE=  # optional)
        explicit_scope = explicit_scope_raw.split("#", 1)[0].strip()
        if explicit_scope:
            return (
                explicit_scope
                .replace("{TENANT_ID}", self.region_config["TENANT_ID"])
                .replace("{CLIENT_ID}", self.region_config["CLIENT_ID"])
            )

        configured_scope = (self.region_config.get("SCOPE") or "").strip()
        if configured_scope:
            # Region config commonly uses "<resource>/.default" for client-credentials.
            # For implicit delegated auth we need "<resource>/user_impersonation".
            if configured_scope.endswith("/.default"):
                configured_scope = configured_scope[: -len("/.default")] + "/user_impersonation"
            if not configured_scope.startswith("api://"):
                configured_scope = f"api://{configured_scope}"
            return configured_scope

        raise ValueError(
            "Unable to resolve delegated scope for implicit auth. "
            "Set PLAYWRIGHT_SCOPE explicitly or configure region *_SCOPE env vars."
        )

    def _cache_key(self) -> tuple[str, str | None]:
        return self.region, self.profile

    # ------------------------------------------------------------------
    # Public API (mirrors AuthHandler)
    # ------------------------------------------------------------------

    def get_auth_headers(self, force_refresh: bool = False) -> dict[str, str]:
        """Return ``{"Authorization": "Bearer <token>"}``."""
        token = self.get_implicit_token(force_refresh=force_refresh)
        return {"Authorization": f"Bearer {token}"}

    def get_implicit_token(self, force_refresh: bool = False) -> str:
        """
        Return a valid access token, refreshing via browser login if needed.

        The cached token is reused until 60 seconds before its expiry.
        """
        cache_key = self._cache_key()
        print(f"[PlaywrightAuthHandler] get_implicit_token called: region={self.region}, profile={self.profile}, force_refresh={force_refresh}, cache_key={cache_key}")
        print(f"[PlaywrightAuthHandler] Global cache contents: {list(_IMPLICIT_TOKEN_CACHE.keys())}")
        
        if (
            not force_refresh
            and self._access_token
            and time.time() < self._expires_at
        ):
            print(f"[PlaywrightAuthHandler] Returning instance-level cached token (expires_at={self._expires_at})")
            return self._access_token

        if not force_refresh:
            cached = _IMPLICIT_TOKEN_CACHE.get(cache_key)
            if cached:
                cached_token, cached_expires_at = cached
                time_now = time.time()
                print(f"[PlaywrightAuthHandler] Found global cache entry. Expiry check: time_now={time_now}, cached_expires_at={cached_expires_at}, valid={time_now < cached_expires_at}")
                if time.time() < cached_expires_at:
                    self._access_token = cached_token
                    self._expires_at = cached_expires_at
                    logger.info("Reusing cached implicit token for region '%s'", self.region)
                    print(f"[PlaywrightAuthHandler] Reusing global cached token for {cache_key}")
                    return self._access_token
                else:
                    print(f"[PlaywrightAuthHandler] Cached token expired, proceeding to refresh")
            else:
                print(f"[PlaywrightAuthHandler] No cache entry for {cache_key}, will need fresh token")

        manual_token = _get_manual_token_from_env()
        if manual_token is not None:
            token, expires_on = manual_token
            if time.time() < float(expires_on):
                self._access_token = token
                self._expires_at = max(0.0, float(expires_on) - 60.0)
                _IMPLICIT_TOKEN_CACHE[self._cache_key()] = (self._access_token, self._expires_at)
                print(f"[PlaywrightAuthHandler] Using manual token from env")
                return self._access_token
            # Token expired — fall through to browser login.
            print("Saved token has expired. Falling through to browser login.")

        print(f"[PlaywrightAuthHandler] Opening browser for {cache_key}...")
        token, expires_on = self._browser_login()
        self._access_token = token
        # Refresh 60 s before the token's server-side expiry.
        self._expires_at = max(0.0, float(expires_on) - 60.0)
        _IMPLICIT_TOKEN_CACHE[self._cache_key()] = (self._access_token, self._expires_at)
        print(f"[PlaywrightAuthHandler] Browser login successful. Cached token for {cache_key}, expires_at={self._expires_at}")
        return self._access_token

    # ------------------------------------------------------------------
    # Internal: browser automation
    # ------------------------------------------------------------------

    def _browser_login(self) -> tuple[str, int]:
        """
        Launch a browser, complete the Azure AD login, and return the token
        from the final redirect URL fragment.

        :raises RuntimeError: when login cannot be completed or no token is found.
        """
        # Import inside the method so that projects that never use this handler
        # do not raise ImportError if playwright is absent.
        print(f"[PlaywrightAuthHandler._browser_login] Starting browser login for region {self.region}...")
        try:
            from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
        except ImportError as exc:
            raise ImportError(
                "playwright is not installed.  "
                "Run: pip install playwright && playwright install chromium"
            ) from exc

        username = _get_required_env("PLAYWRIGHT_USERNAME")
        password = _get_required_env("PLAYWRIGHT_PASSWORD")
        timeout = _timeout_ms()
        print(f"[PlaywrightAuthHandler._browser_login] Timeout={timeout}ms, headless={_is_headless()}, slow_mo={_slow_mo()}ms")

        with sync_playwright() as pw:
            print(f"[PlaywrightAuthHandler._browser_login] Launching chromium browser (headless={_is_headless()})...")
            browser = pw.chromium.launch(
                headless=_is_headless(),
                slow_mo=_slow_mo(),
                channel="chrome",
            )
            print(f"[PlaywrightAuthHandler._browser_login] Browser launched successfully")
            _emit_browser_event(
                _BROWSER_OPEN_HOOKS,
                "open",
                {
                    "event": "browser_open",
                    "region": self.region,
                    "profile": self.profile,
                    "headless": _is_headless(),
                    "channel": "chrome",
                    "timeout_ms": timeout,
                    "timestamp": time.time(),
                },
            )
            context = browser.new_context(
                http_credentials={
                    "username": username,
                    "password": password,
                }
            )
            page = context.new_page()
            page.set_default_timeout(timeout)
            captured_redirect_url: str | None = None

            def _consider_url(candidate_url: str | None) -> None:
                nonlocal captured_redirect_url
                if captured_redirect_url:
                    return
                url_value = (candidate_url or "").strip()
                if not url_value:
                    return

                # Primary match: expected callback prefix + token fragment.
                if (
                    url_value.startswith(self._expected_redirect_prefix)
                    and "access_token=" in url_value
                ):
                    captured_redirect_url = url_value
                    return

                # Fallback: token appears in another callback/tab URL.
                if "access_token=" in url_value:
                    captured_redirect_url = url_value

            def _attach_page_watchers(watched_page: Any) -> None:
                try:
                    watched_page.on("framenavigated", lambda frame: _consider_url(getattr(frame, "url", None)))
                except Exception:
                    pass
                try:
                    watched_page.on("load", lambda: _consider_url(getattr(watched_page, "url", "")))
                except Exception:
                    pass

            context.on("page", _attach_page_watchers)
            _attach_page_watchers(page)

            try:
                login_url = self._build_login_url()
                logger.debug("Navigating to login URL for region '%s'", self.region)
                page.goto(login_url, wait_until="load")

                # ----------------------------------------------------------
                # Azure AD username step
                # ----------------------------------------------------------
                self._fill_aad_username(page, username, timeout)

                # ----------------------------------------------------------
                # Azure AD password step
                # ----------------------------------------------------------
                try:
                    self._fill_aad_password(page, password, timeout)
                except RuntimeError:
                    # Some tenant flows (passwordless/federated/new AAD UX)
                    # may not expose a direct password selector. In that case
                    # allow the user to finish auth manually in the visible
                    # browser and continue waiting for redirect token capture.
                    print(
                        "Password field was not auto-detected. "
                        "Continue sign-in manually in the browser (password/MFA/account picker)."
                    )

                # ----------------------------------------------------------
                # Handle "Stay signed in?" prompt if present
                # ----------------------------------------------------------
                self._handle_kmsi_prompt(page, timeout)

                # Some redirect URIs (like oauth.pstmn.io) may open/switch tabs
                # and only briefly expose the fragment. Use both event-driven
                # capture and page polling so token URLs are not missed.
                redirected_url = ""
                deadline = time.time() + (timeout / 1000.0)
                while time.time() < deadline and not redirected_url:
                    if captured_redirect_url:
                        redirected_url = captured_redirect_url
                        break

                    for candidate_page in list(context.pages):
                        try:
                            candidate_url = candidate_page.url or ""
                        except Exception:
                            continue

                        _consider_url(candidate_url)
                        if captured_redirect_url:
                            redirected_url = captured_redirect_url
                            break

                    if not redirected_url:
                        time.sleep(0.25)

                if not redirected_url:
                    raise RuntimeError(
                        "Timed out waiting for redirect URL containing access_token. "
                        "If using oauth.pstmn.io, confirm the callback tab opened and includes #access_token=."
                    )

            except PWTimeout as exc:
                raise RuntimeError(
                    f"Playwright timed out during Azure AD login (timeout={timeout} ms). "
                    f"Details: {exc}"
                ) from exc
            finally:
                context.close()
                browser.close()
                _emit_browser_event(
                    _BROWSER_CLOSE_HOOKS,
                    "close",
                    {
                        "event": "browser_close",
                        "region": self.region,
                        "profile": self.profile,
                        "headless": _is_headless(),
                        "channel": "chrome",
                        "timeout_ms": timeout,
                        "timestamp": time.time(),
                    },
                )

        result = _parse_token_from_redirect_url(redirected_url)
        if result is None:
            raise RuntimeError(
                "No implicit-flow access token was found in the redirect URL. "
                "Confirm that the app registration allows implicit access tokens, "
                "the redirect URI is registered, and the authorize URL returns "
                "response_type=token."
            )

        return result

    # ------------------------------------------------------------------
    # Page-interaction helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _fill_aad_username(page: Any, username: str, timeout: float) -> None:
        """Fill in the username / UPN field on the Azure AD login page."""
        from playwright.sync_api import TimeoutError as PWTimeout

        # Azure AD renders the username input as input[type=email] or #i0116
        selectors = ["input[type='email']", "#i0116", "input[name='loginfmt']"]
        for selector in selectors:
            try:
                page.wait_for_selector(selector, timeout=timeout)
                page.fill(selector, username)
                page.click("input[type='submit'], #idSIButton9")
                return
            except PWTimeout:
                continue

        raise RuntimeError(
            "Could not locate the Azure AD username input field. "
            f"Tried selectors: {selectors}"
        )

    @staticmethod
    def _fill_aad_password(page: Any, password: str, timeout: float) -> None:
        """Fill in the password field on the Azure AD login page."""
        from playwright.sync_api import TimeoutError as PWTimeout

        selectors = ["input[type='password']", "#i0118", "input[name='passwd']"]
        for selector in selectors:
            try:
                page.wait_for_selector(selector, timeout=timeout)
                page.fill(selector, password)
                page.click("input[type='submit'], #idSIButton9")
                return
            except PWTimeout:
                continue

        raise RuntimeError(
            "Could not locate the Azure AD password input field. "
            f"Tried selectors: {selectors}"
        )

    @staticmethod
    def _handle_kmsi_prompt(page: Any, timeout: float) -> None:
        """
        Dismiss the 'Keep me signed in?' (KMSI) prompt if it appears.
        Clicks 'No' to avoid persisting session cookies between test runs.
        """
        from playwright.sync_api import TimeoutError as PWTimeout

        try:
            page.wait_for_selector("#idBtn_Back", timeout=5_000)
            page.click("#idBtn_Back")  # "No" button
        except PWTimeout:
            pass  # Prompt did not appear – that is fine