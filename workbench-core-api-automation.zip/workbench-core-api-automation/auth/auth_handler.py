import time
import requests
from helpers.config import get_token_url, load_region_config

class AuthHandler:
    def __init__(self, region: str, profile: str | None = None):
        self.region = region
        self.profile = profile
        self.region_config = load_region_config(region, profile=profile)
        self.token_url_template = get_token_url(profile=profile)
        self.access_token = None
        self.expires_at = None
        
    def get_auth_headers(self, force_refresh: bool = False):
        token = self.get_oauth2_token(force_refresh=force_refresh)
        return {"Authorization": f"Bearer {token}"}
    
    def get_oauth2_token(self, force_refresh: bool = False):
        # If the Condition fails → does NOT return cached token → falls through to fetch a new token
        if (not force_refresh) and self.access_token and time.time() < self.expires_at:
            return self.access_token
        
        #Builds the new token URL
        tenant_id = self.region_config["TENANT_ID"]
        if "{TENANT_ID}" in self.token_url_template:
            url = self.token_url_template.replace("{TENANT_ID}", tenant_id)
        else:
            url = self.token_url_template
        
        #Builds the login payload
        payload = {
            "client_id": self.region_config["CLIENT_ID"],
            "client_secret": self.region_config["CLIENT_SECRET"],
            "scope": self.region_config["SCOPE"],
            "grant_type": "client_credentials",
        }
        
        #Sends POST request to Azure → gets new token
        response = requests.post(url, data=payload, timeout=60)
        if not response.ok:
            content_type = response.headers.get("Content-Type", "unknown")
            try:
                error_body = response.json()
            except requests.exceptions.JSONDecodeError:
                error_body = (response.text or "").strip()[:1000]
            raise ValueError(
                "Token endpoint request failed. "
                f"url={url}, status={response.status_code}, content_type={content_type}, "
                f"response={error_body}"
            )

        try:
            token_data = response.json()
        except requests.exceptions.JSONDecodeError as exc:
            content_type = response.headers.get("Content-Type", "unknown")
            body_preview = (response.text or "").strip()[:500]
            raise ValueError(
                "Token endpoint returned a non-JSON response. "
                f"url={url}, status={response.status_code}, content_type={content_type}, "
                f"body_preview={body_preview!r}"
            ) from exc

        if "access_token" not in token_data:
            raise ValueError(
                "Token endpoint JSON did not include 'access_token'. "
                f"url={url}, status={response.status_code}, body={token_data}"
            )
        #Saves the new token
        self.access_token = token_data["access_token"]
        #Resets expires_at to NOW + 3600 again (clock restarts)
        expires_in = int(token_data.get("expires_in", 3600))
        # Refresh 60s before provider-side expiry to reduce edge-case 401s.
        self.expires_at = time.time() + max(0, expires_in - 60)
        #   Returns the fresh token
        return self.access_token
