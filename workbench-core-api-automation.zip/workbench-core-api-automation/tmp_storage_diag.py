from pathlib import Path
import os
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

load_dotenv(Path('.env'), override=True)

regions = ['eastus', 'australiaeast', 'westeurope']
source = os.getenv('BATCH_TRANSLATION_SOURCE_CONTAINER', 'reg-source').strip()
destination = os.getenv('BATCH_TRANSLATION_DESTINATION_CONTAINER', 'reg-destination').strip()
directory = os.getenv('BATCH_TRANSLATION_DIRECTORY_NAME', 'sourceData').strip()

print(f'BATCH_TRANSLATION_SOURCE_CONTAINER={source}')
print(f'BATCH_TRANSLATION_DESTINATION_CONTAINER={destination}')
print(f'BATCH_TRANSLATION_DIRECTORY_NAME={directory}')
print(f'DATA_TRANSFER_SOURCE_CONTAINER={os.getenv("DATA_TRANSFER_SOURCE_CONTAINER")}')
print(f'DATA_TRANSFER_DESTINATION_CONTAINER={os.getenv("DATA_TRANSFER_DESTINATION_CONTAINER")}')
print(f'DATA_TRANSFER_DIRECTORY_NAME={os.getenv("DATA_TRANSFER_DIRECTORY_NAME")}')
print(f'SOURCE_EQUALS_DEST={source == destination}')

for region in regions:
    key = f'AZURE_STORAGE_CONNECTION_STRING_{region.replace("-", "_").upper()}'
    conn = (os.getenv(key) or '').strip().strip('"')
    print(f'\n=== REGION: {region} ===')
    if not conn:
        print(f'MISSING_CONN_STRING={key}')
        continue

    client = BlobServiceClient.from_connection_string(conn, connection_verify=False)
    print(f'ACCOUNT={client.account_name}')

    for name in [source, destination]:
        try:
            cc = client.get_container_client(name)
            exists = cc.exists()
            print(f'CONTAINER_{name}_EXISTS={exists}')
            if exists and name == source:
                blobs = list(cc.list_blobs(name_starts_with=f'{directory}/'))
                print(f'SOURCE_BLOB_COUNT_UNDER_{directory}={len(blobs)}')
                for blob in blobs[:5]:
                    print(f'SOURCE_BLOB={blob.name}')
        except Exception as exc:
            print(f'CONTAINER_{name}_ERROR={type(exc).__name__}:{exc}')
